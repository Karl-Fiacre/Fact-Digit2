import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.57.4';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface FNERequest {
  invoiceId: string;
  fneApiKey: string;
  invoiceData: {
    invoice_number: string;
    date_issued: string;
    total_amount: number;
    client_name: string;
    items: Array<{
      description: string;
      quantity: number;
      unit_price: number;
      total_price: number;
    }>;
  };
}

// Server-side validation functions
function validateString(value: unknown, fieldName: string, maxLength: number): string {
  if (typeof value !== 'string') {
    throw new Error(`${fieldName} doit être une chaîne de caractères`);
  }
  const trimmed = value.trim();
  if (trimmed.length === 0) {
    throw new Error(`${fieldName} ne peut pas être vide`);
  }
  if (trimmed.length > maxLength) {
    throw new Error(`${fieldName} ne peut pas dépasser ${maxLength} caractères`);
  }
  return trimmed;
}

function validateNumber(value: unknown, fieldName: string, min: number = 0): number {
  if (typeof value !== 'number' || isNaN(value)) {
    throw new Error(`${fieldName} doit être un nombre valide`);
  }
  if (value < min) {
    throw new Error(`${fieldName} doit être supérieur ou égal à ${min}`);
  }
  return value;
}

function validateUUID(value: unknown, fieldName: string): string {
  const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  if (typeof value !== 'string' || !uuidRegex.test(value)) {
    throw new Error(`${fieldName} doit être un UUID valide`);
  }
  return value;
}

function validateFNERequest(req: FNERequest): void {
  // Validate invoiceId
  validateUUID(req.invoiceId, 'Invoice ID');
  
  // Validate API key (10-500 chars)
  const apiKey = validateString(req.fneApiKey, 'Clé API FNE', 500);
  if (apiKey.length < 10) {
    throw new Error('La clé API FNE doit contenir au moins 10 caractères');
  }
  
  // Validate invoiceData
  if (!req.invoiceData || typeof req.invoiceData !== 'object') {
    throw new Error('Les données de facture sont invalides');
  }
  
  validateString(req.invoiceData.invoice_number, 'Numéro de facture', 100);
  validateString(req.invoiceData.date_issued, 'Date d\'émission', 50);
  validateNumber(req.invoiceData.total_amount, 'Montant total', 0);
  validateString(req.invoiceData.client_name, 'Nom du client', 255);
  
  // Validate items array
  if (!Array.isArray(req.invoiceData.items) || req.invoiceData.items.length === 0) {
    throw new Error('La facture doit contenir au moins un article');
  }
  
  if (req.invoiceData.items.length > 1000) {
    throw new Error('La facture ne peut pas contenir plus de 1000 articles');
  }
  
  req.invoiceData.items.forEach((item, index) => {
    validateString(item.description, `Article ${index + 1} - Description`, 500);
    validateNumber(item.quantity, `Article ${index + 1} - Quantité`, 0.01);
    validateNumber(item.unit_price, `Article ${index + 1} - Prix unitaire`, 0);
    validateNumber(item.total_price, `Article ${index + 1} - Prix total`, 0);
  });
}

interface FNEResponse {
  success: boolean;
  fne_number?: string;
  message?: string;
  error?: string;
}

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    
    const supabase = createClient(supabaseUrl, supabaseKey);

    const requestData: FNERequest = await req.json();
    
    // CRITICAL: Server-side validation to prevent injection attacks
    try {
      validateFNERequest(requestData);
    } catch (validationError: any) {
      console.error('Validation error:', validationError.message);
      return new Response(JSON.stringify({
        success: false,
        error: `Erreur de validation: ${validationError.message}`,
      }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const { invoiceId, fneApiKey, invoiceData } = requestData;

    console.log('Processing FNE request for invoice:', invoiceId);

    // Log the request (without the API key for security)
    const logData = {
      invoice_id: invoiceId,
      request_data: { ...invoiceData },
      status: 'pending' as const,
    };

    const { data: logEntry } = await supabase
      .from('fne_logs')
      .insert(logData)
      .select()
      .single();

    // Update invoice status to 'sent'
    await supabase
      .from('invoices')
      .update({ 
        fne_status: 'sent',
        fne_submitted_at: new Date().toISOString()
      })
      .eq('id', invoiceId);

    try {
      // Simulate FNE API call to DGI (replace with actual API endpoint)
      const fneApiResponse = await fetch('https://api-fne.dgi.ci/v1/invoices', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${fneApiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          numero_facture: invoiceData.invoice_number,
          date_emission: invoiceData.date_issued,
          montant_total: invoiceData.total_amount,
          nom_client: invoiceData.client_name,
          articles: invoiceData.items.map(item => ({
            designation: item.description,
            quantite: item.quantity,
            prix_unitaire: item.unit_price,
            montant: item.total_price,
          })),
        }),
      });

      const fneResult = await fneApiResponse.json();

      if (fneApiResponse.ok && fneResult.success) {
        // Success - update invoice with FNE number
        await supabase
          .from('invoices')
          .update({
            fne_status: 'validated',
            fne_number: fneResult.numero_fne,
            fne_validated_at: new Date().toISOString(),
          })
          .eq('id', invoiceId);

        // Update log with success
        if (logEntry) {
          await supabase
            .from('fne_logs')
            .update({
              response_data: fneResult,
              status: 'success',
            })
            .eq('id', logEntry.id);
        }

        const response: FNEResponse = {
          success: true,
          fne_number: fneResult.numero_fne,
          message: 'Facture validée avec succès par la DGI',
        };

        return new Response(JSON.stringify(response), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });

      } else {
        throw new Error(fneResult.message || 'Erreur lors de la validation FNE');
      }

    } catch (apiError: any) {
      console.error('FNE API Error:', apiError);

      // Update invoice status to 'rejected'
      await supabase
        .from('invoices')
        .update({
          fne_status: 'rejected',
          fne_rejection_reason: apiError.message,
        })
        .eq('id', invoiceId);

      // Update log with error
      if (logEntry) {
        await supabase
          .from('fne_logs')
          .update({
            status: 'error',
            error_message: apiError.message,
          })
          .eq('id', logEntry.id);
      }

      const response: FNEResponse = {
        success: false,
        error: apiError.message,
      };

      return new Response(JSON.stringify(response), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

  } catch (error: any) {
    console.error('Server Error:', error);
    
    const response: FNEResponse = {
      success: false,
      error: 'Erreur serveur lors du traitement',
    };

    return new Response(JSON.stringify(response), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});