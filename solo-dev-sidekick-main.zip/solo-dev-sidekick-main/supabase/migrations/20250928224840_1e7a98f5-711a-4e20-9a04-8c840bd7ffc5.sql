-- Mettre à jour le profil existant avec la company_id de la société démo
UPDATE public.profiles 
SET company_id = '00000000-0000-0000-0000-000000000001'
WHERE user_id = '73284fff-2b99-405e-8489-2b306b953055';