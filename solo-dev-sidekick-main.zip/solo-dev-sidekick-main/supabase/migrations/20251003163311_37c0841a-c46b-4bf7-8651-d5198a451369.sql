-- Fix user_roles policy to include WITH CHECK so admins can insert/update
DO $$ BEGIN
  DROP POLICY IF EXISTS "Only admins can manage roles" ON public.user_roles;
EXCEPTION WHEN undefined_object THEN NULL; END $$;

CREATE POLICY "Only admins can manage roles"
  ON public.user_roles
  FOR ALL
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));
