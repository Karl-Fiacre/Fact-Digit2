-- Migration pour corriger les problèmes de sécurité critiques Phase 1

-- Note: Pour créer votre premier utilisateur administrateur, exécutez cette commande
-- en remplaçant 'VOTRE_USER_ID' par l'ID de votre compte utilisateur:
-- 
-- INSERT INTO public.user_roles (user_id, role)
-- VALUES ('VOTRE_USER_ID', 'admin')
-- ON CONFLICT (user_id, role) DO NOTHING;
--
-- Pour trouver votre user_id, connectez-vous puis exécutez:
-- SELECT auth.uid();

-- Corriger la politique RLS pour event_registrations_melliamcosmetics
-- Actuellement, tous les utilisateurs authentifiés peuvent voir les données PII
-- On restreint l'accès aux administrateurs uniquement

DROP POLICY IF EXISTS "Only authenticated users can view event registrations" ON public.event_registrations_melliamcosmetics;

CREATE POLICY "Only admins can view event registrations"
  ON public.event_registrations_melliamcosmetics
  FOR SELECT
  USING (public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Only authenticated users can update event registrations" ON public.event_registrations_melliamcosmetics;

CREATE POLICY "Only admins can update event registrations"
  ON public.event_registrations_melliamcosmetics
  FOR UPDATE
  USING (public.has_role(auth.uid(), 'admin'));

-- Ajouter une politique DELETE pour les administrateurs
CREATE POLICY "Only admins can delete event registrations"
  ON public.event_registrations_melliamcosmetics
  FOR DELETE
  USING (public.has_role(auth.uid(), 'admin'));