-- Add FNE-related columns to invoices table
ALTER TABLE public.invoices 
ADD COLUMN fne_number TEXT,
ADD COLUMN fne_status TEXT DEFAULT 'draft' CHECK (fne_status IN ('draft', 'sent', 'validated', 'rejected')),
ADD COLUMN fne_submitted_at TIMESTAMP WITH TIME ZONE,
ADD COLUMN fne_validated_at TIMESTAMP WITH TIME ZONE,
ADD COLUMN fne_rejection_reason TEXT;

-- Create FNE logs table for tracking API communications
CREATE TABLE public.fne_logs (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  invoice_id UUID NOT NULL REFERENCES public.invoices(id) ON DELETE CASCADE,
  request_data JSONB NOT NULL,
  response_data JSONB,
  status TEXT NOT NULL CHECK (status IN ('success', 'error', 'pending')),
  error_message TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on fne_logs table
ALTER TABLE public.fne_logs ENABLE ROW LEVEL SECURITY;

-- Create RLS policy for fne_logs
CREATE POLICY "Users can view their company FNE logs" 
ON public.fne_logs 
FOR SELECT 
USING (invoice_id IN (
  SELECT i.id 
  FROM invoices i 
  JOIN profiles p ON i.company_id = p.company_id 
  WHERE p.user_id = auth.uid()
));

CREATE POLICY "System can insert FNE logs" 
ON public.fne_logs 
FOR INSERT 
WITH CHECK (true);

-- Add indexes for better performance
CREATE INDEX idx_invoices_fne_status ON public.invoices(fne_status);
CREATE INDEX idx_invoices_fne_number ON public.invoices(fne_number);
CREATE INDEX idx_fne_logs_invoice_id ON public.fne_logs(invoice_id);

-- Add trigger for updated_at on invoices when FNE fields change
CREATE OR REPLACE FUNCTION public.update_invoice_fne_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  IF (OLD.fne_status IS DISTINCT FROM NEW.fne_status OR 
      OLD.fne_number IS DISTINCT FROM NEW.fne_number OR
      OLD.fne_submitted_at IS DISTINCT FROM NEW.fne_submitted_at OR
      OLD.fne_validated_at IS DISTINCT FROM NEW.fne_validated_at) THEN
    NEW.updated_at = now();
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_invoice_fne_trigger
  BEFORE UPDATE ON public.invoices
  FOR EACH ROW
  EXECUTE FUNCTION public.update_invoice_fne_timestamp();