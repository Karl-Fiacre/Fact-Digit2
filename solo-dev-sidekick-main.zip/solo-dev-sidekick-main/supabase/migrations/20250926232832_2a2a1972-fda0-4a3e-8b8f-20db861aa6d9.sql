-- Fix profiles table RLS policies to prevent unauthorized access to user personal information

-- Drop existing policies for profiles table to recreate them with better security
DROP POLICY IF EXISTS "Users can view their profile" ON public.profiles;
DROP POLICY IF EXISTS "Users can update their profile" ON public.profiles;
DROP POLICY IF EXISTS "Users can create their profile" ON public.profiles;

-- Create comprehensive RLS policies for profiles table
-- Only authenticated users can access their own profile data
CREATE POLICY "Users can view only their own profile" 
ON public.profiles 
FOR SELECT 
TO authenticated
USING (user_id = auth.uid());

CREATE POLICY "Users can update only their own profile" 
ON public.profiles 
FOR UPDATE 
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can create only their own profile" 
ON public.profiles 
FOR INSERT 
TO authenticated
WITH CHECK (user_id = auth.uid());

-- Explicitly deny all access to anon users for profiles
CREATE POLICY "Deny all access to anonymous users" 
ON public.profiles 
FOR ALL 
TO anon
USING (false);

-- Fix reservations_melliamcosmetics table to restrict access properly
-- Currently any authenticated user can see all reservations which is a privacy issue

-- Drop existing policies for reservations
DROP POLICY IF EXISTS "Only authenticated users can view reservations" ON public.reservations_melliamcosmetics;
DROP POLICY IF EXISTS "Anyone can insert reservations" ON public.reservations_melliamcosmetics;

-- Create better policies for reservations - only system/admin should view all reservations
CREATE POLICY "Allow public to insert reservations" 
ON public.reservations_melliamcosmetics 
FOR INSERT 
TO anon, authenticated
WITH CHECK (true);

-- Only service role can view reservations (for admin purposes)
CREATE POLICY "Only service role can view reservations" 
ON public.reservations_melliamcosmetics 
FOR SELECT 
TO service_role
USING (true);

-- Similar fix for contacts table - only admins should see contact form submissions
DROP POLICY IF EXISTS "Only authenticated users can view contacts" ON public.contacts_melliamcosmetics;
DROP POLICY IF EXISTS "Anyone can insert contacts" ON public.contacts_melliamcosmetics;

CREATE POLICY "Allow public to insert contacts" 
ON public.contacts_melliamcosmetics 
FOR INSERT 
TO anon, authenticated
WITH CHECK (true);

CREATE POLICY "Only service role can view contacts" 
ON public.contacts_melliamcosmetics 
FOR SELECT 
TO service_role
USING (true);