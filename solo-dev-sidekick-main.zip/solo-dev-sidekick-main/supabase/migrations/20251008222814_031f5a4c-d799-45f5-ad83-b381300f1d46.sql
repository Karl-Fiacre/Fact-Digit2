-- Fonction RPC optimisée pour récupérer les statistiques du tableau de bord
CREATE OR REPLACE FUNCTION get_dashboard_stats(p_company_id UUID)
RETURNS TABLE (
  clients_count BIGINT,
  products_count BIGINT,
  invoices_count BIGINT,
  total_revenue NUMERIC,
  total_tva NUMERIC
) 
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    (SELECT COUNT(*) FROM clients WHERE company_id = p_company_id),
    (SELECT COUNT(*) FROM products WHERE company_id = p_company_id),
    (SELECT COUNT(*) FROM invoices WHERE company_id = p_company_id),
    COALESCE((SELECT SUM(total_amount) FROM invoices WHERE company_id = p_company_id), 0),
    COALESCE((SELECT SUM(tva_amount) FROM invoices WHERE company_id = p_company_id), 0);
END;
$$;