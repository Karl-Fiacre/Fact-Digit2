-- Fix security issue: Update functions to set search_path properly
CREATE OR REPLACE FUNCTION public.update_invoice_fne_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  IF (OLD.fne_status IS DISTINCT FROM NEW.fne_status OR 
      OLD.fne_number IS DISTINCT FROM NEW.fne_number OR
      OLD.fne_submitted_at IS DISTINCT FROM NEW.fne_submitted_at OR
      OLD.fne_validated_at IS DISTINCT FROM NEW.fne_validated_at) THEN
    NEW.updated_at = now();
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

-- Also fix the existing handle_updated_at function
CREATE OR REPLACE FUNCTION public.handle_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;