const { contextBridge, ipcRenderer } = require('electron');

// API exposée au renderer process
contextBridge.exposeInMainWorld('electronAPI', {
  // Informations de l'application
  getAppVersion: () => ipcRenderer.invoke('app-version'),
  
  // Dialogues système
  showSaveDialog: (options) => ipcRenderer.invoke('show-save-dialog', options),
  showOpenDialog: (options) => ipcRenderer.invoke('show-open-dialog', options),
  showMessageBox: (options) => ipcRenderer.invoke('show-message-box', options),
  
  // Écouter les actions du menu
  onMenuAction: (callback) => {
    const subscription = (event, action) => callback(action);
    ipcRenderer.on('menu-action', subscription);
    
    return () => {
      ipcRenderer.removeListener('menu-action', subscription);
    };
  },
  
  // Vérifier si on est dans Electron
  isElectron: true,
  
  // Platform info
  platform: process.platform,
  
  // Storage API pour offline
  storage: {
    get: (key) => {
      try {
        const data = localStorage.getItem(key);
        return data ? JSON.parse(data) : null;
      } catch (error) {
        console.error('Storage get error:', error);
        return null;
      }
    },
    set: (key, value) => {
      try {
        localStorage.setItem(key, JSON.stringify(value));
        return true;
      } catch (error) {
        console.error('Storage set error:', error);
        return false;
      }
    },
    remove: (key) => {
      try {
        localStorage.removeItem(key);
        return true;
      } catch (error) {
        console.error('Storage remove error:', error);
        return false;
      }
    },
    clear: () => {
      try {
        localStorage.clear();
        return true;
      } catch (error) {
        console.error('Storage clear error:', error);
        return false;
      }
    }
  }
});