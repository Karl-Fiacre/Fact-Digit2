import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

interface Company {
  id: string;
  name: string;
  address?: string;
  rccm?: string;
  numero_cc?: string;
  phone?: string;
  email?: string;
  website?: string;
  logo_url?: string;
}

interface Client {
  name: string;
  email?: string;
  phone?: string;
  address?: string;
  rccm?: string;
  numero_cc?: string;
}

interface InvoiceItem {
  description: string;
  quantity: number;
  unit_price: number;
  total_price: number;
  tva_rate?: number;
}

interface Invoice {
  id: string;
  invoice_number: string;
  date_issued: string;
  date_due?: string;
  subtotal?: number;
  tva_amount?: number;
  total_amount: number;
  status: string;
  fne_status?: string;
  fne_number?: string;
  notes?: string;
  terms?: string;
  client: Client;
  invoice_items: InvoiceItem[];
}

// Fonction pour créer le HTML de la facture
const createInvoiceHTML = (invoice: Invoice, company: Company): string => {
  const subtotal = invoice.subtotal || invoice.invoice_items.reduce((sum, item) => 
    sum + (item.quantity * item.unit_price), 0
  );
  
  const tvaAmount = invoice.tva_amount || invoice.invoice_items.reduce((sum, item) => 
    sum + (item.quantity * item.unit_price * ((item.tva_rate || 18) / 100)), 0
  );

  return `
    <div style="padding: 40px; background: white; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; max-width: 800px;">
      <!-- En-tête -->
      <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 30px;">
        <div>
          ${company.logo_url ? `<img src="${company.logo_url}" alt="Logo" style="height: 64px; margin-bottom: 16px;" />` : ''}
          <h2 style="font-size: 24px; font-weight: bold; color: #111827; margin: 0 0 8px 0;">${company.name}</h2>
          ${company.address ? `<p style="font-size: 14px; color: #4b5563; margin: 4px 0;">${company.address}</p>` : ''}
          ${company.phone ? `<p style="font-size: 14px; color: #4b5563; margin: 4px 0;">Tél: ${company.phone}</p>` : ''}
          ${company.email ? `<p style="font-size: 14px; color: #4b5563; margin: 4px 0;">Email: ${company.email}</p>` : ''}
          ${company.rccm ? `<p style="font-size: 14px; color: #4b5563; margin: 4px 0;">RCCM: ${company.rccm}</p>` : ''}
          ${company.numero_cc ? `<p style="font-size: 14px; color: #4b5563; margin: 4px 0;">N° CC: ${company.numero_cc}</p>` : ''}
        </div>
        <div style="text-align: right;">
          <h3 style="font-size: 30px; font-weight: bold; color: hsl(221.2 83.2% 53.3%); margin: 0 0 8px 0;">FACTURE</h3>
          <p style="font-size: 18px; font-weight: 600; margin: 8px 0;">${invoice.invoice_number}</p>
          ${invoice.fne_status === 'validated' ? '<div style="margin-top: 8px;"><span style="display: inline-block; padding: 4px 12px; background: #dcfce7; color: #166534; border-radius: 9999px; font-size: 12px; font-weight: 500;">Validée DGI</span></div>' : ''}
        </div>
      </div>

      <!-- Separator -->
      <div style="height: 1px; background: #e5e7eb; margin: 24px 0;"></div>

      <!-- Informations client et dates -->
      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 32px; margin-bottom: 30px;">
        <div>
          <h4 style="font-weight: 600; color: #111827; margin: 0 0 8px 0;">Facturé à:</h4>
          <p style="font-weight: 500; margin: 4px 0;">${invoice.client.name}</p>
          ${invoice.client.address ? `<p style="font-size: 14px; color: #4b5563; margin: 4px 0;">${invoice.client.address}</p>` : ''}
          ${invoice.client.phone ? `<p style="font-size: 14px; color: #4b5563; margin: 4px 0;">Tél: ${invoice.client.phone}</p>` : ''}
          ${invoice.client.email ? `<p style="font-size: 14px; color: #4b5563; margin: 4px 0;">Email: ${invoice.client.email}</p>` : ''}
          ${invoice.client.rccm ? `<p style="font-size: 14px; color: #4b5563; margin: 4px 0;">RCCM: ${invoice.client.rccm}</p>` : ''}
          ${invoice.client.numero_cc ? `<p style="font-size: 14px; color: #4b5563; margin: 4px 0;">N° CC: ${invoice.client.numero_cc}</p>` : ''}
        </div>
        <div>
          <div style="display: flex; justify-content: space-between; margin: 4px 0;">
            <span style="font-size: 14px; color: #4b5563;">Date d'émission:</span>
            <span style="font-weight: 500;">${new Date(invoice.date_issued).toLocaleDateString('fr-FR')}</span>
          </div>
          ${invoice.date_due ? `
            <div style="display: flex; justify-content: space-between; margin: 4px 0;">
              <span style="font-size: 14px; color: #4b5563;">Date d'échéance:</span>
              <span style="font-weight: 500;">${new Date(invoice.date_due).toLocaleDateString('fr-FR')}</span>
            </div>
          ` : ''}
          ${invoice.fne_number ? `
            <div style="display: flex; justify-content: space-between; margin: 4px 0;">
              <span style="font-size: 14px; color: #4b5563;">N° FNE:</span>
              <span style="font-weight: 500; color: #15803d;">${invoice.fne_number}</span>
            </div>
          ` : ''}
        </div>
      </div>

      <!-- Separator -->
      <div style="height: 1px; background: #e5e7eb; margin: 24px 0;"></div>

      <!-- Tableau des articles -->
      <table style="width: 100%; border-collapse: collapse; margin-bottom: 30px;">
        <thead>
          <tr style="border-bottom: 2px solid #d1d5db;">
            <th style="text-align: left; padding: 12px 0; font-weight: 600; color: #111827;">Description</th>
            <th style="text-align: center; padding: 12px 0; font-weight: 600; color: #111827;">Qté</th>
            <th style="text-align: right; padding: 12px 0; font-weight: 600; color: #111827;">Prix unit.</th>
            <th style="text-align: right; padding: 12px 0; font-weight: 600; color: #111827;">TVA</th>
            <th style="text-align: right; padding: 12px 0; font-weight: 600; color: #111827;">Total</th>
          </tr>
        </thead>
        <tbody>
          ${invoice.invoice_items.map(item => `
            <tr style="border-bottom: 1px solid #e5e7eb;">
              <td style="padding: 12px 0; color: #1f2937;">${item.description}</td>
              <td style="text-align: center; padding: 12px 0; color: #1f2937;">${item.quantity}</td>
              <td style="text-align: right; padding: 12px 0; color: #1f2937;">${item.unit_price.toLocaleString('fr-FR')} FCFA</td>
              <td style="text-align: right; padding: 12px 0; color: #1f2937;">${item.tva_rate || 18}%</td>
              <td style="text-align: right; padding: 12px 0; font-weight: 500; color: #111827;">${item.total_price.toLocaleString('fr-FR')} FCFA</td>
            </tr>
          `).join('')}
        </tbody>
      </table>

      <!-- Totaux -->
      <div style="display: flex; justify-content: flex-end; margin-bottom: 30px;">
        <div style="width: 320px;">
          <div style="display: flex; justify-content: space-between; color: #374151; margin: 8px 0;">
            <span>Sous-total (HT):</span>
            <span style="font-weight: 500;">${subtotal.toLocaleString('fr-FR')} FCFA</span>
          </div>
          <div style="display: flex; justify-content: space-between; color: #374151; margin: 8px 0;">
            <span>TVA:</span>
            <span style="font-weight: 500;">${tvaAmount.toLocaleString('fr-FR')} FCFA</span>
          </div>
          <div style="height: 1px; background: #e5e7eb; margin: 8px 0;"></div>
          <div style="display: flex; justify-content: space-between; font-size: 18px; font-weight: bold; color: #111827; margin: 8px 0;">
            <span>Total (TTC):</span>
            <span>${invoice.total_amount.toLocaleString('fr-FR')} FCFA</span>
          </div>
        </div>
      </div>

      ${invoice.notes || invoice.terms ? `
        <div style="height: 1px; background: #e5e7eb; margin: 24px 0;"></div>
        <div style="margin-bottom: 30px;">
          ${invoice.notes ? `
            <div style="margin-bottom: 16px;">
              <h5 style="font-weight: 600; color: #111827; margin: 0 0 8px 0;">Notes:</h5>
              <p style="font-size: 14px; color: #374151; white-space: pre-wrap; margin: 0;">${invoice.notes}</p>
            </div>
          ` : ''}
          ${invoice.terms ? `
            <div>
              <h5 style="font-weight: 600; color: #111827; margin: 0 0 8px 0;">Conditions de paiement:</h5>
              <p style="font-size: 14px; color: #374151; white-space: pre-wrap; margin: 0;">${invoice.terms}</p>
            </div>
          ` : ''}
        </div>
      ` : ''}

      <!-- Pied de page -->
      <div style="padding-top: 16px; border-top: 1px solid #e5e7eb;">
        <p style="font-size: 12px; text-align: center; color: #6b7280; margin: 0;">
          Merci pour votre confiance. Cette facture a été générée par Fact-Digit.
        </p>
      </div>
    </div>
  `;
};

export const generateInvoicePDF = async (
  invoice: Invoice,
  company: Company
): Promise<Blob> => {
  // Créer un élément temporaire pour contenir le HTML
  const container = document.createElement('div');
  container.style.position = 'absolute';
  container.style.left = '-9999px';
  container.style.top = '0';
  container.style.width = '800px';
  container.style.background = 'white';
  
  container.innerHTML = createInvoiceHTML(invoice, company);
  document.body.appendChild(container);

  try {
    // Convertir le HTML en canvas
    const canvas = await html2canvas(container, {
      scale: 2,
      useCORS: true,
      logging: false,
      backgroundColor: '#ffffff'
    });

    // Créer le PDF
    const imgData = canvas.toDataURL('image/png');
    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4'
    });

    const pdfWidth = pdf.internal.pageSize.getWidth();
    const pdfHeight = pdf.internal.pageSize.getHeight();
    const imgWidth = canvas.width;
    const imgHeight = canvas.height;
    const ratio = Math.min(pdfWidth / imgWidth, pdfHeight / imgHeight);
    const imgX = (pdfWidth - imgWidth * ratio) / 2;
    const imgY = 0;

    pdf.addImage(imgData, 'PNG', imgX, imgY, imgWidth * ratio, imgHeight * ratio);

    const pdfBlob = pdf.output('blob');
    return pdfBlob;
  } finally {
    // Nettoyer l'élément temporaire
    document.body.removeChild(container);
  }
};