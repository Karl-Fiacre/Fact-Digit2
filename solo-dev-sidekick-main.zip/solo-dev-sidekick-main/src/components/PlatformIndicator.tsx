import { useEffect, useState } from 'react';
import { Badge } from '@/components/ui/badge';
import { Monitor, Smartphone, Globe, Box } from 'lucide-react';
import { getPlatformInfo } from '@/lib/platformDetect';

export const PlatformIndicator = () => {
  const [platformInfo, setPlatformInfo] = useState(getPlatformInfo());

  useEffect(() => {
    setPlatformInfo(getPlatformInfo());
  }, []);

  const getPlatformIcon = () => {
    switch (platformInfo.platform) {
      case 'electron':
        return <Monitor className="h-3 w-3" />;
      case 'tauri':
        return <Box className="h-3 w-3" />;
      case 'capacitor':
        return <Smartphone className="h-3 w-3" />;
      default:
        return <Globe className="h-3 w-3" />;
    }
  };

  const getPlatformLabel = () => {
    switch (platformInfo.platform) {
      case 'electron':
        return 'Desktop (Electron)';
      case 'tauri':
        return 'Desktop (Tauri)';
      case 'capacitor':
        return 'Mobile';
      default:
        return 'Web';
    }
  };

  const getPlatformVariant = () => {
    if (platformInfo.isDesktop) return 'default';
    if (platformInfo.isMobile) return 'secondary';
    return 'outline';
  };

  if (process.env.NODE_ENV === 'production' && platformInfo.platform === 'web') {
    return null; // Ne pas afficher en production web
  }

  return (
    <Badge variant={getPlatformVariant()} className="flex items-center gap-1 text-xs">
      {getPlatformIcon()}
      <span>{getPlatformLabel()}</span>
      {platformInfo.supportsOffline && (
        <span className="ml-1 text-green-600">●</span>
      )}
    </Badge>
  );
};
