import React, { useState } from "react";
import { z } from "zod";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Shield, AlertTriangle } from "lucide-react";

const fneApiKeySchema = z.string()
  .min(10, "La clé API doit contenir au moins 10 caractères")
  .max(500, "La clé API ne peut pas dépasser 500 caractères")
  .trim();

interface FNEDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (apiKey: string) => void;
  loading: boolean;
}

export function FNEDialog({ open, onOpenChange, onSubmit, loading }: FNEDialogProps) {
  const [apiKey, setApiKey] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    
    // Validate API key with zod
    const validation = fneApiKeySchema.safeParse(apiKey);
    if (!validation.success) {
      setError(validation.error.errors[0].message);
      return;
    }
    
    onSubmit(validation.data);
    setApiKey(""); // Clear immediately for security
  };

  const handleClose = () => {
    setApiKey(""); // Clear on close for security
    setError("");
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5 text-blue-600" />
            Générer Facture Normalisée FNE
          </DialogTitle>
          <DialogDescription>
            Saisissez votre clé API FNE pour transmettre cette facture à la DGI.
          </DialogDescription>
        </DialogHeader>

        <Alert>
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            <strong>Sécurité :</strong> Votre clé API ne sera utilisée que pour cette transaction 
            et ne sera jamais stockée dans notre système.
          </AlertDescription>
        </Alert>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="fne-api-key">Clé API FNE</Label>
            <Input
              id="fne-api-key"
              type="password"
              placeholder="Entrez votre clé API FNE"
              value={apiKey}
              onChange={(e) => {
                setApiKey(e.target.value);
                setError(""); // Clear error on input change
              }}
              required
              minLength={10}
              maxLength={500}
              className="w-full"
              autoComplete="off"
            />
            {error && (
              <p className="text-sm text-destructive">{error}</p>
            )}
            <p className="text-sm text-muted-foreground">
              Cette clé est fournie par la DGI de Côte d'Ivoire
            </p>
          </div>

          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={handleClose}
              disabled={loading}
            >
              Annuler
            </Button>
            <Button
              type="submit"
              disabled={!apiKey.trim() || loading}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {loading ? "Transmission..." : "Générer FNE"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}