import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Download, FileText, Shield, Eye, CheckCircle, XCircle, Clock, Edit, Trash2 } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { FNEDialog } from "./FNEDialog";
import { InvoicePreviewDialog } from "./InvoicePreviewDialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { generateInvoicePDF } from "@/utils/pdfGenerator";

interface Invoice {
  id: string;
  invoice_number: string;
  date_issued: string;
  total_amount: number;
  status: string;
  fne_status?: string;
  fne_number?: string;
  fne_rejection_reason?: string;
  client: {
    name: string;
  };
  invoice_items: Array<{
    description: string;
    quantity: number;
    unit_price: number;
    total_price: number;
  }>;
}

interface InvoiceCardProps {
  invoice: Invoice;
  onUpdate?: () => void;
  onDelete?: () => void;
}

export function InvoiceCard({ invoice, onUpdate, onDelete }: InvoiceCardProps) {
  const [fneDialogOpen, setFneDialogOpen] = useState(false);
  const [previewOpen, setPreviewOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [company, setCompany] = useState<any>(null);
  const { toast } = useToast();
  const navigate = useNavigate();

  const getFneStatusBadge = (status?: string) => {
    switch (status) {
      case 'validated':
        return <Badge className="bg-green-100 text-green-800"><CheckCircle className="h-3 w-3 mr-1" />Validée DGI</Badge>;
      case 'rejected':
        return <Badge className="bg-red-100 text-red-800"><XCircle className="h-3 w-3 mr-1" />Rejetée</Badge>;
      case 'sent':
        return <Badge className="bg-blue-100 text-blue-800"><Clock className="h-3 w-3 mr-1" />En attente</Badge>;
      default:
        return <Badge variant="secondary">Brouillon</Badge>;
    }
  };

  const handleGenerateFNE = async (fneApiKey: string) => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('fne-integration', {
        body: {
          invoiceId: invoice.id,
          fneApiKey,
          invoiceData: {
            invoice_number: invoice.invoice_number,
            date_issued: invoice.date_issued,
            total_amount: invoice.total_amount,
            client_name: invoice.client.name,
            items: invoice.invoice_items,
          },
        },
      });

      if (error) throw error;

      if (data.success) {
        toast({
          title: "Succès",
          description: `Facture validée par la DGI. Numéro FNE: ${data.fne_number}`,
        });
      } else {
        toast({
          title: "Erreur",
          description: data.error || "Erreur lors de la génération FNE",
          variant: "destructive",
        });
      }

      onUpdate?.();
      setFneDialogOpen(false);
    } catch (error: any) {
      console.error('FNE Generation Error:', error);
      toast({
        title: "Erreur",
        description: "Erreur lors de la communication avec la DGI",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const loadCompanyInfo = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const { data: profile } = await supabase
      .from('profiles')
      .select('company_id')
      .eq('user_id', user.id)
      .maybeSingle();

    if (profile?.company_id) {
      const { data: companyData } = await supabase
        .from('companies')
        .select('*')
        .eq('id', profile.company_id)
        .maybeSingle();
      
      if (companyData) {
        setCompany(companyData);
      }
    }
  };

  const handleViewInvoice = async () => {
    if (!company) {
      await loadCompanyInfo();
    }
    setPreviewOpen(true);
  };

  const handleDownloadPDF = async () => {
    try {
      setLoading(true);
      
      if (!company) {
        await loadCompanyInfo();
      }

      if (!company) {
        toast({
          title: "Erreur",
          description: "Impossible de récupérer les informations de l'entreprise",
          variant: "destructive"
        });
        return;
      }

      // Générer le PDF
      const pdfBlob = await generateInvoicePDF(invoice, company);
      
      // Télécharger le fichier
      const url = URL.createObjectURL(pdfBlob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `Facture-${invoice.invoice_number}.pdf`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      toast({
        title: "Succès",
        description: "PDF généré et téléchargé avec succès",
      });
    } catch (error) {
      console.error('Erreur génération PDF:', error);
      toast({
        title: "Erreur",
        description: "Erreur lors de la génération du PDF",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async () => {
    try {
      setLoading(true);
      
      // Supprimer d'abord les items de la facture
      const { error: itemsError } = await supabase
        .from('invoice_items')
        .delete()
        .eq('invoice_id', invoice.id);

      if (itemsError) throw itemsError;

      // Supprimer ensuite la facture
      const { error: invoiceError } = await supabase
        .from('invoices')
        .delete()
        .eq('id', invoice.id);

      if (invoiceError) throw invoiceError;

      toast({
        title: "Succès",
        description: "Facture supprimée avec succès",
      });

      onDelete?.();
    } catch (error) {
      console.error('Erreur suppression:', error);
      toast({
        title: "Erreur",
        description: "Erreur lors de la suppression de la facture",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
      setDeleteDialogOpen(false);
    }
  };

  return (
    <>
      <Card className="w-full">
        <CardHeader>
          <div className="flex justify-between items-start">
            <div>
              <CardTitle className="text-lg">{invoice.invoice_number}</CardTitle>
              <p className="text-sm text-muted-foreground">
                Client: {invoice.client.name}
              </p>
              <p className="text-sm text-muted-foreground">
                Date: {new Date(invoice.date_issued).toLocaleDateString('fr-FR')}
              </p>
            </div>
            <div className="text-right">
              <p className="text-xl font-bold">{invoice.total_amount.toLocaleString('fr-FR')} FCFA</p>
              <div className="mt-2 space-y-1">
                <Badge variant={invoice.status === 'paid' ? 'default' : 'secondary'}>
                  {invoice.status === 'paid' ? 'Payée' : 'En attente'}
                </Badge>
                {getFneStatusBadge(invoice.fne_status)}
              </div>
            </div>
          </div>
          
          {invoice.fne_number && (
            <div className="mt-3 p-3 bg-green-50 rounded-lg">
              <p className="text-sm font-medium text-green-800">
                Numéro FNE: {invoice.fne_number}
              </p>
            </div>
          )}
          
          {invoice.fne_rejection_reason && (
            <div className="mt-3 p-3 bg-red-50 rounded-lg">
              <p className="text-sm font-medium text-red-800">
                Motif de rejet: {invoice.fne_rejection_reason}
              </p>
            </div>
          )}
        </CardHeader>
        
        <CardContent>
          <div className="flex gap-2 flex-wrap">
            {(invoice.status === 'draft' || invoice.status === 'pending') && invoice.fne_status !== 'validated' && (
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => navigate(`/invoices/edit/${invoice.id}`)}
              >
                <Edit className="h-4 w-4 mr-2" />
                Modifier
              </Button>
            )}
            
            <Button 
              variant="outline" 
              size="sm"
              onClick={handleViewInvoice}
            >
              <Eye className="h-4 w-4 mr-2" />
              Voir
            </Button>
            
            <Button 
              variant="outline" 
              size="sm" 
              onClick={handleDownloadPDF}
              disabled={loading}
            >
              <Download className="h-4 w-4 mr-2" />
              {loading ? 'Génération...' : 'PDF'}
            </Button>
            
            {invoice.fne_status !== 'validated' && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => setFneDialogOpen(true)}
                disabled={loading || invoice.fne_status === 'sent'}
                className="bg-blue-50 border-blue-200 text-blue-700 hover:bg-blue-100"
              >
                <Shield className="h-4 w-4 mr-2" />
                {invoice.fne_status === 'sent' ? 'En cours...' : 'Générer FNE'}
              </Button>
            )}
            
            {invoice.fne_status !== 'validated' && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => setDeleteDialogOpen(true)}
                disabled={loading}
                className="bg-red-50 border-red-200 text-red-700 hover:bg-red-100"
              >
                <Trash2 className="h-4 w-4 mr-2" />
                Supprimer
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      <FNEDialog
        open={fneDialogOpen}
        onOpenChange={setFneDialogOpen}
        onSubmit={handleGenerateFNE}
        loading={loading}
      />

      <InvoicePreviewDialog
        open={previewOpen}
        onOpenChange={setPreviewOpen}
        invoice={invoice}
        company={company}
      />

      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmer la suppression</AlertDialogTitle>
            <AlertDialogDescription>
              Êtes-vous sûr de vouloir supprimer la facture {invoice.invoice_number} ? 
              Cette action est irréversible.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Annuler</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleDelete}
              className="bg-red-600 hover:bg-red-700"
            >
              Supprimer
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}