import React from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { useIsMobile } from "@/hooks/use-mobile";

interface InvoicePreviewDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  invoice: {
    invoice_number: string;
    date_issued: string;
    date_due?: string;
    status: string;
    fne_status?: string;
    fne_number?: string;
    subtotal?: number;
    tva_amount?: number;
    total_amount: number;
    notes?: string;
    terms?: string;
    client: {
      name: string;
      email?: string;
      phone?: string;
      address?: string;
      rccm?: string;
      numero_cc?: string;
    };
    invoice_items: Array<{
      description: string;
      quantity: number;
      unit_price: number;
      tva_rate?: number;
      total_price: number;
    }>;
  };
  company?: {
    name: string;
    address?: string;
    rccm?: string;
    numero_cc?: string;
    phone?: string;
    email?: string;
    logo_url?: string;
  };
}

export function InvoicePreviewDialog({ 
  open, 
  onOpenChange, 
  invoice,
  company 
}: InvoicePreviewDialogProps) {
  const isMobile = useIsMobile();

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className={`${isMobile ? 'max-w-[95vw] w-full h-[95vh] p-2' : 'max-w-4xl max-h-[90vh]'} overflow-y-auto`}>
        <DialogHeader className={isMobile ? 'px-2' : ''}>
          <DialogTitle className={isMobile ? 'text-base' : ''}>Aperçu de la facture</DialogTitle>
        </DialogHeader>

        <div className={`space-y-4 ${isMobile ? 'p-2 text-xs' : 'p-6'} bg-white`}>
          {/* En-tête de l'entreprise */}
          <div className={`flex ${isMobile ? 'flex-col gap-4' : 'justify-between items-start'}`}>
            <div>
              {company?.logo_url && (
                <img src={company.logo_url} alt="Logo" className={isMobile ? 'h-10 mb-2' : 'h-16 mb-4'} />
              )}
              <h2 className={`font-bold text-gray-900 ${isMobile ? 'text-lg' : 'text-2xl'}`}>
                {company?.name || "Mon Entreprise"}
              </h2>
              {company?.address && <p className={`text-gray-600 ${isMobile ? 'text-xs' : 'text-sm'}`}>{company.address}</p>}
              {company?.phone && <p className={`text-gray-600 ${isMobile ? 'text-xs' : 'text-sm'}`}>Tél: {company.phone}</p>}
              {company?.email && <p className={`text-gray-600 ${isMobile ? 'text-xs' : 'text-sm'}`}>Email: {company.email}</p>}
              {company?.rccm && <p className={`text-gray-600 ${isMobile ? 'text-xs' : 'text-sm'}`}>RCCM: {company.rccm}</p>}
              {company?.numero_cc && <p className={`text-gray-600 ${isMobile ? 'text-xs' : 'text-sm'}`}>N° CC: {company.numero_cc}</p>}
            </div>
            <div className={isMobile ? '' : 'text-right'}>
              <h3 className={`font-bold text-primary ${isMobile ? 'text-xl' : 'text-3xl'}`}>FACTURE</h3>
              <p className={`font-semibold mt-2 ${isMobile ? 'text-sm' : 'text-lg'}`}>{invoice.invoice_number}</p>
              <div className={`mt-2 flex gap-2 ${isMobile ? 'flex-wrap' : 'justify-end'}`}>
                <Badge variant={invoice.status === 'paid' ? 'default' : 'secondary'} className={isMobile ? 'text-xs' : ''}>
                  {invoice.status === 'paid' ? 'Payée' : 'En attente'}
                </Badge>
                {invoice.fne_status === 'validated' && (
                  <Badge className={`bg-green-100 text-green-800 ${isMobile ? 'text-xs' : ''}`}>Validée DGI</Badge>
                )}
              </div>
            </div>
          </div>

          <Separator />

          {/* Informations client */}
          <div className={`grid ${isMobile ? 'grid-cols-1 gap-4' : 'grid-cols-2 gap-8'}`}>
            <div>
              <h4 className={`font-semibold text-gray-900 mb-2 ${isMobile ? 'text-sm' : ''}`}>Facturé à:</h4>
              <p className={`font-medium ${isMobile ? 'text-xs' : ''}`}>{invoice.client.name}</p>
              {invoice.client.address && <p className={`text-gray-600 ${isMobile ? 'text-xs' : 'text-sm'}`}>{invoice.client.address}</p>}
              {invoice.client.phone && <p className={`text-gray-600 ${isMobile ? 'text-xs' : 'text-sm'}`}>Tél: {invoice.client.phone}</p>}
              {invoice.client.email && <p className={`text-gray-600 ${isMobile ? 'text-xs' : 'text-sm'}`}>Email: {invoice.client.email}</p>}
              {invoice.client.rccm && <p className={`text-gray-600 ${isMobile ? 'text-xs' : 'text-sm'}`}>RCCM: {invoice.client.rccm}</p>}
              {invoice.client.numero_cc && <p className={`text-gray-600 ${isMobile ? 'text-xs' : 'text-sm'}`}>N° CC: {invoice.client.numero_cc}</p>}
            </div>
            <div>
              <div className="space-y-1">
                <div className="flex justify-between">
                  <span className={`text-gray-600 ${isMobile ? 'text-xs' : 'text-sm'}`}>Date d'émission:</span>
                  <span className={`font-medium ${isMobile ? 'text-xs' : ''}`}>{new Date(invoice.date_issued).toLocaleDateString('fr-FR')}</span>
                </div>
                {invoice.date_due && (
                  <div className="flex justify-between">
                    <span className={`text-gray-600 ${isMobile ? 'text-xs' : 'text-sm'}`}>Date d'échéance:</span>
                    <span className={`font-medium ${isMobile ? 'text-xs' : ''}`}>{new Date(invoice.date_due).toLocaleDateString('fr-FR')}</span>
                  </div>
                )}
                {invoice.fne_number && (
                  <div className="flex justify-between">
                    <span className={`text-gray-600 ${isMobile ? 'text-xs' : 'text-sm'}`}>N° FNE:</span>
                    <span className={`font-medium text-green-700 ${isMobile ? 'text-xs' : ''}`}>{invoice.fne_number}</span>
                  </div>
                )}
              </div>
            </div>
          </div>

          <Separator />

          {/* Articles */}
          <div className={isMobile ? 'overflow-x-auto -mx-2' : ''}>
            <table className={`w-full ${isMobile ? 'text-xs' : ''}`}>
              <thead>
                <tr className="border-b-2 border-gray-300">
                  <th className={`text-left font-semibold text-gray-900 ${isMobile ? 'py-2 text-xs' : 'py-3'}`}>Description</th>
                  <th className={`text-center font-semibold text-gray-900 ${isMobile ? 'py-2 text-xs px-1' : 'py-3'}`}>Qté</th>
                  {!isMobile && <th className="text-right py-3 font-semibold text-gray-900">Prix unit.</th>}
                  {!isMobile && <th className="text-right py-3 font-semibold text-gray-900">TVA</th>}
                  <th className={`text-right font-semibold text-gray-900 ${isMobile ? 'py-2 text-xs' : 'py-3'}`}>Total</th>
                </tr>
              </thead>
              <tbody>
                {invoice.invoice_items.map((item, index) => (
                  <tr key={index} className="border-b border-gray-200">
                    <td className={`text-gray-800 ${isMobile ? 'py-2 text-xs' : 'py-3'}`}>{item.description}</td>
                    <td className={`text-center text-gray-800 ${isMobile ? 'py-2 text-xs px-1' : 'py-3'}`}>{item.quantity}</td>
                    {!isMobile && (
                      <td className="py-3 text-right text-gray-800">
                        {item.unit_price.toLocaleString('fr-FR')} FCFA
                      </td>
                    )}
                    {!isMobile && (
                      <td className="py-3 text-right text-gray-800">
                        {item.tva_rate || 18}%
                      </td>
                    )}
                    <td className={`text-right font-medium text-gray-900 ${isMobile ? 'py-2 text-xs' : 'py-3'}`}>
                      {item.total_price.toLocaleString('fr-FR')} FCFA
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Totaux */}
          <div className="flex justify-end">
            <div className={`space-y-2 ${isMobile ? 'w-full' : 'w-80'}`}>
              <div className={`flex justify-between text-gray-700 ${isMobile ? 'text-xs' : ''}`}>
                <span>Sous-total (HT):</span>
                <span className="font-medium">
                  {(invoice.subtotal || invoice.invoice_items.reduce((sum, item) => 
                    sum + (item.quantity * item.unit_price), 0
                  )).toLocaleString('fr-FR')} FCFA
                </span>
              </div>
              <div className={`flex justify-between text-gray-700 ${isMobile ? 'text-xs' : ''}`}>
                <span>TVA:</span>
                <span className="font-medium">
                  {(invoice.tva_amount || invoice.invoice_items.reduce((sum, item) => 
                    sum + (item.quantity * item.unit_price * ((item.tva_rate || 18) / 100)), 0
                  )).toLocaleString('fr-FR')} FCFA
                </span>
              </div>
              <Separator />
              <div className={`flex justify-between font-bold text-gray-900 ${isMobile ? 'text-sm' : 'text-lg'}`}>
                <span>Total (TTC):</span>
                <span>{invoice.total_amount.toLocaleString('fr-FR')} FCFA</span>
              </div>
            </div>
          </div>

          {/* Notes et conditions */}
          {(invoice.notes || invoice.terms) && (
            <>
              <Separator />
              <div className={`space-y-${isMobile ? '2' : '4'}`}>
                {invoice.notes && (
                  <div>
                    <h5 className={`font-semibold text-gray-900 mb-2 ${isMobile ? 'text-xs' : ''}`}>Notes:</h5>
                    <p className={`text-gray-700 whitespace-pre-wrap ${isMobile ? 'text-xs' : 'text-sm'}`}>{invoice.notes}</p>
                  </div>
                )}
                {invoice.terms && (
                  <div>
                    <h5 className={`font-semibold text-gray-900 mb-2 ${isMobile ? 'text-xs' : ''}`}>Conditions de paiement:</h5>
                    <p className={`text-gray-700 whitespace-pre-wrap ${isMobile ? 'text-xs' : 'text-sm'}`}>{invoice.terms}</p>
                  </div>
                )}
              </div>
            </>
          )}

          {/* Pied de page */}
          <div className={`border-t border-gray-200 ${isMobile ? 'pt-2' : 'pt-4'}`}>
            <p className={`text-center text-gray-500 ${isMobile ? 'text-[10px]' : 'text-xs'}`}>
              Merci pour votre confiance. Cette facture a été générée par Fact-Digit.
            </p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
