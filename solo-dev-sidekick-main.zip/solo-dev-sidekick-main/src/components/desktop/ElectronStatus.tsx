import React from 'react';
import { useElectronSync } from '@/hooks/useElectronSync';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Monitor, Wifi, WifiOff, RefreshCw, Download, Upload } from 'lucide-react';

const ElectronStatus = () => {
  const { 
    isElectron, 
    isOnline, 
    isSyncing, 
    syncWithServer, 
    lastSync,
    electronData 
  } = useElectronSync();

  if (!isElectron) return null;

  const formatLastSync = (timestamp: number) => {
    if (!timestamp) return 'Jamais';
    const date = new Date(timestamp);
    return date.toLocaleString('fr-FR');
  };

  return (
    <Card className="border-primary/20">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-sm">
          <Monitor size={16} />
          Mode Desktop
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {/* Statut de connexion */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            {isOnline ? (
              <Wifi size={16} className="text-green-500" />
            ) : (
              <WifiOff size={16} className="text-red-500" />
            )}
            <span className="text-sm">
              {isOnline ? 'En ligne' : 'Hors ligne'}
            </span>
          </div>
          <Badge variant={isOnline ? 'default' : 'secondary'}>
            {isOnline ? 'Connecté' : 'Mode offline'}
          </Badge>
        </div>

        {/* Actions en attente */}
        {electronData.pendingActions.length > 0 && (
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">
              Actions en attente
            </span>
            <Badge variant="outline">
              {electronData.pendingActions.length}
            </Badge>
          </div>
        )}

        {/* Dernière synchronisation */}
        <div className="flex items-center justify-between">
          <span className="text-sm text-muted-foreground">
            Dernière sync
          </span>
          <span className="text-xs">
            {formatLastSync(lastSync)}
          </span>
        </div>

        {/* Bouton de synchronisation */}
        <Button
          onClick={syncWithServer}
          disabled={!isOnline || isSyncing}
          size="sm"
          className="w-full"
          variant={electronData.pendingActions.length > 0 ? 'default' : 'outline'}
        >
          {isSyncing ? (
            <>
              <RefreshCw size={14} className="mr-2 animate-spin" />
              Synchronisation...
            </>
          ) : (
            <>
              {electronData.pendingActions.length > 0 ? (
                <Upload size={14} className="mr-2" />
              ) : (
                <Download size={14} className="mr-2" />
              )}
              Synchroniser
            </>
          )}
        </Button>

        {/* Données locales */}
        <div className="grid grid-cols-3 gap-2 text-xs text-muted-foreground">
          <div className="text-center">
            <div className="font-medium">{electronData.invoices.length}</div>
            <div>Factures</div>
          </div>
          <div className="text-center">
            <div className="font-medium">{electronData.clients.length}</div>
            <div>Clients</div>
          </div>
          <div className="text-center">
            <div className="font-medium">{electronData.products.length}</div>
            <div>Produits</div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default ElectronStatus;