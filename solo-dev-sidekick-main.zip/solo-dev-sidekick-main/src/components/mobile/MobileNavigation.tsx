import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Home, FileText, Users, Package, Settings, Menu } from 'lucide-react';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';

const MobileNavigation = () => {
  const location = useLocation();

  const navItems = [
    { icon: Home, label: 'Dashboard', path: '/dashboard' },
    { icon: FileText, label: 'Factures', path: '/invoices' },
    { icon: Users, label: 'Clients', path: '/clients' },
    { icon: Package, label: 'Produits', path: '/products' },
    { icon: Settings, label: 'Paramètres', path: '/settings' }
  ];

  const NavContent = () => (
    <div className="flex flex-col space-y-4 p-4">
      <div className="mb-6">
        <h2 className="text-xl font-bold text-primary">Fact-Digit</h2>
        <p className="text-sm text-muted-foreground">Gestion de facturation</p>
      </div>
      {navItems.map((item) => {
        const isActive = location.pathname === item.path;
        return (
          <Link
            key={item.path}
            to={item.path}
            className={`flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${
              isActive 
                ? 'bg-primary text-primary-foreground' 
                : 'text-muted-foreground hover:bg-accent hover:text-accent-foreground'
            }`}
          >
            <item.icon size={20} />
            <span className="font-medium">{item.label}</span>
          </Link>
        );
      })}
    </div>
  );

  return (
    <>
      {/* Navigation mobile en drawer */}
      <div className="md:hidden fixed top-0 left-0 right-0 z-50 bg-background border-b">
        <div className="flex items-center justify-between p-3 sm:p-4">
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon">
                <Menu size={24} />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-64">
              <NavContent />
            </SheetContent>
          </Sheet>
          <h1 className="text-base sm:text-lg font-semibold">Fact-Digit</h1>
          <div className="w-10" /> {/* Spacer pour centrer le titre */}
        </div>
      </div>

      {/* Navigation bottom pour mobile */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 z-50 bg-background border-t">
        <div className="flex justify-around items-center py-1 sm:py-2 px-2">
          {navItems.slice(0, 4).map((item) => {
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`flex flex-col items-center space-y-1 px-2 sm:px-3 py-2 rounded-lg transition-colors min-w-0 flex-1 ${
                  isActive 
                    ? 'text-primary' 
                    : 'text-muted-foreground'
                }`}
              >
                <item.icon size={18} className="sm:w-5 sm:h-5" />
                <span className="text-[10px] sm:text-xs font-medium truncate leading-tight">{item.label}</span>
              </Link>
            );
          })}
        </div>
      </div>
    </>
  );
};

export default MobileNavigation;