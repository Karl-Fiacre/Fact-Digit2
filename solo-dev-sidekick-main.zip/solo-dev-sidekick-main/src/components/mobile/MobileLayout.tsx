import React from 'react';
import { useIsMobile } from '@/hooks/use-mobile';
import MobileNavigation from './MobileNavigation';
import MobileStatusBar from './MobileStatusBar';

interface MobileLayoutProps {
  children: React.ReactNode;
}

const MobileLayout: React.FC<MobileLayoutProps> = ({ children }) => {
  const isMobile = useIsMobile();

  if (!isMobile) {
    return <>{children}</>;
  }

  return (
    <div className="min-h-screen bg-background">
      <MobileStatusBar />
      <MobileNavigation />
      
      {/* Contenu principal avec padding pour la navigation */}
      <main className="pt-16 pb-20 px-3 sm:px-4">
        {children}
      </main>
    </div>
  );
};

export default MobileLayout;