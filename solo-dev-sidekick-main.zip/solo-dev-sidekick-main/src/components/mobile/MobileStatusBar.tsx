import React, { useEffect, useState } from 'react';
import { StatusBar, Style } from '@capacitor/status-bar';
import { Network } from '@capacitor/network';
import { Wifi, WifiOff, Loader2 } from 'lucide-react';
import { useOfflineSync } from '@/hooks/useOfflineSync';

const MobileStatusBar = () => {
  const { isOnline, isSyncing } = useOfflineSync();
  const [isCapacitor, setIsCapacitor] = useState(false);

  useEffect(() => {
    // Vérifier si on est dans l'app Capacitor
    const checkCapacitor = () => {
      setIsCapacitor(window.location.protocol === 'capacitor:');
    };

    checkCapacitor();

    // Configurer la status bar si on est sur mobile
    if (isCapacitor) {
      StatusBar.setStyle({ style: Style.Light });
      StatusBar.setBackgroundColor({ color: '#000000' });
    }
  }, [isCapacitor]);

  if (!isCapacitor) return null;

  return (
    <div className="fixed top-0 left-0 right-0 z-50 bg-primary text-primary-foreground">
      <div className="flex items-center justify-between px-4 py-1 text-xs">
        <div className="flex items-center space-x-2">
          {isOnline ? (
            <Wifi size={12} className="text-green-400" />
          ) : (
            <WifiOff size={12} className="text-red-400" />
          )}
          <span>{isOnline ? 'En ligne' : 'Hors ligne'}</span>
        </div>
        
        {isSyncing && (
          <div className="flex items-center space-x-1">
            <Loader2 size={12} className="animate-spin" />
            <span>Sync...</span>
          </div>
        )}
        
        <div>{new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}</div>
      </div>
    </div>
  );
};

export default MobileStatusBar;