import React, { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Upload, FileSpreadsheet, AlertCircle, CheckCircle } from "lucide-react";
import Papa from "papaparse";
import * as XLSX from "xlsx";

interface InvoiceImportData {
  client_name: string;
  client_email?: string;
  client_phone?: string;
  client_address?: string;
  invoice_number: string;
  date_issued: string;
  date_due?: string;
  product_name: string;
  product_description?: string;
  quantity: number;
  unit_price: number;
  tva_rate?: number;
  notes?: string;
}

interface InvoiceImportDialogProps {
  onImportComplete: () => void;
}

const InvoiceImportDialog = ({ onImportComplete }: InvoiceImportDialogProps) => {
  const [isOpen, setIsOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [importData, setImportData] = useState<InvoiceImportData[]>([]);
  const [previewData, setPreviewData] = useState<InvoiceImportData[]>([]);
  const [step, setStep] = useState<'upload' | 'preview' | 'processing'>('upload');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  // Normalisation des entêtes/valeurs (FR/EN) et conversions
  const normalizeKey = (key: string) => {
    const k = key.toLowerCase().trim();
    const map: Record<string, string> = {
      // Client
      'client': 'client_name',
      'nom client': 'client_name',
      'nom_du_client': 'client_name',
      'client_name': 'client_name',
      'email client': 'client_email',
      'courriel client': 'client_email',
      'client_email': 'client_email',
      'phone client': 'client_phone',
      'téléphone client': 'client_phone',
      'telephone client': 'client_phone',
      'client_phone': 'client_phone',
      'adresse client': 'client_address',
      'client_address': 'client_address',

      // Facture
      'numero_facture': 'invoice_number',
      'n° facture': 'invoice_number',
      'n°facture': 'invoice_number',
      'num facture': 'invoice_number',
      'invoice_number': 'invoice_number',
      'date_emission': 'date_issued',
      "date d'émission": 'date_issued',
      'date emission': 'date_issued',
      'date_issued': 'date_issued',
      'date_echeance': 'date_due',
      "date d'échéance": 'date_due',
      'date echeance': 'date_due',
      'date_due': 'date_due',

      // Article
      'produit': 'product_name',
      'designation': 'product_name',
      'article': 'product_name',
      'product_name': 'product_name',
      'description': 'product_description',
      'product_description': 'product_description',
      'quantite': 'quantity',
      'qté': 'quantity',
      'qte': 'quantity',
      'quantity': 'quantity',
      'prix_unitaire': 'unit_price',
      'prix unitaire': 'unit_price',
      'pu': 'unit_price',
      'unit_price': 'unit_price',
      'tva': 'tva_rate',
      'tva_rate': 'tva_rate',
      'notes': 'notes',
      'remarques': 'notes',
    };
    return map[k] || key;
  };

  const toNumber = (val: any, fallback = 0) => {
    if (typeof val === 'number') return val;
    if (typeof val !== 'string') return fallback;
    const s = val.replace(/\s/g, '') // remove spaces
                 .replace(/\u202f/g, '') // narrow no-break space
                 .replace(/\./g, '') // thousands dot
                 .replace(/,/g, '.'); // decimal comma
    const n = Number(s);
    return isNaN(n) ? fallback : n;
  };

  const normalizeRow = (row: Record<string, any>): InvoiceImportData => {
    // Remap keys
    const mapped: any = {};
    Object.entries(row).forEach(([k, v]) => {
      mapped[normalizeKey(k)] = v;
    });
    return {
      client_name: mapped.client_name,
      client_email: mapped.client_email,
      client_phone: mapped.client_phone,
      client_address: mapped.client_address,
      invoice_number: mapped.invoice_number,
      date_issued: mapped.date_issued,
      date_due: mapped.date_due,
      product_name: mapped.product_name,
      product_description: mapped.product_description,
      quantity: toNumber(mapped.quantity, 1),
      unit_price: toNumber(mapped.unit_price, 0),
      tva_rate: toNumber(mapped.tva_rate, 18),
      notes: mapped.notes,
    };
  };

  const csvTemplate = `client_name,client_email,client_phone,client_address,invoice_number,date_issued,date_due,product_name,product_description,quantity,unit_price,tva_rate,notes
"ACME Corp","contact@acme.com","+225 01 02 03 04","Abidjan, Cocody","FAC-2024-001","2024-01-15","2024-02-15","Consultation","Service de consultation","1","50000","18","Facture de consultation"
"Tech Solutions","info@tech.ci","+225 05 06 07 08","Abidjan, Plateau","FAC-2024-002","2024-01-16","2024-02-16","Développement Web","Site web vitrine","1","200000","18","Développement complet"`;

  const downloadTemplate = () => {
    const blob = new Blob([csvTemplate], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', 'modele_factures_import.csv');
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const parseFile = (file: File) => {
    const fileExtension = file.name.split('.').pop()?.toLowerCase();
    
    if (fileExtension === 'csv') {
      Papa.parse(file, {
        header: true,
        skipEmptyLines: true,
        complete: (results) => {
          processImportData(results.data as InvoiceImportData[]);
        },
        error: (error) => {
          toast({
            title: "Erreur de lecture CSV",
            description: error.message,
            variant: "destructive"
          });
        }
      });
    } else if (fileExtension === 'xlsx' || fileExtension === 'xls') {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const data = new Uint8Array(e.target?.result as ArrayBuffer);
          const workbook = XLSX.read(data, { type: 'array' });
          const sheetName = workbook.SheetNames[0];
          const worksheet = workbook.Sheets[sheetName];
          const jsonData = XLSX.utils.sheet_to_json(worksheet) as InvoiceImportData[];
          processImportData(jsonData);
        } catch (error) {
          toast({
            title: "Erreur de lecture Excel",
            description: "Impossible de lire le fichier Excel",
            variant: "destructive"
          });
        }
      };
      reader.readAsArrayBuffer(file);
    } else {
      toast({
        title: "Format non supporté",
        description: "Veuillez utiliser un fichier CSV ou Excel (.xlsx, .xls)",
        variant: "destructive"
      });
    }
  };

  const processImportData = (data: InvoiceImportData[]) => {
    const normalized = (data as any[]).map((row) => normalizeRow(row as Record<string, any>));

    const cleanedData = normalized.filter(row => 
      row.client_name && row.invoice_number && row.product_name && row.quantity && row.unit_price
    ).map(row => ({
      ...row,
      quantity: toNumber(row.quantity, 1),
      unit_price: toNumber(row.unit_price, 0),
      tva_rate: toNumber(row.tva_rate, 18),
      date_issued: row.date_issued || new Date().toISOString().split('T')[0]
    }));

    const skipped = normalized.length - cleanedData.length;

    if (cleanedData.length === 0) {
      toast({
        title: "Aucune ligne valide détectée",
        description: "Vérifiez les entêtes (ex: client_name, invoice_number, product_name, quantity, unit_price) ou utilisez le modèle.",
        variant: "destructive"
      });
      setStep('upload');
      return;
    }

    if (skipped > 0) {
      toast({
        title: "Nettoyage des données",
        description: `${skipped} ligne(s) ignorée(s) pour cause de champs manquants ou invalides`,
      });
    }

    setImportData(cleanedData);
    setPreviewData(cleanedData.slice(0, 5)); // Prévisualiser les 5 premières lignes
    setStep('preview');
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      parseFile(file);
    }
  };

  const processImport = async () => {
    setLoading(true);
    setStep('processing');
    
    try {
      // Récupérer la company_id de l'utilisateur connecté
      const { data: profile, error: profileError } = await supabase
        .from('profiles')
        .select('company_id')
        .eq('user_id', '73284fff-2b99-405e-8489-2b306b953055') // Utilisation de l'ID utilisateur réel
        .maybeSingle();

      if (profileError || !profile?.company_id) {
        toast({
          title: "Erreur",
          description: "Impossible de récupérer les informations de l'entreprise",
          variant: "destructive"
        });
        setLoading(false);
        return;
      }

      const companyId = profile.company_id;
      let successCount = 0;
      let errorCount = 0;

      for (const invoiceData of importData) {
        try {
          // 1. Créer ou trouver le client
          let client;
          const { data: existingClient } = await supabase
            .from('clients')
            .select('id')
            .eq('name', invoiceData.client_name)
            .eq('company_id', companyId)
            .single();

          if (existingClient) {
            client = existingClient;
          } else {
            const { data: newClient, error: clientError } = await supabase
              .from('clients')
              .insert({
                name: invoiceData.client_name,
                email: invoiceData.client_email,
                phone: invoiceData.client_phone,
                address: invoiceData.client_address,
                company_id: companyId
              })
              .select()
              .single();

            if (clientError) throw clientError;
            client = newClient;
          }

          // 2. Créer la facture
          const subtotal = invoiceData.quantity * invoiceData.unit_price;
          const tvaAmount = subtotal * (invoiceData.tva_rate / 100);
          const totalAmount = subtotal + tvaAmount;

          const { data: invoice, error: invoiceError } = await supabase
            .from('invoices')
            .insert({
              company_id: companyId,
              client_id: client.id,
              invoice_number: invoiceData.invoice_number,
              date_issued: invoiceData.date_issued,
              date_due: invoiceData.date_due,
              subtotal,
              tva_amount: tvaAmount,
              total_amount: totalAmount,
              notes: invoiceData.notes,
              status: 'draft',
              fne_status: 'draft'
            })
            .select()
            .single();

          if (invoiceError) throw invoiceError;

          // 3. Créer les éléments de facture
          const { error: itemError } = await supabase
            .from('invoice_items')
            .insert({
              invoice_id: invoice.id,
              description: invoiceData.product_name,
              quantity: invoiceData.quantity,
              unit_price: invoiceData.unit_price,
              tva_rate: invoiceData.tva_rate,
              total_price: subtotal
            });

          if (itemError) throw itemError;
          successCount++;
        } catch (error) {
          console.error('Erreur lors de l\'import de la facture:', invoiceData.invoice_number, error);
          errorCount++;
        }
      }

      toast({
        title: "Import terminé",
        description: `${successCount} factures importées avec succès${errorCount > 0 ? `, ${errorCount} erreurs` : ''}`,
        variant: successCount > 0 ? "default" : "destructive"
      });

      if (successCount > 0) {
        onImportComplete();
        setIsOpen(false);
        resetDialog();
      }
    } catch (error) {
      toast({
        title: "Erreur d'import",
        description: "Une erreur est survenue lors de l'import",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const resetDialog = () => {
    setStep('upload');
    setImportData([]);
    setPreviewData([]);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => {
      setIsOpen(open);
      if (!open) resetDialog();
    }}>
      <DialogTrigger asChild>
        <Button variant="outline">
          <Upload className="h-4 w-4 mr-2" />
          Importer des factures
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Importer des factures</DialogTitle>
          <DialogDescription>
            Importez vos factures depuis un fichier Excel (.xlsx) ou CSV
          </DialogDescription>
        </DialogHeader>

        {step === 'upload' && (
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-sm">Étape 1: Format d'entête requis</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-4">
                  Votre fichier CSV ou Excel doit contenir ces entêtes exactes (première ligne) :
                </p>
                <div className="bg-muted p-3 rounded-md mb-4 text-xs font-mono overflow-x-auto">
                  <div className="whitespace-nowrap">
                    client_name,client_email,client_phone,client_address,invoice_number,date_issued,date_due,product_name,product_description,quantity,unit_price,tva_rate,notes
                  </div>
                </div>
                <div className="space-y-2 text-xs text-muted-foreground">
                  <p><strong>Champs obligatoires :</strong> client_name, invoice_number, product_name, quantity, unit_price</p>
                  <p><strong>Formats acceptés :</strong> CSV (.csv), Excel (.xlsx, .xls)</p>
                  <p><strong>Alternative :</strong> Vous pouvez aussi utiliser les entêtes en français comme "Nom Client", "N° Facture", "Produit", "Quantité", "Prix unitaire"</p>
                </div>
                <Button variant="outline" onClick={downloadTemplate} className="mt-4">
                  <FileSpreadsheet className="h-4 w-4 mr-2" />
                  Télécharger un exemple complet
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-sm">Étape 2: Importer votre fichier</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <Label htmlFor="file-upload">Sélectionner un fichier CSV ou Excel</Label>
                  <Input
                    id="file-upload"
                    type="file"
                    ref={fileInputRef}
                    accept=".csv,.xlsx,.xls"
                    onChange={handleFileUpload}
                  />
                  <p className="text-xs text-muted-foreground">
                    Formats supportés: CSV, Excel (.xlsx, .xls)
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {step === 'preview' && (
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <CheckCircle className="h-5 w-5 text-green-600" />
              <span className="font-medium">Aperçu des données ({importData.length} factures détectées)</span>
            </div>
            
            <div className="border rounded-lg overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-muted">
                  <tr>
                    <th className="p-2 text-left">Client</th>
                    <th className="p-2 text-left">N° Facture</th>
                    <th className="p-2 text-left">Produit</th>
                    <th className="p-2 text-right">Quantité</th>
                    <th className="p-2 text-right">Prix unitaire</th>
                    <th className="p-2 text-right">Total</th>
                  </tr>
                </thead>
                <tbody>
                  {previewData.map((row, index) => (
                    <tr key={index} className="border-t">
                      <td className="p-2">{row.client_name}</td>
                      <td className="p-2">{row.invoice_number}</td>
                      <td className="p-2">{row.product_name}</td>
                      <td className="p-2 text-right">{row.quantity}</td>
                      <td className="p-2 text-right">{row.unit_price.toLocaleString()} CFA</td>
                      <td className="p-2 text-right">{(row.quantity * row.unit_price).toLocaleString()} CFA</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            
            {importData.length > 5 && (
              <p className="text-sm text-muted-foreground">
                ... et {importData.length - 5} autres factures
              </p>
            )}

            <div className="flex gap-2 justify-end">
              <Button variant="outline" onClick={resetDialog}>
                Annuler
              </Button>
              <Button onClick={processImport} disabled={loading}>
                {loading ? "Import en cours..." : `Importer ${importData.length} factures`}
              </Button>
            </div>
          </div>
        )}

        {step === 'processing' && (
          <div className="text-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
            <p>Import des factures en cours...</p>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};

export default InvoiceImportDialog;