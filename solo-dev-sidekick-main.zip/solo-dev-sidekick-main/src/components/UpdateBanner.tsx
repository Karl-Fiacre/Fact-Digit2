import { AlertCircle, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { useAppUpdates } from '@/hooks/useAppUpdates';

export const UpdateBanner = () => {
  const { updateAvailable, currentVersion, applyUpdate } = useAppUpdates();

  if (!updateAvailable) return null;

  return (
    <Alert className="border-primary/50 bg-primary/10">
      <AlertCircle className="h-4 w-4" />
      <AlertTitle>Mise à jour disponible</AlertTitle>
      <AlertDescription className="flex items-center justify-between">
        <span>
          Une nouvelle version de Fact-Digit est disponible (version actuelle: {currentVersion})
        </span>
        <Button onClick={applyUpdate} size="sm" className="ml-4">
          <Download className="h-4 w-4 mr-2" />
          Mettre à jour
        </Button>
      </AlertDescription>
    </Alert>
  );
};
