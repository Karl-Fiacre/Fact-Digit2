export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "13.0.4"
  }
  public: {
    Tables: {
      clients: {
        Row: {
          address: string | null
          company_id: string
          created_at: string
          email: string | null
          id: string
          name: string
          numero_cc: string | null
          phone: string | null
          rccm: string | null
          type: string | null
          updated_at: string
        }
        Insert: {
          address?: string | null
          company_id: string
          created_at?: string
          email?: string | null
          id?: string
          name: string
          numero_cc?: string | null
          phone?: string | null
          rccm?: string | null
          type?: string | null
          updated_at?: string
        }
        Update: {
          address?: string | null
          company_id?: string
          created_at?: string
          email?: string | null
          id?: string
          name?: string
          numero_cc?: string | null
          phone?: string | null
          rccm?: string | null
          type?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "clients_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
        ]
      }
      companies: {
        Row: {
          address: string | null
          created_at: string
          email: string | null
          id: string
          logo_url: string | null
          name: string
          numero_cc: string | null
          phone: string | null
          rccm: string | null
          updated_at: string
          website: string | null
        }
        Insert: {
          address?: string | null
          created_at?: string
          email?: string | null
          id?: string
          logo_url?: string | null
          name: string
          numero_cc?: string | null
          phone?: string | null
          rccm?: string | null
          updated_at?: string
          website?: string | null
        }
        Update: {
          address?: string | null
          created_at?: string
          email?: string | null
          id?: string
          logo_url?: string | null
          name?: string
          numero_cc?: string | null
          phone?: string | null
          rccm?: string | null
          updated_at?: string
          website?: string | null
        }
        Relationships: []
      }
      contacts_melliamcosmetics: {
        Row: {
          created_at: string
          email: string
          id: string
          message: string
          name: string
          status: string | null
          subject: string
          type: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          email: string
          id?: string
          message: string
          name: string
          status?: string | null
          subject: string
          type: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          email?: string
          id?: string
          message?: string
          name?: string
          status?: string | null
          subject?: string
          type?: string
          updated_at?: string
        }
        Relationships: []
      }
      documents_keyli: {
        Row: {
          created_at: string
          doc_type: Database["public"]["Enums"]["document_type_keyli"]
          file_url: string
          id: string
          property_id: string | null
          review_notes: string | null
          reviewed_at: string | null
          status: Database["public"]["Enums"]["document_status_keyli"] | null
          user_id: string
        }
        Insert: {
          created_at?: string
          doc_type: Database["public"]["Enums"]["document_type_keyli"]
          file_url: string
          id?: string
          property_id?: string | null
          review_notes?: string | null
          reviewed_at?: string | null
          status?: Database["public"]["Enums"]["document_status_keyli"] | null
          user_id: string
        }
        Update: {
          created_at?: string
          doc_type?: Database["public"]["Enums"]["document_type_keyli"]
          file_url?: string
          id?: string
          property_id?: string | null
          review_notes?: string | null
          reviewed_at?: string | null
          status?: Database["public"]["Enums"]["document_status_keyli"] | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "documents_keyli_property_id_fkey"
            columns: ["property_id"]
            isOneToOne: false
            referencedRelation: "properties_keyli"
            referencedColumns: ["id"]
          },
        ]
      }
      event_registrations_melliamcosmetics: {
        Row: {
          created_at: string
          dietary_restrictions: string | null
          email: string
          event_id: string
          first_name: string
          id: string
          last_name: string
          payment_amount: number | null
          payment_status: string | null
          phone: string | null
          registration_date: string
          special_requests: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          dietary_restrictions?: string | null
          email: string
          event_id: string
          first_name: string
          id?: string
          last_name: string
          payment_amount?: number | null
          payment_status?: string | null
          phone?: string | null
          registration_date?: string
          special_requests?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          dietary_restrictions?: string | null
          email?: string
          event_id?: string
          first_name?: string
          id?: string
          last_name?: string
          payment_amount?: number | null
          payment_status?: string | null
          phone?: string | null
          registration_date?: string
          special_requests?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "event_registrations_event_id_fkey"
            columns: ["event_id"]
            isOneToOne: false
            referencedRelation: "events_melliamcosmetics"
            referencedColumns: ["id"]
          },
        ]
      }
      events_melliamcosmetics: {
        Row: {
          created_at: string
          current_participants: number | null
          description: string | null
          event_date: string
          event_type: string | null
          id: string
          image_url: string | null
          location: string | null
          max_participants: number | null
          price: number | null
          status: string | null
          title: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          current_participants?: number | null
          description?: string | null
          event_date: string
          event_type?: string | null
          id?: string
          image_url?: string | null
          location?: string | null
          max_participants?: number | null
          price?: number | null
          status?: string | null
          title: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          current_participants?: number | null
          description?: string | null
          event_date?: string
          event_type?: string | null
          id?: string
          image_url?: string | null
          location?: string | null
          max_participants?: number | null
          price?: number | null
          status?: string | null
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      fne_logs: {
        Row: {
          created_at: string
          error_message: string | null
          id: string
          invoice_id: string
          request_data: Json
          response_data: Json | null
          status: string
        }
        Insert: {
          created_at?: string
          error_message?: string | null
          id?: string
          invoice_id: string
          request_data: Json
          response_data?: Json | null
          status: string
        }
        Update: {
          created_at?: string
          error_message?: string | null
          id?: string
          invoice_id?: string
          request_data?: Json
          response_data?: Json | null
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "fne_logs_invoice_id_fkey"
            columns: ["invoice_id"]
            isOneToOne: false
            referencedRelation: "invoices"
            referencedColumns: ["id"]
          },
        ]
      }
      invoice_items: {
        Row: {
          created_at: string
          description: string
          id: string
          invoice_id: string
          product_id: string | null
          quantity: number
          total_price: number | null
          tva_rate: number | null
          unit_price: number
        }
        Insert: {
          created_at?: string
          description: string
          id?: string
          invoice_id: string
          product_id?: string | null
          quantity?: number
          total_price?: number | null
          tva_rate?: number | null
          unit_price: number
        }
        Update: {
          created_at?: string
          description?: string
          id?: string
          invoice_id?: string
          product_id?: string | null
          quantity?: number
          total_price?: number | null
          tva_rate?: number | null
          unit_price?: number
        }
        Relationships: [
          {
            foreignKeyName: "invoice_items_invoice_id_fkey"
            columns: ["invoice_id"]
            isOneToOne: false
            referencedRelation: "invoices"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "invoice_items_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
        ]
      }
      invoices: {
        Row: {
          client_id: string
          company_id: string
          created_at: string
          date_due: string | null
          date_issued: string
          fne_number: string | null
          fne_rejection_reason: string | null
          fne_status: string | null
          fne_submitted_at: string | null
          fne_validated_at: string | null
          id: string
          invoice_number: string
          notes: string | null
          status: string | null
          subtotal: number | null
          terms: string | null
          total_amount: number | null
          tva_amount: number | null
          updated_at: string
        }
        Insert: {
          client_id: string
          company_id: string
          created_at?: string
          date_due?: string | null
          date_issued?: string
          fne_number?: string | null
          fne_rejection_reason?: string | null
          fne_status?: string | null
          fne_submitted_at?: string | null
          fne_validated_at?: string | null
          id?: string
          invoice_number: string
          notes?: string | null
          status?: string | null
          subtotal?: number | null
          terms?: string | null
          total_amount?: number | null
          tva_amount?: number | null
          updated_at?: string
        }
        Update: {
          client_id?: string
          company_id?: string
          created_at?: string
          date_due?: string | null
          date_issued?: string
          fne_number?: string | null
          fne_rejection_reason?: string | null
          fne_status?: string | null
          fne_submitted_at?: string | null
          fne_validated_at?: string | null
          id?: string
          invoice_number?: string
          notes?: string | null
          status?: string | null
          subtotal?: number | null
          terms?: string | null
          total_amount?: number | null
          tva_amount?: number | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "invoices_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "invoices_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
        ]
      }
      messages_keyli: {
        Row: {
          body: string
          created_at: string
          from_user: string
          id: string
          property_id: string
          read: boolean | null
          to_user: string
        }
        Insert: {
          body: string
          created_at?: string
          from_user: string
          id?: string
          property_id: string
          read?: boolean | null
          to_user: string
        }
        Update: {
          body?: string
          created_at?: string
          from_user?: string
          id?: string
          property_id?: string
          read?: boolean | null
          to_user?: string
        }
        Relationships: [
          {
            foreignKeyName: "messages_keyli_property_id_fkey"
            columns: ["property_id"]
            isOneToOne: false
            referencedRelation: "properties_keyli"
            referencedColumns: ["id"]
          },
        ]
      }
      newsletter_subscribers_melliamcosmetics: {
        Row: {
          email: string
          id: string
          name: string | null
          preferences: string[] | null
          status: string | null
          subscribed_at: string
          updated_at: string
        }
        Insert: {
          email: string
          id?: string
          name?: string | null
          preferences?: string[] | null
          status?: string | null
          subscribed_at?: string
          updated_at?: string
        }
        Update: {
          email?: string
          id?: string
          name?: string | null
          preferences?: string[] | null
          status?: string | null
          subscribed_at?: string
          updated_at?: string
        }
        Relationships: []
      }
      products: {
        Row: {
          category: string | null
          company_id: string
          created_at: string
          description: string | null
          id: string
          is_service: boolean | null
          name: string
          price: number
          tva_rate: number | null
          unit: string | null
          updated_at: string
        }
        Insert: {
          category?: string | null
          company_id: string
          created_at?: string
          description?: string | null
          id?: string
          is_service?: boolean | null
          name: string
          price?: number
          tva_rate?: number | null
          unit?: string | null
          updated_at?: string
        }
        Update: {
          category?: string | null
          company_id?: string
          created_at?: string
          description?: string | null
          id?: string
          is_service?: boolean | null
          name?: string
          price?: number
          tva_rate?: number | null
          unit?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "products_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          address: string | null
          bio: string | null
          company_id: string | null
          created_at: string
          display_name: string | null
          email: string | null
          first_name: string | null
          id: string
          id_number: string | null
          id_validity_date: string | null
          last_name: string | null
          phone: string | null
          photo_url: string | null
          rating_avg: number | null
          role: string | null
          role_keyli: Database["public"]["Enums"]["user_role_keyli"] | null
          updated_at: string
          user_id: string
          verification_badge_reason: string | null
          verification_date: string | null
          verified: boolean | null
        }
        Insert: {
          address?: string | null
          bio?: string | null
          company_id?: string | null
          created_at?: string
          display_name?: string | null
          email?: string | null
          first_name?: string | null
          id?: string
          id_number?: string | null
          id_validity_date?: string | null
          last_name?: string | null
          phone?: string | null
          photo_url?: string | null
          rating_avg?: number | null
          role?: string | null
          role_keyli?: Database["public"]["Enums"]["user_role_keyli"] | null
          updated_at?: string
          user_id: string
          verification_badge_reason?: string | null
          verification_date?: string | null
          verified?: boolean | null
        }
        Update: {
          address?: string | null
          bio?: string | null
          company_id?: string | null
          created_at?: string
          display_name?: string | null
          email?: string | null
          first_name?: string | null
          id?: string
          id_number?: string | null
          id_validity_date?: string | null
          last_name?: string | null
          phone?: string | null
          photo_url?: string | null
          rating_avg?: number | null
          role?: string | null
          role_keyli?: Database["public"]["Enums"]["user_role_keyli"] | null
          updated_at?: string
          user_id?: string
          verification_badge_reason?: string | null
          verification_date?: string | null
          verified?: boolean | null
        }
        Relationships: [
          {
            foreignKeyName: "profiles_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
        ]
      }
      properties_keyli: {
        Row: {
          area_m2: number | null
          bathrooms: number | null
          city: string
          created_at: string
          description: string | null
          furnished: boolean | null
          geolocation: unknown | null
          id: string
          is_verified: boolean | null
          main_image_url: string | null
          neighborhood: string | null
          owner_id: string
          price: number
          rooms: number | null
          status: Database["public"]["Enums"]["property_status_keyli"]
          title: string
          type: Database["public"]["Enums"]["property_type_keyli"]
          updated_at: string
          video_url: string | null
        }
        Insert: {
          area_m2?: number | null
          bathrooms?: number | null
          city: string
          created_at?: string
          description?: string | null
          furnished?: boolean | null
          geolocation?: unknown | null
          id?: string
          is_verified?: boolean | null
          main_image_url?: string | null
          neighborhood?: string | null
          owner_id: string
          price: number
          rooms?: number | null
          status: Database["public"]["Enums"]["property_status_keyli"]
          title: string
          type: Database["public"]["Enums"]["property_type_keyli"]
          updated_at?: string
          video_url?: string | null
        }
        Update: {
          area_m2?: number | null
          bathrooms?: number | null
          city?: string
          created_at?: string
          description?: string | null
          furnished?: boolean | null
          geolocation?: unknown | null
          id?: string
          is_verified?: boolean | null
          main_image_url?: string | null
          neighborhood?: string | null
          owner_id?: string
          price?: number
          rooms?: number | null
          status?: Database["public"]["Enums"]["property_status_keyli"]
          title?: string
          type?: Database["public"]["Enums"]["property_type_keyli"]
          updated_at?: string
          video_url?: string | null
        }
        Relationships: []
      }
      property_media_keyli: {
        Row: {
          created_at: string
          id: string
          media_type: string
          order_index: number | null
          property_id: string
          url: string
        }
        Insert: {
          created_at?: string
          id?: string
          media_type: string
          order_index?: number | null
          property_id: string
          url: string
        }
        Update: {
          created_at?: string
          id?: string
          media_type?: string
          order_index?: number | null
          property_id?: string
          url?: string
        }
        Relationships: [
          {
            foreignKeyName: "property_media_keyli_property_id_fkey"
            columns: ["property_id"]
            isOneToOne: false
            referencedRelation: "properties_keyli"
            referencedColumns: ["id"]
          },
        ]
      }
      registrations_melliamcosmetics: {
        Row: {
          created_at: string
          dietary_restrictions: string | null
          email: string
          eventbrite_attendee_id: string | null
          eventbrite_order_id: string | null
          eventbrite_ticket_url: string | null
          first_name: string
          id: string
          interests: string[] | null
          last_name: string
          organization: string | null
          phone: string
          position: string | null
          status: string | null
          ticket_generated_at: string | null
          ticket_number: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          dietary_restrictions?: string | null
          email: string
          eventbrite_attendee_id?: string | null
          eventbrite_order_id?: string | null
          eventbrite_ticket_url?: string | null
          first_name: string
          id?: string
          interests?: string[] | null
          last_name: string
          organization?: string | null
          phone: string
          position?: string | null
          status?: string | null
          ticket_generated_at?: string | null
          ticket_number?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          dietary_restrictions?: string | null
          email?: string
          eventbrite_attendee_id?: string | null
          eventbrite_order_id?: string | null
          eventbrite_ticket_url?: string | null
          first_name?: string
          id?: string
          interests?: string[] | null
          last_name?: string
          organization?: string | null
          phone?: string
          position?: string | null
          status?: string | null
          ticket_generated_at?: string | null
          ticket_number?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      reports_keyli: {
        Row: {
          created_at: string
          id: string
          property_id: string
          reason: string
          reporter_id: string
          status: Database["public"]["Enums"]["report_status_keyli"] | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          id?: string
          property_id: string
          reason: string
          reporter_id: string
          status?: Database["public"]["Enums"]["report_status_keyli"] | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          id?: string
          property_id?: string
          reason?: string
          reporter_id?: string
          status?: Database["public"]["Enums"]["report_status_keyli"] | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "reports_keyli_property_id_fkey"
            columns: ["property_id"]
            isOneToOne: false
            referencedRelation: "properties_keyli"
            referencedColumns: ["id"]
          },
        ]
      }
      reservations_melliamcosmetics: {
        Row: {
          created_at: string
          email: string
          id: string
          name: string
          phone: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          email: string
          id?: string
          name: string
          phone: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          email?: string
          id?: string
          name?: string
          phone?: string
          updated_at?: string
        }
        Relationships: []
      }
      subscriptions_keyli: {
        Row: {
          amount: number
          created_at: string
          end_date: string
          id: string
          paystack_payment_id: string | null
          plan: Database["public"]["Enums"]["subscription_plan_keyli"]
          start_date: string
          status:
            | Database["public"]["Enums"]["subscription_status_keyli"]
            | null
          updated_at: string
          user_id: string
        }
        Insert: {
          amount: number
          created_at?: string
          end_date: string
          id?: string
          paystack_payment_id?: string | null
          plan: Database["public"]["Enums"]["subscription_plan_keyli"]
          start_date?: string
          status?:
            | Database["public"]["Enums"]["subscription_status_keyli"]
            | null
          updated_at?: string
          user_id: string
        }
        Update: {
          amount?: number
          created_at?: string
          end_date?: string
          id?: string
          paystack_payment_id?: string | null
          plan?: Database["public"]["Enums"]["subscription_plan_keyli"]
          start_date?: string
          status?:
            | Database["public"]["Enums"]["subscription_status_keyli"]
            | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      teachings_melliamcosmetics: {
        Row: {
          category: string | null
          content: string
          created_at: string
          id: string
          is_featured: boolean | null
          source: string | null
          title: string | null
          updated_at: string
        }
        Insert: {
          category?: string | null
          content: string
          created_at?: string
          id?: string
          is_featured?: boolean | null
          source?: string | null
          title?: string | null
          updated_at?: string
        }
        Update: {
          category?: string | null
          content?: string
          created_at?: string
          id?: string
          is_featured?: boolean | null
          source?: string | null
          title?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      testimonials_melliamcosmetics: {
        Row: {
          avatar_url: string | null
          content: string
          created_at: string
          email: string | null
          experience_type: string | null
          id: string
          is_approved: boolean | null
          is_featured: boolean | null
          location: string | null
          name: string
          rating: number | null
          title: string | null
          updated_at: string
        }
        Insert: {
          avatar_url?: string | null
          content: string
          created_at?: string
          email?: string | null
          experience_type?: string | null
          id?: string
          is_approved?: boolean | null
          is_featured?: boolean | null
          location?: string | null
          name: string
          rating?: number | null
          title?: string | null
          updated_at?: string
        }
        Update: {
          avatar_url?: string | null
          content?: string
          created_at?: string
          email?: string | null
          experience_type?: string | null
          id?: string
          is_approved?: boolean | null
          is_featured?: boolean | null
          location?: string | null
          name?: string
          rating?: number | null
          title?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      transactions_keyli: {
        Row: {
          amount: number
          created_at: string
          currency: string | null
          id: string
          paystack_ref: string | null
          status: Database["public"]["Enums"]["transaction_status_keyli"] | null
          subscription_id: string | null
          user_id: string
        }
        Insert: {
          amount: number
          created_at?: string
          currency?: string | null
          id?: string
          paystack_ref?: string | null
          status?:
            | Database["public"]["Enums"]["transaction_status_keyli"]
            | null
          subscription_id?: string | null
          user_id: string
        }
        Update: {
          amount?: number
          created_at?: string
          currency?: string | null
          id?: string
          paystack_ref?: string | null
          status?:
            | Database["public"]["Enums"]["transaction_status_keyli"]
            | null
          subscription_id?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "transactions_keyli_subscription_id_fkey"
            columns: ["subscription_id"]
            isOneToOne: false
            referencedRelation: "subscriptions_keyli"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      get_dashboard_stats: {
        Args: { p_company_id: string }
        Returns: {
          clients_count: number
          invoices_count: number
          products_count: number
          total_revenue: number
          total_tva: number
        }[]
      }
      get_user_role_keyli: {
        Args: { user_uuid: string }
        Returns: string
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      secure_function_example: {
        Args: Record<PropertyKey, never>
        Returns: string
      }
    }
    Enums: {
      app_role: "admin" | "moderator" | "user"
      document_status_keyli: "pending" | "approved" | "rejected"
      document_type_keyli:
        | "acd"
        | "registre"
        | "extrait_naissance"
        | "cert_residence"
        | "permis_construire"
        | "id_front"
        | "id_back"
      property_status_keyli: "a_louer" | "a_vendre"
      property_type_keyli:
        | "maison"
        | "duplex"
        | "villa"
        | "appartement"
        | "studio"
        | "residence_meublee"
        | "auberge"
        | "hotel"
        | "bureau"
        | "magasin"
      report_status_keyli: "pending" | "reviewed" | "resolved"
      subscription_plan_keyli: "owner_agency" | "basic_user"
      subscription_status_keyli: "active" | "expired" | "canceled"
      transaction_status_keyli: "pending" | "completed" | "failed"
      user_role_keyli: "user" | "owner" | "agency" | "admin"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "moderator", "user"],
      document_status_keyli: ["pending", "approved", "rejected"],
      document_type_keyli: [
        "acd",
        "registre",
        "extrait_naissance",
        "cert_residence",
        "permis_construire",
        "id_front",
        "id_back",
      ],
      property_status_keyli: ["a_louer", "a_vendre"],
      property_type_keyli: [
        "maison",
        "duplex",
        "villa",
        "appartement",
        "studio",
        "residence_meublee",
        "auberge",
        "hotel",
        "bureau",
        "magasin",
      ],
      report_status_keyli: ["pending", "reviewed", "resolved"],
      subscription_plan_keyli: ["owner_agency", "basic_user"],
      subscription_status_keyli: ["active", "expired", "canceled"],
      transaction_status_keyli: ["pending", "completed", "failed"],
      user_role_keyli: ["user", "owner", "agency", "admin"],
    },
  },
} as const
