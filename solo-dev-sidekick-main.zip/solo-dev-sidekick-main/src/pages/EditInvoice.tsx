import React, { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { ArrowLeft, Plus, Trash2, Save } from "lucide-react";

const invoiceItemSchema = z.object({
  description: z.string().min(1, "Description requise"),
  quantity: z.number().min(0.01, "Quantité doit être supérieure à 0"),
  unit_price: z.number().min(0, "Prix unitaire doit être positif"),
  tva_rate: z.number().min(0).max(100, "Taux TVA invalide"),
});

const invoiceSchema = z.object({
  client_id: z.string().min(1, "Client requis"),
  date_issued: z.string().min(1, "Date d'émission requise"),
  date_due: z.string().optional(),
  notes: z.string().optional(),
  terms: z.string().optional(),
  discount_type: z.enum(['none', 'percentage', 'fixed']).default('none'),
  discount_value: z.number().min(0).default(0),
  items: z.array(invoiceItemSchema).min(1, "Au moins un article requis"),
});

type InvoiceFormData = z.infer<typeof invoiceSchema>;

interface Client {
  id: string;
  name: string;
  email?: string;
  type: string;
}

interface Product {
  id: string;
  name: string;
  price: number;
  tva_rate: number;
  unit: string;
  description?: string;
}

const EditInvoice = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [clients, setClients] = useState<Client[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(false);
  const [loadingInvoice, setLoadingInvoice] = useState(true);
  const [companyInfo, setCompanyInfo] = useState<any>(null);

  const form = useForm<InvoiceFormData>({
    resolver: zodResolver(invoiceSchema),
    defaultValues: {
      date_issued: new Date().toISOString().split('T')[0],
      discount_type: 'none',
      discount_value: 0,
      items: [{ description: "", quantity: 1, unit_price: 0, tva_rate: 18 }],
    },
  });

  const { fields, append, remove } = useFieldArray({
    control: form.control,
    name: "items",
  });

  useEffect(() => {
    loadData();
  }, [id]);

  const loadData = async () => {
    try {
      // Charger la facture
      const { data: invoiceData, error: invoiceError } = await supabase
        .from('invoices')
        .select(`
          *,
          invoice_items (*)
        `)
        .eq('id', id)
        .single();

      if (invoiceError) throw invoiceError;

      // Charger les clients
      const { data: clientsData } = await supabase
        .from('clients')
        .select('*')
        .order('name');

      // Charger les produits
      const { data: productsData } = await supabase
        .from('products')
        .select('*')
        .order('name');

      // Charger les infos de l'entreprise
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Non authentifié");
      
      const { data: profileData } = await supabase
        .from('profiles')
        .select('*, companies(*)')
        .eq('user_id', user.id)
        .maybeSingle();

      if (clientsData) setClients(clientsData);
      if (productsData) setProducts(productsData);
      if (profileData?.companies) setCompanyInfo(profileData.companies);

      // Pré-remplir le formulaire
      if (invoiceData) {
        form.reset({
          client_id: invoiceData.client_id,
          date_issued: invoiceData.date_issued,
          date_due: invoiceData.date_due || "",
          notes: invoiceData.notes || "",
          terms: invoiceData.terms || "",
          discount_type: 'none',
          discount_value: 0,
          items: invoiceData.invoice_items.map((item: any) => ({
            description: item.description,
            quantity: parseFloat(item.quantity),
            unit_price: parseFloat(item.unit_price),
            tva_rate: parseFloat(item.tva_rate),
          })),
        });
      }

      setLoadingInvoice(false);
    } catch (error: any) {
      console.error('Erreur chargement:', error);
      toast({
        title: "Erreur",
        description: "Impossible de charger la facture",
        variant: "destructive"
      });
      navigate("/invoices");
    }
  };

  const syncProductsWithDatabase = async (items: any[]) => {
    if (!companyInfo?.id) return;

    for (const item of items) {
      // Vérifier si un produit avec cette description existe déjà
      const { data: existingProduct } = await supabase
        .from('products')
        .select('id')
        .eq('company_id', companyInfo.id)
        .eq('name', item.description)
        .maybeSingle();

      // Si le produit n'existe pas, le créer
      if (!existingProduct) {
        await supabase
          .from('products')
          .insert({
            company_id: companyInfo.id,
            name: item.description,
            description: item.description,
            price: item.unit_price,
            tva_rate: item.tva_rate,
            unit: 'unité',
            is_service: false,
          });
      }
    }
  };

  const onSubmit = async (data: InvoiceFormData) => {
    try {
      setLoading(true);

      if (!companyInfo?.id) {
        toast({
          title: "Erreur",
          description: "Informations de l'entreprise manquantes",
          variant: "destructive"
        });
        return;
      }

      // Calculer les montants
      let subtotal = 0;
      let tvaAmount = 0;

      data.items.forEach((item) => {
        const itemTotal = item.quantity * item.unit_price;
        subtotal += itemTotal;
        tvaAmount += (itemTotal * item.tva_rate) / 100;
      });

      // Appliquer la remise
      let discountAmount = 0;
      if (data.discount_type === 'percentage') {
        discountAmount = (subtotal * data.discount_value) / 100;
      } else if (data.discount_type === 'fixed') {
        discountAmount = data.discount_value;
      }

      const finalSubtotal = subtotal - discountAmount;
      const finalTVA = (finalSubtotal / subtotal) * tvaAmount;
      const totalAmount = finalSubtotal + finalTVA;

      // Synchroniser les produits
      await syncProductsWithDatabase(data.items);

      // Mettre à jour la facture
      const { error: invoiceError } = await supabase
        .from('invoices')
        .update({
          client_id: data.client_id,
          date_issued: data.date_issued,
          date_due: data.date_due || null,
          subtotal: finalSubtotal,
          tva_amount: finalTVA,
          total_amount: totalAmount,
          notes: data.notes || null,
          terms: data.terms || null,
          updated_at: new Date().toISOString(),
        })
        .eq('id', id);

      if (invoiceError) throw invoiceError;

      // Supprimer les anciens items
      await supabase
        .from('invoice_items')
        .delete()
        .eq('invoice_id', id);

      // Ajouter les nouveaux items
      const itemsToInsert = data.items.map((item) => ({
        invoice_id: id,
        description: item.description,
        quantity: item.quantity,
        unit_price: item.unit_price,
        tva_rate: item.tva_rate
        // total_price est une colonne générée, elle sera calculée automatiquement
      }));

      const { error: itemsError } = await supabase
        .from('invoice_items')
        .insert(itemsToInsert);

      if (itemsError) throw itemsError;

      toast({
        title: "Succès",
        description: "Facture modifiée avec succès",
      });

      navigate("/invoices");
    } catch (error: any) {
      console.error('Erreur:', error);
      toast({
        title: "Erreur",
        description: "Erreur lors de la modification de la facture",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const addProductToInvoice = (product: Product) => {
    append({
      description: product.name,
      quantity: 1,
      unit_price: product.price,
      tva_rate: product.tva_rate,
    });
  };

  const calculateItemTotal = (quantity: number, unitPrice: number) => {
    return (quantity * unitPrice).toFixed(2);
  };

  const calculateSubtotal = () => {
    const items = form.watch("items");
    return items.reduce((sum, item) => sum + (item.quantity * item.unit_price), 0);
  };

  const calculateTVA = () => {
    const items = form.watch("items");
    return items.reduce((sum, item) => {
      const itemTotal = item.quantity * item.unit_price;
      return sum + (itemTotal * item.tva_rate) / 100;
    }, 0);
  };

  const calculateTotal = () => {
    const subtotal = calculateSubtotal();
    const tva = calculateTVA();
    const discountType = form.watch("discount_type");
    const discountValue = form.watch("discount_value");

    let discountAmount = 0;
    if (discountType === 'percentage') {
      discountAmount = (subtotal * discountValue) / 100;
    } else if (discountType === 'fixed') {
      discountAmount = discountValue;
    }

    return subtotal + tva - discountAmount;
  };

  if (loadingInvoice) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <p>Chargement...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="sm" onClick={() => navigate("/invoices")}>
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <h1 className="text-2xl font-bold">Modifier la facture</h1>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Formulaire principal */}
          <div className="lg:col-span-2">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                {/* Informations générales */}
                <Card>
                  <CardHeader>
                    <CardTitle>Informations générales</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <FormField
                      control={form.control}
                      name="client_id"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Client *</FormLabel>
                          <Select onValueChange={field.onChange} value={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Sélectionner un client" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {clients.map((client) => (
                                <SelectItem key={client.id} value={client.id}>
                                  {client.name} - {client.type}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="date_issued"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Date d'émission *</FormLabel>
                            <FormControl>
                              <Input type="date" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="date_due"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Date d'échéance</FormLabel>
                            <FormControl>
                              <Input type="date" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  </CardContent>
                </Card>

                {/* Articles */}
                <Card>
                  <CardHeader>
                    <CardTitle>Articles</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {fields.map((field, index) => (
                      <div key={field.id} className="p-4 border rounded-lg space-y-4">
                        <div className="flex justify-between items-center mb-2">
                          <span className="font-medium">Article {index + 1}</span>
                          {fields.length > 1 && (
                            <Button
                              type="button"
                              variant="ghost"
                              size="sm"
                              onClick={() => remove(index)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          )}
                        </div>

                        <FormField
                          control={form.control}
                          name={`items.${index}.description`}
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Description *</FormLabel>
                              <FormControl>
                                <Input {...field} placeholder="Description de l'article" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <div className="grid grid-cols-3 gap-4">
                          <FormField
                            control={form.control}
                            name={`items.${index}.quantity`}
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Quantité *</FormLabel>
                                <FormControl>
                                  <Input
                                    type="number"
                                    step="0.01"
                                    {...field}
                                    onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={form.control}
                            name={`items.${index}.unit_price`}
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Prix unitaire *</FormLabel>
                                <FormControl>
                                  <Input
                                    type="number"
                                    step="0.01"
                                    {...field}
                                    onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={form.control}
                            name={`items.${index}.tva_rate`}
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>TVA (%)</FormLabel>
                                <FormControl>
                                  <Input
                                    type="number"
                                    step="0.01"
                                    {...field}
                                    onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>

                        <div className="text-sm text-muted-foreground">
                          Total: {calculateItemTotal(
                            form.watch(`items.${index}.quantity`),
                            form.watch(`items.${index}.unit_price`)
                          )} FCFA
                        </div>
                      </div>
                    ))}

                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => append({ description: "", quantity: 1, unit_price: 0, tva_rate: 18 })}
                      className="w-full"
                    >
                      <Plus className="h-4 w-4 mr-2" />
                      Ajouter un article
                    </Button>
                  </CardContent>
                </Card>

                {/* Remise */}
                <Card>
                  <CardHeader>
                    <CardTitle>Remise</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="discount_type"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Type de remise</FormLabel>
                            <Select onValueChange={field.onChange} value={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="none">Aucune</SelectItem>
                                <SelectItem value="percentage">Pourcentage</SelectItem>
                                <SelectItem value="fixed">Montant fixe</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      {form.watch("discount_type") !== "none" && (
                        <FormField
                          control={form.control}
                          name="discount_value"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>
                                Valeur {form.watch("discount_type") === "percentage" ? "(%)" : "(FCFA)"}
                              </FormLabel>
                              <FormControl>
                                <Input
                                  type="number"
                                  step="0.01"
                                  {...field}
                                  onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      )}
                    </div>
                  </CardContent>
                </Card>

                {/* Notes et conditions */}
                <Card>
                  <CardHeader>
                    <CardTitle>Notes et conditions</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <FormField
                      control={form.control}
                      name="notes"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Notes</FormLabel>
                          <FormControl>
                            <Textarea {...field} rows={3} placeholder="Notes additionnelles..." />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="terms"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Conditions de paiement</FormLabel>
                          <FormControl>
                            <Textarea {...field} rows={3} placeholder="Conditions de paiement..." />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </CardContent>
                </Card>

                <div className="flex gap-4">
                  <Button type="submit" disabled={loading} className="flex-1">
                    <Save className="h-4 w-4 mr-2" />
                    {loading ? "Enregistrement..." : "Enregistrer les modifications"}
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => navigate("/invoices")}
                  >
                    Annuler
                  </Button>
                </div>
              </form>
            </Form>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Récapitulatif */}
            <Card>
              <CardHeader>
                <CardTitle>Récapitulatif</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="flex justify-between">
                  <span>Sous-total:</span>
                  <span className="font-medium">{calculateSubtotal().toFixed(2)} FCFA</span>
                </div>
                <div className="flex justify-between">
                  <span>TVA:</span>
                  <span className="font-medium">{calculateTVA().toFixed(2)} FCFA</span>
                </div>
                <div className="flex justify-between text-lg font-bold pt-2 border-t">
                  <span>Total:</span>
                  <span>{calculateTotal().toFixed(2)} FCFA</span>
                </div>
              </CardContent>
            </Card>

            {/* Produits rapides */}
            <Card>
              <CardHeader>
                <CardTitle>Produits rapides</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 max-h-96 overflow-y-auto">
                  {products.map((product) => (
                    <Button
                      key={product.id}
                      type="button"
                      variant="outline"
                      className="w-full justify-start text-left"
                      onClick={() => addProductToInvoice(product)}
                    >
                      <div className="flex flex-col items-start">
                        <span className="font-medium">{product.name}</span>
                        <span className="text-sm text-muted-foreground">
                          {product.price} FCFA - TVA {product.tva_rate}%
                        </span>
                      </div>
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EditInvoice;
