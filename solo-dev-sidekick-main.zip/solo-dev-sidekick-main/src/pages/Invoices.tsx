import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { InvoiceCard } from "@/components/InvoiceCard";
import InvoiceImportDialog from "@/components/InvoiceImportDialog";
import { Plus, Search, ArrowLeft, Filter, TrendingUp, DollarSign, CheckCircle2, Clock, Building2 } from "lucide-react";
import { Area, AreaChart, CartesianGrid, XAxis, YAxis, ResponsiveContainer, Tooltip } from "recharts";
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart";

const Invoices = () => {
  const [invoices, setInvoices] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [fneStatusFilter, setFneStatusFilter] = useState<string>("all");
  const [showFilters, setShowFilters] = useState(false);
  const [companyInfo, setCompanyInfo] = useState<any>(null);
  const navigate = useNavigate();
  const { toast } = useToast();

  const loadInvoices = async () => {
    try {
      setLoading(true);
      
      // Charger les infos de l'entreprise
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        const { data: profileData } = await supabase
          .from('profiles')
          .select('*, companies(*)')
          .eq('user_id', user.id)
          .maybeSingle();
        setCompanyInfo(profileData);
      }

      const { data, error } = await supabase
        .from('invoices')
        .select(`
          *,
          clients (name),
          invoice_items (*)
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setInvoices(data || []);
    } catch (error: any) {
      toast({
        title: "Erreur",
        description: "Impossible de charger les factures",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadInvoices();
  }, []);

  const filteredInvoices = invoices.filter(invoice => {
    const matchesSearch = !searchTerm || 
      invoice.invoice_number.toLowerCase().includes(searchTerm.toLowerCase()) ||
      invoice.clients?.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      invoice.total_amount.toString().includes(searchTerm);
    
    const matchesStatus = statusFilter === "all" || invoice.status === statusFilter;
    const matchesFneStatus = fneStatusFilter === "all" || 
      (fneStatusFilter === "draft" && (!invoice.fne_status || invoice.fne_status === "draft")) ||
      invoice.fne_status === fneStatusFilter;
    
    return matchesSearch && matchesStatus && matchesFneStatus;
  });

  // Préparer les données pour le graphique (derniers 6 mois)
  const chartData = React.useMemo(() => {
    const monthlyData = new Map();
    const now = new Date();
    
    // Initialiser les 6 derniers mois
    for (let i = 5; i >= 0; i--) {
      const date = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const key = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
      const monthName = date.toLocaleDateString('fr-FR', { month: 'short' });
      monthlyData.set(key, { month: monthName, revenue: 0, count: 0 });
    }
    
    // Agréger les données réelles
    invoices.forEach(invoice => {
      const date = new Date(invoice.created_at);
      const key = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
      if (monthlyData.has(key)) {
        const current = monthlyData.get(key);
        current.revenue += parseFloat(invoice.total_amount) || 0;
        current.count += 1;
      }
    });
    
    return Array.from(monthlyData.values());
  }, [invoices]);

  const totalRevenue = invoices.reduce((sum, inv) => sum + (parseFloat(inv.total_amount) || 0), 0);
  const validatedCount = invoices.filter(inv => inv.fne_status === 'validated').length;
  const pendingCount = invoices.filter(inv => inv.fne_status === 'sent').length;
  const draftCount = invoices.filter(inv => inv.fne_status === 'draft' || !inv.fne_status).length;

  return (
    <div className="min-h-screen bg-gradient-to-br from-[hsl(var(--dashboard-gradient-start))] via-[hsl(var(--background))] to-[hsl(var(--dashboard-gradient-end))] relative overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-96 h-96 bg-[hsl(var(--accent-blue))]/10 rounded-full blur-3xl animate-pulse" />
        <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-[hsl(var(--accent-purple))]/10 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-[hsl(var(--accent-green))]/5 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '2s' }} />
      </div>

      {/* Header premium */}
      <header className="sticky top-0 z-40 border-b bg-card/60 backdrop-blur-2xl shadow-lg">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="sm" onClick={() => navigate("/dashboard")} className="hover:scale-110 transition-transform">
                <ArrowLeft className="h-4 w-4" />
              </Button>
              <div className="flex items-center gap-3">
                {companyInfo?.company?.logo_url ? (
                  <img 
                    src={companyInfo.company.logo_url} 
                    alt="Logo" 
                    className="h-10 w-10 rounded-lg object-cover border-2 border-primary/20"
                  />
                ) : (
                  <div className="p-2 rounded-lg bg-gradient-to-br from-[hsl(var(--accent-blue))] to-[hsl(var(--accent-purple))]">
                    <Building2 className="h-5 w-5 text-white" />
                  </div>
                )}
                <div>
                  <h1 className="text-2xl sm:text-3xl font-bold bg-gradient-to-r from-[hsl(var(--accent-blue))] via-primary to-[hsl(var(--accent-purple))] bg-clip-text text-transparent">
                    Factures
                  </h1>
                  <p className="text-xs text-muted-foreground hidden sm:block">Gestion et suivi</p>
                </div>
              </div>
            </div>
            <div className="flex gap-2">
              <InvoiceImportDialog onImportComplete={loadInvoices} />
              <Button onClick={() => navigate("/invoices/new")} className="group hover:scale-105 transition-all duration-300 shadow-lg hover:shadow-xl">
                <Plus className="h-4 w-4 mr-2 group-hover:rotate-90 transition-transform" />
                Nouvelle facture
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8 relative">
        {/* Hero Stats Section avec animations */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="group hover:shadow-2xl transition-all duration-500 hover:-translate-y-2 border-[hsl(var(--accent-blue))]/30 bg-gradient-to-br from-card via-card to-[hsl(var(--accent-blue))]/10 overflow-hidden relative animate-fade-in">
            <div className="absolute top-0 right-0 w-32 h-32 bg-[hsl(var(--accent-blue))]/20 rounded-full blur-2xl -mr-16 -mt-16 group-hover:scale-150 transition-transform duration-500" />
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 relative z-10">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total factures</CardTitle>
              <div className="p-2.5 rounded-xl bg-[hsl(var(--accent-blue))]/20 group-hover:bg-[hsl(var(--accent-blue))]/30 transition-colors duration-300 group-hover:scale-110 group-hover:rotate-6">
                <TrendingUp className="h-5 w-5 text-[hsl(var(--accent-blue))]" />
              </div>
            </CardHeader>
            <CardContent className="relative z-10">
              <div className="text-4xl font-bold text-[hsl(var(--accent-blue))] mb-1">{invoices.length}</div>
              <p className="text-xs text-muted-foreground">Factures émises</p>
            </CardContent>
          </Card>
          
          <Card className="group hover:shadow-2xl transition-all duration-500 hover:-translate-y-2 border-[hsl(var(--accent-green))]/30 bg-gradient-to-br from-card via-card to-[hsl(var(--accent-green))]/10 overflow-hidden relative animate-fade-in" style={{ animationDelay: '0.1s' }}>
            <div className="absolute top-0 right-0 w-32 h-32 bg-[hsl(var(--accent-green))]/20 rounded-full blur-2xl -mr-16 -mt-16 group-hover:scale-150 transition-transform duration-500" />
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 relative z-10">
              <CardTitle className="text-sm font-medium text-muted-foreground">Validées DGI</CardTitle>
              <div className="p-2.5 rounded-xl bg-[hsl(var(--accent-green))]/20 group-hover:bg-[hsl(var(--accent-green))]/30 transition-colors duration-300 group-hover:scale-110 group-hover:rotate-6">
                <CheckCircle2 className="h-5 w-5 text-[hsl(var(--accent-green))]" />
              </div>
            </CardHeader>
            <CardContent className="relative z-10">
              <div className="text-4xl font-bold text-[hsl(var(--accent-green))] mb-1">{validatedCount}</div>
              <p className="text-xs text-muted-foreground">Conformes et validées</p>
            </CardContent>
          </Card>
          
          <Card className="group hover:shadow-2xl transition-all duration-500 hover:-translate-y-2 border-primary/30 bg-gradient-to-br from-card via-card to-primary/10 overflow-hidden relative animate-fade-in" style={{ animationDelay: '0.2s' }}>
            <div className="absolute top-0 right-0 w-32 h-32 bg-primary/20 rounded-full blur-2xl -mr-16 -mt-16 group-hover:scale-150 transition-transform duration-500" />
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 relative z-10">
              <CardTitle className="text-sm font-medium text-muted-foreground">En attente DGI</CardTitle>
              <div className="p-2.5 rounded-xl bg-primary/20 group-hover:bg-primary/30 transition-colors duration-300 group-hover:scale-110 group-hover:rotate-6">
                <Clock className="h-5 w-5 text-primary" />
              </div>
            </CardHeader>
            <CardContent className="relative z-10">
              <div className="text-4xl font-bold text-primary mb-1">{pendingCount}</div>
              <p className="text-xs text-muted-foreground">En cours de validation</p>
            </CardContent>
          </Card>
          
          <Card className="group hover:shadow-2xl transition-all duration-500 hover:-translate-y-2 border-[hsl(var(--accent-purple))]/30 bg-gradient-to-br from-card via-card to-[hsl(var(--accent-purple))]/10 overflow-hidden relative animate-fade-in" style={{ animationDelay: '0.3s' }}>
            <div className="absolute top-0 right-0 w-32 h-32 bg-[hsl(var(--accent-purple))]/20 rounded-full blur-2xl -mr-16 -mt-16 group-hover:scale-150 transition-transform duration-500" />
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 relative z-10">
              <CardTitle className="text-sm font-medium text-muted-foreground">Chiffre d'affaires</CardTitle>
              <div className="p-2.5 rounded-xl bg-[hsl(var(--accent-purple))]/20 group-hover:bg-[hsl(var(--accent-purple))]/30 transition-colors duration-300 group-hover:scale-110 group-hover:rotate-6">
                <DollarSign className="h-5 w-5 text-[hsl(var(--accent-purple))]" />
              </div>
            </CardHeader>
            <CardContent className="relative z-10">
              <div className="text-3xl font-bold text-[hsl(var(--accent-purple))] mb-1">
                {totalRevenue.toLocaleString()} <span className="text-base">CFA</span>
              </div>
              <p className="text-xs text-muted-foreground">Revenus totaux</p>
            </CardContent>
          </Card>
        </div>

        {/* Graphique d'évolution */}
        <Card className="mb-8 hover:shadow-2xl transition-all duration-300 border-[hsl(var(--accent-blue))]/20 animate-fade-in" style={{ animationDelay: '0.4s' }}>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <div className="p-2 rounded-lg bg-gradient-to-br from-[hsl(var(--accent-blue))] to-[hsl(var(--accent-purple))]">
                <TrendingUp className="h-5 w-5 text-white" />
              </div>
              Évolution du chiffre d'affaires
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ChartContainer
              config={{
                revenue: {
                  label: "Revenus",
                  color: "hsl(var(--chart-1))",
                },
              }}
              className="h-[300px] w-full"
            >
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData}>
                  <defs>
                    <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(var(--chart-1))" stopOpacity={0.4}/>
                      <stop offset="95%" stopColor="hsl(var(--chart-1))" stopOpacity={0.05}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted/30" />
                  <XAxis dataKey="month" className="text-xs" />
                  <YAxis className="text-xs" />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Area
                    type="monotone"
                    dataKey="revenue"
                    stroke="hsl(var(--chart-1))"
                    fillOpacity={1}
                    fill="url(#colorRevenue)"
                    strokeWidth={3}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </ChartContainer>
          </CardContent>
        </Card>

        {/* Barre de recherche et filtres premium */}
        <Card className="mb-6 hover:shadow-xl transition-all duration-300 animate-fade-in" style={{ animationDelay: '0.5s' }}>
          <CardContent className="p-4 space-y-4">
            <div className="flex gap-2">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Rechercher par numéro, client ou montant..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 focus:ring-2 focus:ring-primary/50 transition-all"
                />
              </div>
              <Button
                variant="outline"
                size="icon"
                onClick={() => setShowFilters(!showFilters)}
                className="hover:scale-110 transition-transform"
              >
                <Filter className="h-4 w-4" />
              </Button>
            </div>
            
            {showFilters && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4 border-t animate-fade-in">
                <div>
                  <label className="text-sm font-medium mb-2 block">Statut paiement</label>
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger>
                      <SelectValue placeholder="Tous" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Tous</SelectItem>
                      <SelectItem value="draft">Brouillon</SelectItem>
                      <SelectItem value="pending">En attente</SelectItem>
                      <SelectItem value="paid">Payée</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <label className="text-sm font-medium mb-2 block">Statut DGI</label>
                  <Select value={fneStatusFilter} onValueChange={setFneStatusFilter}>
                    <SelectTrigger>
                      <SelectValue placeholder="Tous" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Tous</SelectItem>
                      <SelectItem value="draft">Brouillon</SelectItem>
                      <SelectItem value="sent">En attente DGI</SelectItem>
                      <SelectItem value="validated">Validée DGI</SelectItem>
                      <SelectItem value="rejected">Rejetée</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Liste des factures */}
        {loading ? (
          <div className="text-center py-8">
            <div className="inline-block animate-spin rounded-full h-12 w-12 border-4 border-primary border-t-transparent"></div>
            <p className="mt-4 text-muted-foreground">Chargement des factures...</p>
          </div>
        ) : filteredInvoices.length === 0 ? (
          <Card className="animate-fade-in">
            <CardContent className="p-12 text-center">
              <div className="mb-4 inline-block p-4 rounded-full bg-primary/10">
                <Plus className="h-12 w-12 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-2">
                {searchTerm ? "Aucune facture trouvée" : "Aucune facture créée"}
              </h3>
              <p className="text-muted-foreground mb-6">
                {searchTerm ? "Essayez avec d'autres termes de recherche" : "Commencez par créer votre première facture"}
              </p>
              {!searchTerm && (
                <Button onClick={() => navigate("/invoices/new")} className="hover:scale-105 transition-transform">
                  <Plus className="h-4 w-4 mr-2" />
                  Créer votre première facture
                </Button>
              )}
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-4">
            {filteredInvoices.map((invoice, index) => (
              <div 
                key={invoice.id} 
                className="animate-fade-in"
                style={{ animationDelay: `${0.6 + (index * 0.05)}s` }}
              >
                <InvoiceCard 
                  invoice={{
                    ...invoice,
                    client: { name: invoice.clients?.name || 'Client inconnu' }
                  }}
                  onUpdate={loadInvoices}
                  onDelete={loadInvoices}
                />
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default Invoices;
