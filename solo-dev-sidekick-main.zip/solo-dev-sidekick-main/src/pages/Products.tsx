import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { z } from "zod";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { ArrowLeft, Plus, Package, Search, Trash2, DollarSign, TrendingUp, Sparkles, Building2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

const productSchema = z.object({
  name: z.string()
    .trim()
    .min(1, "Le nom est requis")
    .max(255, "Le nom ne peut pas dépasser 255 caractères"),
  description: z.string()
    .trim()
    .max(2000, "La description ne peut pas dépasser 2000 caractères")
    .optional()
    .or(z.literal("")),
  price: z.string()
    .refine((val) => !isNaN(parseFloat(val)) && parseFloat(val) >= 0, "Le prix doit être un nombre positif"),
  unit: z.string().trim().max(50, "L'unité ne peut pas dépasser 50 caractères"),
  category: z.string()
    .trim()
    .max(100, "La catégorie ne peut pas dépasser 100 caractères")
    .optional()
    .or(z.literal("")),
  tva_rate: z.string()
    .refine((val) => !isNaN(parseFloat(val)) && parseFloat(val) >= 0 && parseFloat(val) <= 100, "Le taux TVA doit être entre 0 et 100"),
  is_service: z.boolean()
});

const Products = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [showNewProductForm, setShowNewProductForm] = useState(false);
  const [products, setProducts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [companyId, setCompanyId] = useState<string | null>(null);
  const [companyInfo, setCompanyInfo] = useState<any>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [newProduct, setNewProduct] = useState({
    name: "",
    description: "",
    price: "",
    unit: "unité",
    category: "",
    tva_rate: "18",
    is_service: false
  });

  useEffect(() => {
    loadCompanyAndProducts();
  }, []);

  const loadCompanyAndProducts = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data: profile } = await supabase
        .from('profiles')
        .select('company_id, companies(*)')
        .eq('user_id', user.id)
        .single();

      if (profile?.company_id) {
        setCompanyId(profile.company_id);
        setCompanyInfo(profile);
        const { data: productsData } = await supabase
          .from('products')
          .select('*')
          .eq('company_id', profile.company_id)
          .order('created_at', { ascending: false });
        
        setProducts(productsData || []);
      }
    } catch (error) {
      console.error('Error loading products:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteProduct = async (productId: string) => {
    try {
      const { error } = await supabase
        .from('products')
        .delete()
        .eq('id', productId);

      if (error) throw error;

      toast({
        title: "✅ Produit supprimé",
        description: "Le produit a été supprimé avec succès.",
      });
      
      loadCompanyAndProducts();
    } catch (error) {
      console.error('Error deleting product:', error);
      toast({
        title: "Erreur",
        description: "Une erreur est survenue lors de la suppression du produit.",
        variant: "destructive",
      });
    }
  };

  const handleSubmitNewProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!companyId) {
      toast({
        title: "Erreur",
        description: "Veuillez d'abord configurer votre entreprise.",
        variant: "destructive",
      });
      return;
    }

    try {
      const validation = productSchema.safeParse(newProduct);
      if (!validation.success) {
        toast({
          title: "Erreur de validation",
          description: validation.error.errors[0].message,
          variant: "destructive",
        });
        return;
      }

      const { error } = await supabase
        .from('products')
        .insert([{
          name: validation.data.name,
          description: validation.data.description || null,
          price: parseFloat(validation.data.price),
          unit: validation.data.unit,
          category: validation.data.category || null,
          tva_rate: parseFloat(validation.data.tva_rate),
          is_service: validation.data.is_service,
          company_id: companyId
        }]);

      if (error) throw error;

      toast({
        title: "🎉 Produit ajouté",
        description: "Le nouveau produit a été ajouté avec succès.",
      });
      
      setShowNewProductForm(false);
      setNewProduct({
        name: "",
        description: "",
        price: "",
        unit: "unité",
        category: "",
        tva_rate: "18",
        is_service: false
      });
      
      loadCompanyAndProducts();
    } catch (error) {
      console.error('Error adding product:', error);
      toast({
        title: "Erreur",
        description: "Une erreur est survenue lors de l'ajout du produit.",
        variant: "destructive",
      });
    }
  };

  const filteredProducts = products.filter(product =>
    product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    product.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    product.category?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const totalValue = products.reduce((sum, p) => sum + parseFloat(p.price), 0);
  const servicesCount = products.filter(p => p.is_service).length;
  const productsCount = products.filter(p => !p.is_service).length;

  return (
    <div className="min-h-screen bg-gradient-to-br from-[hsl(var(--dashboard-gradient-start))] via-[hsl(var(--background))] to-[hsl(var(--dashboard-gradient-end))] relative overflow-hidden">
      {/* Animated background */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-96 h-96 bg-[hsl(var(--accent-blue))]/10 rounded-full blur-3xl animate-pulse" />
        <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-[hsl(var(--accent-purple))]/10 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
      </div>

      {/* Header premium */}
      <header className="sticky top-0 z-40 border-b bg-card/60 backdrop-blur-2xl shadow-lg">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="sm" onClick={() => navigate("/dashboard")} className="hover:scale-110 transition-transform">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Retour
              </Button>
              <div className="flex items-center gap-3">
                {companyInfo?.companies?.logo_url ? (
                  <img 
                    src={companyInfo.companies.logo_url} 
                    alt="Logo" 
                    className="h-10 w-10 rounded-lg object-cover border-2 border-primary/20"
                  />
                ) : (
                  <div className="p-2 rounded-lg bg-gradient-to-br from-[hsl(var(--accent-blue))] to-[hsl(var(--accent-purple))]">
                    <Building2 className="h-5 w-5 text-white" />
                  </div>
                )}
                <div>
                  <h1 className="text-2xl sm:text-3xl font-bold bg-gradient-to-r from-[hsl(var(--accent-blue))] via-primary to-[hsl(var(--accent-purple))] bg-clip-text text-transparent">
                    Produits & Services
                  </h1>
                  <p className="text-xs text-muted-foreground hidden sm:block">Catalogue et gestion</p>
                </div>
              </div>
            </div>
            <Button onClick={() => setShowNewProductForm(true)} className="group hover:scale-105 transition-all duration-300 shadow-lg hover:shadow-xl">
              <Plus className="h-4 w-4 mr-2 group-hover:rotate-90 transition-transform" />
              Nouveau produit
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8 relative">
        {!showNewProductForm && (
          <>
            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <Card className="group hover:shadow-2xl transition-all duration-500 hover:-translate-y-2 border-[hsl(var(--accent-blue))]/30 bg-gradient-to-br from-card via-card to-[hsl(var(--accent-blue))]/10 overflow-hidden relative animate-fade-in">
                <div className="absolute top-0 right-0 w-32 h-32 bg-[hsl(var(--accent-blue))]/20 rounded-full blur-2xl -mr-16 -mt-16 group-hover:scale-150 transition-transform duration-500" />
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 relative z-10">
                  <CardTitle className="text-sm font-medium text-muted-foreground">Total Articles</CardTitle>
                  <div className="p-2.5 rounded-xl bg-[hsl(var(--accent-blue))]/20 group-hover:bg-[hsl(var(--accent-blue))]/30 transition-colors duration-300 group-hover:scale-110 group-hover:rotate-6">
                    <Package className="h-5 w-5 text-[hsl(var(--accent-blue))]" />
                  </div>
                </CardHeader>
                <CardContent className="relative z-10">
                  <div className="text-4xl font-bold text-[hsl(var(--accent-blue))] mb-1">{products.length}</div>
                  <p className="text-xs text-muted-foreground">{productsCount} produits • {servicesCount} services</p>
                </CardContent>
              </Card>

              <Card className="group hover:shadow-2xl transition-all duration-500 hover:-translate-y-2 border-[hsl(var(--accent-purple))]/30 bg-gradient-to-br from-card via-card to-[hsl(var(--accent-purple))]/10 overflow-hidden relative animate-fade-in" style={{ animationDelay: '0.1s' }}>
                <div className="absolute top-0 right-0 w-32 h-32 bg-[hsl(var(--accent-purple))]/20 rounded-full blur-2xl -mr-16 -mt-16 group-hover:scale-150 transition-transform duration-500" />
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 relative z-10">
                  <CardTitle className="text-sm font-medium text-muted-foreground">Valeur Catalogue</CardTitle>
                  <div className="p-2.5 rounded-xl bg-[hsl(var(--accent-purple))]/20 group-hover:bg-[hsl(var(--accent-purple))]/30 transition-colors duration-300 group-hover:scale-110 group-hover:rotate-6">
                    <DollarSign className="h-5 w-5 text-[hsl(var(--accent-purple))]" />
                  </div>
                </CardHeader>
                <CardContent className="relative z-10">
                  <div className="text-3xl font-bold text-[hsl(var(--accent-purple))] mb-1">
                    {totalValue.toLocaleString()} <span className="text-base">CFA</span>
                  </div>
                  <p className="text-xs text-muted-foreground">Valeur totale moyenne</p>
                </CardContent>
              </Card>

              <Card className="group hover:shadow-2xl transition-all duration-500 hover:-translate-y-2 border-[hsl(var(--accent-green))]/30 bg-gradient-to-br from-card via-card to-[hsl(var(--accent-green))]/10 overflow-hidden relative animate-fade-in" style={{ animationDelay: '0.2s' }}>
                <div className="absolute top-0 right-0 w-32 h-32 bg-[hsl(var(--accent-green))]/20 rounded-full blur-2xl -mr-16 -mt-16 group-hover:scale-150 transition-transform duration-500" />
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 relative z-10">
                  <CardTitle className="text-sm font-medium text-muted-foreground">Récemment ajoutés</CardTitle>
                  <div className="p-2.5 rounded-xl bg-[hsl(var(--accent-green))]/20 group-hover:bg-[hsl(var(--accent-green))]/30 transition-colors duration-300 group-hover:scale-110 group-hover:rotate-6">
                    <Sparkles className="h-5 w-5 text-[hsl(var(--accent-green))]" />
                  </div>
                </CardHeader>
                <CardContent className="relative z-10">
                  <div className="text-4xl font-bold text-[hsl(var(--accent-green))] mb-1">
                    {products.slice(0, 5).length}
                  </div>
                  <p className="text-xs text-muted-foreground">Nouveaux cette semaine</p>
                </CardContent>
              </Card>
            </div>

            {/* Search Bar */}
            <Card className="mb-6 hover:shadow-xl transition-all duration-300 animate-fade-in" style={{ animationDelay: '0.3s' }}>
              <CardContent className="p-4">
                <div className="relative">
                  <Search className="h-4 w-4 absolute left-3 top-3 text-muted-foreground" />
                  <Input 
                    placeholder="Rechercher un produit ou service..." 
                    className="pl-10 focus:ring-2 focus:ring-primary/50 transition-all"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
              </CardContent>
            </Card>
          </>
        )}

        {/* Product Form or List */}
        {showNewProductForm ? (
          <Card className="max-w-2xl mx-auto hover:shadow-2xl transition-all duration-300 animate-fade-in">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <div className="p-2 rounded-lg bg-gradient-to-br from-[hsl(var(--accent-blue))] to-[hsl(var(--accent-purple))]">
                  <Package className="h-5 w-5 text-white" />
                </div>
                Nouveau {newProduct.is_service ? "Service" : "Produit"}
              </CardTitle>
              <CardDescription>
                Ajoutez un nouveau {newProduct.is_service ? "service" : "produit"} à votre catalogue
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmitNewProduct} className="space-y-6">
                <div className="flex items-center space-x-2 p-4 rounded-lg bg-primary/5 border border-primary/20">
                  <Switch
                    id="is_service"
                    checked={newProduct.is_service}
                    onCheckedChange={(checked) => setNewProduct({...newProduct, is_service: checked})}
                  />
                  <Label htmlFor="is_service" className="cursor-pointer">Il s'agit d'un service</Label>
                </div>

                <div>
                  <Label htmlFor="name">Nom du {newProduct.is_service ? "service" : "produit"} *</Label>
                  <Input
                    id="name"
                    value={newProduct.name}
                    onChange={(e) => setNewProduct({...newProduct, name: e.target.value})}
                    required
                    placeholder={newProduct.is_service ? "Ex: Consultation comptable" : "Ex: Ordinateur portable"}
                    className="mt-2"
                  />
                </div>

                <div>
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    value={newProduct.description}
                    onChange={(e) => setNewProduct({...newProduct, description: e.target.value})}
                    rows={3}
                    placeholder="Description détaillée du produit ou service"
                    className="mt-2"
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="price">Prix unitaire (CFA) *</Label>
                    <Input
                      id="price"
                      type="number"
                      value={newProduct.price}
                      onChange={(e) => setNewProduct({...newProduct, price: e.target.value})}
                      required
                      min="0"
                      step="0.01"
                      className="mt-2"
                    />
                  </div>
                  <div>
                    <Label htmlFor="unit">Unité</Label>
                    <Select value={newProduct.unit} onValueChange={(value) => setNewProduct({...newProduct, unit: value})}>
                      <SelectTrigger className="mt-2">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="unité">Unité</SelectItem>
                        <SelectItem value="kg">Kilogramme</SelectItem>
                        <SelectItem value="litre">Litre</SelectItem>
                        <SelectItem value="mètre">Mètre</SelectItem>
                        <SelectItem value="heure">Heure</SelectItem>
                        <SelectItem value="jour">Jour</SelectItem>
                        <SelectItem value="mois">Mois</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="category">Catégorie</Label>
                    <Input
                      id="category"
                      value={newProduct.category}
                      onChange={(e) => setNewProduct({...newProduct, category: e.target.value})}
                      placeholder="Ex: Électronique, Services, etc."
                      className="mt-2"
                    />
                  </div>
                  <div>
                    <Label htmlFor="tva_rate">Taux TVA (%)</Label>
                    <Select value={newProduct.tva_rate} onValueChange={(value) => setNewProduct({...newProduct, tva_rate: value})}>
                      <SelectTrigger className="mt-2">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="0">0% (Exonéré)</SelectItem>
                        <SelectItem value="18">18% (Standard)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="flex gap-4 pt-4">
                  <Button type="submit" className="flex-1 hover:scale-105 transition-transform">
                    <Plus className="h-4 w-4 mr-2" />
                    Enregistrer le {newProduct.is_service ? "service" : "produit"}
                  </Button>
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => setShowNewProductForm(false)}
                    className="hover:scale-105 transition-transform"
                  >
                    Annuler
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-6">
            {loading ? (
              <Card>
                <CardContent className="p-12 text-center">
                  <div className="inline-block animate-spin rounded-full h-12 w-12 border-4 border-primary border-t-transparent mb-4"></div>
                  <p className="text-muted-foreground">Chargement...</p>
                </CardContent>
              </Card>
            ) : filteredProducts.length === 0 ? (
              <Card className="animate-fade-in">
                <CardContent className="p-12 text-center">
                  <div className="mb-4 inline-block p-4 rounded-full bg-primary/10">
                    <Package className="h-16 w-16 text-primary" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">
                    {searchTerm ? "Aucun produit trouvé" : "Aucun produit dans le catalogue"}
                  </h3>
                  <p className="text-muted-foreground mb-6">
                    {searchTerm ? "Essayez avec d'autres termes de recherche" : "Commencez par ajouter votre premier produit ou service"}
                  </p>
                  {!searchTerm && (
                    <Button onClick={() => setShowNewProductForm(true)} className="hover:scale-105 transition-transform">
                      <Plus className="h-4 w-4 mr-2" />
                      Ajouter un produit
                    </Button>
                  )}
                </CardContent>
              </Card>
            ) : (
              <div className="grid gap-4">
                {filteredProducts.map((product, index) => (
                  <Card 
                    key={product.id} 
                    className="group hover:shadow-2xl transition-all duration-300 hover:-translate-y-1 border-l-4 border-l-primary/40 animate-fade-in"
                    style={{ animationDelay: `${0.4 + (index * 0.05)}s` }}
                  >
                    <CardContent className="p-6">
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <div className="p-2 rounded-lg bg-gradient-to-br from-[hsl(var(--accent-blue))]/20 to-[hsl(var(--accent-purple))]/20 group-hover:scale-110 transition-transform">
                              <Package className="h-5 w-5 text-primary" />
                            </div>
                            <h3 className="font-bold text-xl group-hover:text-primary transition-colors">{product.name}</h3>
                            {product.is_service && (
                              <span className="text-xs bg-[hsl(var(--accent-blue))]/20 text-[hsl(var(--accent-blue))] px-3 py-1 rounded-full font-medium">
                                Service
                              </span>
                            )}
                          </div>
                          {product.description && (
                            <p className="text-sm text-muted-foreground mt-2 mb-3">{product.description}</p>
                          )}
                          {product.category && (
                            <div className="inline-flex items-center gap-1 text-xs text-muted-foreground bg-muted/50 px-2 py-1 rounded">
                              <Sparkles className="h-3 w-3" />
                              {product.category}
                            </div>
                          )}
                        </div>
                        <div className="flex items-start gap-3">
                          <div className="text-right">
                            <p className="font-bold text-2xl text-primary">{product.price.toLocaleString()} CFA</p>
                            <p className="text-xs text-muted-foreground">/{product.unit}</p>
                            <p className="text-xs text-muted-foreground mt-2 bg-muted/50 px-2 py-1 rounded">TVA: {product.tva_rate}%</p>
                          </div>
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive hover:bg-destructive/10 hover:scale-110 transition-all">
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>Confirmer la suppression</AlertDialogTitle>
                                <AlertDialogDescription>
                                  Êtes-vous sûr de vouloir supprimer ce produit ? Cette action est irréversible.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Annuler</AlertDialogCancel>
                                <AlertDialogAction onClick={() => handleDeleteProduct(product.id)} className="bg-destructive hover:bg-destructive/90">
                                  Supprimer
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default Products;
