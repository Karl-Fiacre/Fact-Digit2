import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { z } from "zod";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, Plus, Users, Search, Trash2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";

const clientSchema = z.object({
  name: z.string()
    .trim()
    .min(1, "Le nom est requis")
    .max(255, "Le nom ne peut pas dépasser 255 caractères"),
  email: z.string()
    .trim()
    .email("Email invalide")
    .max(255, "L'email ne peut pas dépasser 255 caractères")
    .optional()
    .or(z.literal("")),
  phone: z.string()
    .trim()
    .max(50, "Le téléphone ne peut pas dépasser 50 caractères")
    .optional()
    .or(z.literal("")),
  address: z.string()
    .trim()
    .max(1000, "L'adresse ne peut pas dépasser 1000 caractères")
    .optional()
    .or(z.literal("")),
  type: z.enum(["particulier", "entreprise"]),
  rccm: z.string()
    .trim()
    .max(100, "Le RCCM ne peut pas dépasser 100 caractères")
    .optional()
    .or(z.literal("")),
  numero_cc: z.string()
    .trim()
    .max(100, "Le numéro CC ne peut pas dépasser 100 caractères")
    .optional()
    .or(z.literal(""))
}).required({ name: true });
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

const Clients = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [showNewClientForm, setShowNewClientForm] = useState(false);
  const [clients, setClients] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [companyId, setCompanyId] = useState<string | null>(null);
  const [newClient, setNewClient] = useState({
    name: "",
    email: "",
    phone: "",
    address: "",
    type: "particulier",
    rccm: "",
    numero_cc: ""
  });

  useEffect(() => {
    loadCompanyAndClients();
  }, []);

  const loadCompanyAndClients = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data: profile } = await supabase
        .from('profiles')
        .select('company_id')
        .eq('user_id', user.id)
        .single();

      if (profile?.company_id) {
        setCompanyId(profile.company_id);
        const { data: clientsData } = await supabase
          .from('clients')
          .select('*')
          .eq('company_id', profile.company_id)
          .order('created_at', { ascending: false });
        
        setClients(clientsData || []);
      }
    } catch (error) {
      console.error('Error loading clients:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteClient = async (clientId: string) => {
    try {
      const { error } = await supabase
        .from('clients')
        .delete()
        .eq('id', clientId);

      if (error) throw error;

      toast({
        title: "Client supprimé",
        description: "Le client a été supprimé avec succès.",
      });
      
      loadCompanyAndClients();
    } catch (error) {
      console.error('Error deleting client:', error);
      toast({
        title: "Erreur",
        description: "Une erreur est survenue lors de la suppression du client.",
        variant: "destructive",
      });
    }
  };

  const handleSubmitNewClient = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!companyId) {
      toast({
        title: "Erreur",
        description: "Veuillez d'abord configurer votre entreprise.",
        variant: "destructive",
      });
      return;
    }

    try {
      // Validate with zod
      const validation = clientSchema.safeParse(newClient);
      if (!validation.success) {
        toast({
          title: "Erreur de validation",
          description: validation.error.errors[0].message,
          variant: "destructive",
        });
        return;
      }

      const clientData = {
        name: validation.data.name,
        email: validation.data.email || null,
        phone: validation.data.phone || null,
        address: validation.data.address || null,
        type: validation.data.type,
        rccm: validation.data.rccm || null,
        numero_cc: validation.data.numero_cc || null,
        company_id: companyId
      };

      const { error } = await supabase
        .from('clients')
        .insert([clientData]);

      if (error) throw error;

      toast({
        title: "Client ajouté",
        description: "Le nouveau client a été ajouté avec succès.",
      });
      
      setShowNewClientForm(false);
      setNewClient({
        name: "",
        email: "",
        phone: "",
        address: "",
        type: "particulier",
        rccm: "",
        numero_cc: ""
      });
      
      loadCompanyAndClients();
    } catch (error) {
      console.error('Error adding client:', error);
      toast({
        title: "Erreur",
        description: "Une erreur est survenue lors de l'ajout du client.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-4 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 sm:gap-4">
          <div className="flex items-center gap-3 sm:gap-4">
            <Button variant="ghost" size="sm" onClick={() => navigate("/dashboard")}>
              <ArrowLeft className="h-4 w-4 sm:mr-2" />
              <span className="hidden sm:inline">Retour</span>
            </Button>
            <h1 className="text-lg sm:text-2xl font-bold">Gestion des Clients</h1>
          </div>
          <Button onClick={() => setShowNewClientForm(true)} size="sm" className="w-full sm:w-auto">
            <Plus className="h-4 w-4 mr-2" />
            Nouveau client
          </Button>
        </div>
      </header>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        {showNewClientForm ? (
          <Card className="max-w-2xl mx-auto">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                Nouveau Client
              </CardTitle>
              <CardDescription>
                Ajoutez un nouveau client à votre base de données
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmitNewClient} className="space-y-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
                  <div>
                    <Label htmlFor="name">Nom complet / Raison sociale *</Label>
                    <Input
                      id="name"
                      value={newClient.name}
                      onChange={(e) => setNewClient({...newClient, name: e.target.value})}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="type">Type de client</Label>
                    <Select value={newClient.type} onValueChange={(value) => setNewClient({...newClient, type: value})}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="particulier">Particulier</SelectItem>
                        <SelectItem value="entreprise">Entreprise</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
                  <div>
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      value={newClient.email}
                      onChange={(e) => setNewClient({...newClient, email: e.target.value})}
                    />
                  </div>
                  <div>
                    <Label htmlFor="phone">Téléphone</Label>
                    <Input
                      id="phone"
                      value={newClient.phone}
                      onChange={(e) => setNewClient({...newClient, phone: e.target.value})}
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="address">Adresse</Label>
                  <Textarea
                    id="address"
                    value={newClient.address}
                    onChange={(e) => setNewClient({...newClient, address: e.target.value})}
                    rows={3}
                  />
                </div>

                {newClient.type === "entreprise" && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
                    <div>
                      <Label htmlFor="rccm">RCCM</Label>
                      <Input
                        id="rccm"
                        value={newClient.rccm}
                        onChange={(e) => setNewClient({...newClient, rccm: e.target.value})}
                      />
                    </div>
                    <div>
                      <Label htmlFor="numero_cc">Numéro CC</Label>
                      <Input
                        id="numero_cc"
                        value={newClient.numero_cc}
                        onChange={(e) => setNewClient({...newClient, numero_cc: e.target.value})}
                      />
                    </div>
                  </div>
                )}

                <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 pt-4">
                  <Button type="submit" className="flex-1 order-2 sm:order-1">
                    Enregistrer le client
                  </Button>
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => setShowNewClientForm(false)}
                    className="flex-1 sm:flex-none order-1 sm:order-2"
                  >
                    Annuler
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-6">
            {/* Barre de recherche */}
            <Card>
              <CardContent className="p-3 sm:p-4">
                <div className="flex flex-col sm:flex-row gap-3 sm:gap-4">
                  <div className="relative flex-1">
                    <Search className="h-4 w-4 absolute left-3 top-3 text-muted-foreground" />
                    <Input placeholder="Rechercher un client..." className="pl-10 text-sm sm:text-base" />
                  </div>
                  <Button variant="outline" size="sm" className="w-full sm:w-auto">
                    Filtrer
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Liste des clients */}
            {loading ? (
              <Card>
                <CardContent className="p-6 sm:p-8 text-center">
                  <p className="text-muted-foreground">Chargement...</p>
                </CardContent>
              </Card>
            ) : clients.length === 0 ? (
              <Card>
                <CardContent className="p-6 sm:p-8 text-center">
                  <Users className="h-12 w-12 sm:h-16 sm:w-16 mx-auto text-muted-foreground mb-4" />
                  <h3 className="text-base sm:text-lg font-semibold mb-2">Aucun client trouvé</h3>
                  <p className="text-sm sm:text-base text-muted-foreground mb-6">
                    Commencez par ajouter votre premier client
                  </p>
                  <Button onClick={() => setShowNewClientForm(true)} className="w-full sm:w-auto">
                    <Plus className="h-4 w-4 mr-2" />
                    Ajouter un client
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="grid gap-4">
                {clients.map((client) => (
                  <Card key={client.id}>
                    <CardContent className="p-4">
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <h3 className="font-semibold text-lg">{client.name}</h3>
                          <p className="text-sm text-muted-foreground capitalize">{client.type}</p>
                          {client.email && <p className="text-sm mt-1">{client.email}</p>}
                          {client.phone && <p className="text-sm">{client.phone}</p>}
                          {client.address && <p className="text-sm text-muted-foreground mt-1">{client.address}</p>}
                        </div>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive">
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Confirmer la suppression</AlertDialogTitle>
                              <AlertDialogDescription>
                                Êtes-vous sûr de vouloir supprimer ce client ? Cette action est irréversible.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Annuler</AlertDialogCancel>
                              <AlertDialogAction onClick={() => handleDeleteClient(client.id)}>
                                Supprimer
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default Clients;