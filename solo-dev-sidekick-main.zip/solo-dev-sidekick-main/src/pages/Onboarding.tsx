import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { User } from "@supabase/supabase-js";

const Onboarding = () => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    // Données entreprise
    companyName: "",
    address: "",
    rccm: "",
    numeroCC: "",
    phone: "",
    email: "",
    website: "",
    // Données profil
    firstName: "",
    lastName: "",
    userPhone: "",
  });

  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    const checkUser = async () => {
      const { data: { user }, error } = await supabase.auth.getUser();
      
      if (error || !user) {
        toast({
          title: "Non authentifié",
          description: "Vous devez vous connecter pour accéder à cette page.",
          variant: "destructive",
        });
        navigate("/auth");
        return;
      }

      setUser(user);
    };

    checkUser();
  }, [navigate, toast]);

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    setLoading(true);
    try {
      // 1. Créer l'entreprise
      const { data: company, error: companyError } = await supabase
        .from("companies")
        .insert({
          name: formData.companyName,
          address: formData.address,
          rccm: formData.rccm,
          numero_cc: formData.numeroCC,
          phone: formData.phone,
          email: formData.email,
          website: formData.website,
        })
        .select()
        .single();

      if (companyError) throw companyError;

      // 2. Mettre à jour le profil utilisateur
      const { error: profileError } = await supabase
        .from("profiles")
        .update({
          company_id: company.id,
          first_name: formData.firstName,
          last_name: formData.lastName,
          phone: formData.userPhone,
        })
        .eq("user_id", user.id);

      if (profileError) throw profileError;

      toast({
        title: "Configuration terminée !",
        description: "Votre entreprise a été créée avec succès.",
      });

      navigate("/dashboard");
    } catch (error: any) {
      toast({
        title: "Erreur",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/20 to-secondary/20 p-4">
      <div className="container mx-auto max-w-2xl py-8">
        <Card>
          <CardHeader className="text-center">
            <CardTitle className="text-2xl">Configuration de votre entreprise</CardTitle>
            <CardDescription>
              Renseignez les informations de votre entreprise pour commencer à utiliser Fact-Digit
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Informations personnelles */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Vos informations</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="firstName">Prénom</Label>
                    <Input
                      id="firstName"
                      value={formData.firstName}
                      onChange={(e) => handleInputChange("firstName", e.target.value)}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="lastName">Nom</Label>
                    <Input
                      id="lastName"
                      value={formData.lastName}
                      onChange={(e) => handleInputChange("lastName", e.target.value)}
                      required
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="userPhone">Téléphone</Label>
                  <Input
                    id="userPhone"
                    value={formData.userPhone}
                    onChange={(e) => handleInputChange("userPhone", e.target.value)}
                  />
                </div>
              </div>

              {/* Informations entreprise */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Informations de l'entreprise</h3>
                <div className="space-y-2">
                  <Label htmlFor="companyName">Nom de l'entreprise *</Label>
                  <Input
                    id="companyName"
                    value={formData.companyName}
                    onChange={(e) => handleInputChange("companyName", e.target.value)}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="address">Adresse</Label>
                  <Input
                    id="address"
                    value={formData.address}
                    onChange={(e) => handleInputChange("address", e.target.value)}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="rccm">RCCM</Label>
                    <Input
                      id="rccm"
                      value={formData.rccm}
                      onChange={(e) => handleInputChange("rccm", e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="numeroCC">N° Compte Contribuable</Label>
                    <Input
                      id="numeroCC"
                      value={formData.numeroCC}
                      onChange={(e) => handleInputChange("numeroCC", e.target.value)}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="phone">Téléphone</Label>
                    <Input
                      id="phone"
                      value={formData.phone}
                      onChange={(e) => handleInputChange("phone", e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => handleInputChange("email", e.target.value)}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="website">Site web</Label>
                  <Input
                    id="website"
                    value={formData.website}
                    onChange={(e) => handleInputChange("website", e.target.value)}
                  />
                </div>
              </div>

              <Button type="submit" className="w-full" disabled={loading}>
                {loading ? "Configuration..." : "Terminer la configuration"}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Onboarding;