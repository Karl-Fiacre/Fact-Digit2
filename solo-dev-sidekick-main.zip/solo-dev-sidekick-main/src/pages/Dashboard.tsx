import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import ElectronStatus from "@/components/desktop/ElectronStatus";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { User, Session } from "@supabase/supabase-js";
import { FileText, Users, Package, Receipt, Plus, LogOut, TrendingUp, ArrowUpRight, Building2 } from "lucide-react";
import ResponsiveCard from "@/components/ui/responsive-card";
import { Area, AreaChart, Bar, BarChart, CartesianGrid, XAxis, YAxis, ResponsiveContainer } from "recharts";
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart";

const Dashboard = () => {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [stats, setStats] = useState({
    clients: 0,
    products: 0,
    invoices: 0,
    totalRevenue: 0,
    totalTVA: 0,
  });
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    const loadData = async () => {
      setIsLoading(true);
      
      const { data: { user }, error } = await supabase.auth.getUser();
      
      if (error || !user) {
        navigate("/auth");
        return;
      }
      
      setUser(user);
      
      // Charger session et profil en parallèle
      const [sessionRes, profileRes] = await Promise.all([
        supabase.auth.getSession(),
        supabase
          .from('profiles')
          .select('user_id, first_name, last_name, company_id, company:companies(id, name, logo_url)')
          .eq('user_id', user.id)
          .single()
      ]);

      setSession(sessionRes.data.session);

      if (!profileRes.data?.company_id) {
        setProfile(profileRes.data);
        setIsLoading(false);
        return;
      }

      setProfile(profileRes.data);

      // Requêtes de statistiques ultra-optimisées en parallèle
      const [clientsRes, productsRes, invoicesRes, invoiceSums] = await Promise.all([
        supabase.from('clients').select('id', { count: 'exact', head: true }).eq('company_id', profileRes.data.company_id),
        supabase.from('products').select('id', { count: 'exact', head: true }).eq('company_id', profileRes.data.company_id),
        supabase.from('invoices').select('id', { count: 'exact', head: true }).eq('company_id', profileRes.data.company_id),
        supabase.from('invoices').select('total_amount, tva_amount').eq('company_id', profileRes.data.company_id)
      ]);

      const totalRevenue = invoiceSums.data?.reduce((sum, inv) => sum + (parseFloat(String(inv.total_amount)) || 0), 0) || 0;
      const totalTVA = invoiceSums.data?.reduce((sum, inv) => sum + (parseFloat(String(inv.tva_amount)) || 0), 0) || 0;

      setStats({
        clients: clientsRes.count || 0,
        products: productsRes.count || 0,
        invoices: invoicesRes.count || 0,
        totalRevenue,
        totalTVA,
      });

      setIsLoading(false);
    };

    loadData();
  }, [navigate]);

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    navigate("/auth");
  };

  const navigateToOnboarding = () => {
    navigate("/onboarding");
  };

  if (!user) {
    return null;
  }

  // Désactiver la vérification d'onboarding
  if (false) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <CardTitle>Bienvenue sur Fact-Digit!</CardTitle>
            <CardDescription>
              Configurons votre entreprise pour commencer
            </CardDescription>
          </CardHeader>
          <CardContent className="text-center">
            <Button onClick={navigateToOnboarding} className="w-full">
              Configurer mon entreprise
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Mock data for charts
  const revenueData = [
    { month: "Jan", revenue: stats.totalRevenue * 0.7 },
    { month: "Fév", revenue: stats.totalRevenue * 0.8 },
    { month: "Mar", revenue: stats.totalRevenue * 0.75 },
    { month: "Avr", revenue: stats.totalRevenue * 0.9 },
    { month: "Mai", revenue: stats.totalRevenue * 0.95 },
    { month: "Juin", revenue: stats.totalRevenue },
  ];

  const statsData = [
    { name: "Clients", value: stats.clients },
    { name: "Produits", value: stats.products },
    { name: "Factures", value: stats.invoices },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-[hsl(var(--dashboard-gradient-start))] via-[hsl(var(--background))] to-[hsl(var(--dashboard-gradient-end))] relative overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-[hsl(var(--accent-blue))]/10 rounded-full blur-3xl animate-pulse" />
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-[hsl(var(--accent-purple))]/10 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
      </div>

      {/* Header */}
      <header className="sticky top-0 z-40 border-b bg-card/60 backdrop-blur-2xl shadow-sm">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-3">
              {profile?.company?.logo_url ? (
                <img 
                  src={profile.company.logo_url} 
                  alt="Logo entreprise" 
                  className="h-12 w-12 rounded-xl object-cover border-2 border-primary/20 shadow-lg"
                />
              ) : (
                <div className="p-2 rounded-xl bg-gradient-to-br from-[hsl(var(--accent-blue))] to-[hsl(var(--accent-purple))] shadow-lg">
                  <Building2 className="h-6 w-6 text-white" />
                </div>
              )}
              <div>
                <h1 className="text-xl sm:text-3xl font-bold bg-gradient-to-r from-[hsl(var(--accent-blue))] via-primary to-[hsl(var(--accent-purple))] bg-clip-text text-transparent">
                  {profile?.company?.name || "Fact-Digit"}
                </h1>
                <p className="text-xs text-muted-foreground hidden sm:block">Tableau de bord</p>
              </div>
            </div>
            <div className="flex items-center gap-2 sm:gap-4">
              <div className="hidden md:flex flex-col items-end">
                <span className="text-sm font-semibold text-foreground">
                  {profile?.company?.name || profile?.first_name || "Utilisateur"}
                </span>
                <span className="text-xs text-muted-foreground">Administrateur</span>
              </div>
              <Button variant="ghost" size="sm" onClick={handleSignOut} className="hover:bg-destructive/10 hover:text-destructive transition-colors">
                <LogOut className="h-4 w-4 sm:mr-2" />
                <span className="hidden sm:inline">Déconnexion</span>
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 relative">
        {/* Welcome Section */}
        <div className="mb-8 animate-fade-in">
          <h2 className="text-2xl sm:text-4xl font-bold text-foreground mb-2">
            Bonjour, {profile?.company?.name || profile?.first_name || "Utilisateur"} 👋
          </h2>
          <p className="text-sm sm:text-base text-muted-foreground">Voici un aperçu de votre activité</p>
        </div>

        {/* Statistiques principales */}
        <div className="grid gap-4 sm:gap-6 grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 mb-8 sm:mb-10">
          <Card className="group hover:shadow-2xl transition-all duration-500 hover:-translate-y-2 border-[hsl(var(--accent-blue))]/30 bg-gradient-to-br from-card via-card to-[hsl(var(--accent-blue))]/10 overflow-hidden relative">
            <div className="absolute top-0 right-0 w-32 h-32 bg-[hsl(var(--accent-blue))]/20 rounded-full blur-2xl -mr-16 -mt-16 group-hover:scale-150 transition-transform duration-500" />
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 relative z-10">
              <CardTitle className="text-sm font-medium text-muted-foreground">Clients</CardTitle>
              <div className="p-2.5 rounded-xl bg-[hsl(var(--accent-blue))]/20 group-hover:bg-[hsl(var(--accent-blue))]/30 transition-colors duration-300 group-hover:scale-110">
                <Users className="h-5 w-5 text-[hsl(var(--accent-blue))]" />
              </div>
            </CardHeader>
            <CardContent className="relative z-10">
              {isLoading ? (
                <div className="space-y-2">
                  <Skeleton className="h-10 w-24" />
                  <Skeleton className="h-4 w-32" />
                </div>
              ) : (
                <>
                  <div className="text-3xl sm:text-4xl font-bold text-[hsl(var(--accent-blue))] mb-1 flex items-end gap-2">
                    {stats.clients}
                    <TrendingUp className="h-5 w-5 text-[hsl(var(--accent-green))] mb-1" />
                  </div>
                  <p className="text-xs text-muted-foreground">Total de clients actifs</p>
                </>
              )}
            </CardContent>
          </Card>

          <Card className="group hover:shadow-2xl transition-all duration-500 hover:-translate-y-2 border-[hsl(var(--accent-purple))]/30 bg-gradient-to-br from-card via-card to-[hsl(var(--accent-purple))]/10 overflow-hidden relative">
            <div className="absolute top-0 right-0 w-32 h-32 bg-[hsl(var(--accent-purple))]/20 rounded-full blur-2xl -mr-16 -mt-16 group-hover:scale-150 transition-transform duration-500" />
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 relative z-10">
              <CardTitle className="text-sm font-medium text-muted-foreground">Produits</CardTitle>
              <div className="p-2.5 rounded-xl bg-[hsl(var(--accent-purple))]/20 group-hover:bg-[hsl(var(--accent-purple))]/30 transition-colors duration-300 group-hover:scale-110">
                <Package className="h-5 w-5 text-[hsl(var(--accent-purple))]" />
              </div>
            </CardHeader>
            <CardContent className="relative z-10">
              {isLoading ? (
                <div className="space-y-2">
                  <Skeleton className="h-10 w-24" />
                  <Skeleton className="h-4 w-32" />
                </div>
              ) : (
                <>
                  <div className="text-3xl sm:text-4xl font-bold text-[hsl(var(--accent-purple))] mb-1">
                    {stats.products}
                  </div>
                  <p className="text-xs text-muted-foreground">Articles en catalogue</p>
                </>
              )}
            </CardContent>
          </Card>

          <Card className="group hover:shadow-2xl transition-all duration-500 hover:-translate-y-2 border-[hsl(var(--accent-green))]/30 bg-gradient-to-br from-card via-card to-[hsl(var(--accent-green))]/10 overflow-hidden relative">
            <div className="absolute top-0 right-0 w-32 h-32 bg-[hsl(var(--accent-green))]/20 rounded-full blur-2xl -mr-16 -mt-16 group-hover:scale-150 transition-transform duration-500" />
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 relative z-10">
              <CardTitle className="text-sm font-medium text-muted-foreground">Factures</CardTitle>
              <div className="p-2.5 rounded-xl bg-[hsl(var(--accent-green))]/20 group-hover:bg-[hsl(var(--accent-green))]/30 transition-colors duration-300 group-hover:scale-110">
                <FileText className="h-5 w-5 text-[hsl(var(--accent-green))]" />
              </div>
            </CardHeader>
            <CardContent className="relative z-10">
              {isLoading ? (
                <div className="space-y-2">
                  <Skeleton className="h-10 w-24" />
                  <Skeleton className="h-4 w-32" />
                </div>
              ) : (
                <>
                  <div className="text-3xl sm:text-4xl font-bold text-[hsl(var(--accent-green))] mb-1">
                    {stats.invoices}
                  </div>
                  <p className="text-xs text-muted-foreground">Factures émises</p>
                </>
              )}
            </CardContent>
          </Card>

          <Card className="group hover:shadow-2xl transition-all duration-500 hover:-translate-y-2 border-primary/30 bg-gradient-to-br from-card via-card to-primary/10 overflow-hidden relative">
            <div className="absolute top-0 right-0 w-32 h-32 bg-primary/20 rounded-full blur-2xl -mr-16 -mt-16 group-hover:scale-150 transition-transform duration-500" />
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 relative z-10">
              <CardTitle className="text-sm font-medium text-muted-foreground">Chiffre d'affaires</CardTitle>
              <div className="p-2.5 rounded-xl bg-primary/20 group-hover:bg-primary/30 transition-colors duration-300 group-hover:scale-110">
                <Receipt className="h-5 w-5 text-primary" />
              </div>
            </CardHeader>
            <CardContent className="relative z-10">
              {isLoading ? (
                <div className="space-y-2">
                  <Skeleton className="h-9 w-32" />
                  <Skeleton className="h-4 w-28" />
                </div>
              ) : (
                <>
                  <div className="text-2xl sm:text-3xl font-bold text-primary mb-1">
                    {stats.totalRevenue.toLocaleString()} <span className="text-base">CFA</span>
                  </div>
                  <p className="text-xs text-muted-foreground">Revenus totaux • +12.5%</p>
                </>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Charts Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {/* Revenue Chart */}
          <Card className="hover:shadow-xl transition-all duration-300 border-[hsl(var(--accent-blue))]/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-[hsl(var(--accent-blue))]" />
                Évolution du chiffre d'affaires
              </CardTitle>
              <CardDescription>Derniers 6 mois</CardDescription>
            </CardHeader>
            <CardContent>
              <ChartContainer
                config={{
                  revenue: {
                    label: "Revenus",
                    color: "hsl(var(--chart-1))",
                  },
                }}
                className="h-[200px] w-full"
              >
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={revenueData}>
                    <defs>
                      <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="hsl(var(--chart-1))" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="hsl(var(--chart-1))" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                    <XAxis dataKey="month" className="text-xs" />
                    <YAxis className="text-xs" />
                    <ChartTooltip content={<ChartTooltipContent />} />
                    <Area
                      type="monotone"
                      dataKey="revenue"
                      stroke="hsl(var(--chart-1))"
                      fillOpacity={1}
                      fill="url(#colorRevenue)"
                      strokeWidth={2}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </ChartContainer>
            </CardContent>
          </Card>

          {/* Stats Chart */}
          <Card className="hover:shadow-xl transition-all duration-300 border-[hsl(var(--accent-purple))]/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Package className="h-5 w-5 text-[hsl(var(--accent-purple))]" />
                Aperçu des données
              </CardTitle>
              <CardDescription>Vue d'ensemble</CardDescription>
            </CardHeader>
            <CardContent>
              <ChartContainer
                config={{
                  value: {
                    label: "Nombre",
                    color: "hsl(var(--chart-4))",
                  },
                }}
                className="h-[200px] w-full"
              >
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={statsData}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                    <XAxis dataKey="name" className="text-xs" />
                    <YAxis className="text-xs" />
                    <ChartTooltip content={<ChartTooltipContent />} />
                    <Bar dataKey="value" fill="hsl(var(--chart-4))" radius={[8, 8, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </ChartContainer>
            </CardContent>
          </Card>
        </div>

        {/* Actions rapides */}
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl sm:text-3xl font-bold text-foreground">Actions rapides</h2>
            <ArrowUpRight className="h-5 w-5 text-muted-foreground" />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
            <Card 
              className="group cursor-pointer hover:shadow-2xl transition-all duration-500 hover:-translate-y-3 hover:scale-105 border-[hsl(var(--accent-blue))]/40 bg-gradient-to-br from-card via-card to-[hsl(var(--accent-blue))]/10 overflow-hidden relative"
              onClick={() => navigate("/clients")}
            >
              <div className="absolute inset-0 bg-gradient-to-br from-[hsl(var(--accent-blue))]/0 via-[hsl(var(--accent-blue))]/10 to-[hsl(var(--accent-blue))]/30 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              <div className="absolute -bottom-10 -right-10 w-32 h-32 bg-[hsl(var(--accent-blue))]/30 rounded-full blur-2xl group-hover:scale-150 transition-transform duration-500" />
              <CardHeader className="relative pb-3 sm:pb-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="p-3 rounded-xl bg-[hsl(var(--accent-blue))]/20 group-hover:bg-[hsl(var(--accent-blue))]/30 transition-all duration-300 group-hover:scale-110 group-hover:rotate-6">
                    <Users className="h-6 w-6 text-[hsl(var(--accent-blue))]" />
                  </div>
                  <ArrowUpRight className="h-5 w-5 text-[hsl(var(--accent-blue))] opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                </div>
                <CardTitle className="text-lg sm:text-xl font-bold group-hover:text-[hsl(var(--accent-blue))] transition-colors">Clients</CardTitle>
                <CardDescription className="text-xs sm:text-sm leading-relaxed">
                  Gérer vos clients et prospects
                </CardDescription>
              </CardHeader>
              <CardContent className="relative pt-0">
                <Button variant="outline" className="w-full text-xs sm:text-sm border-[hsl(var(--accent-blue))]/40 hover:bg-[hsl(var(--accent-blue))]/20 hover:border-[hsl(var(--accent-blue))] transition-all group-hover:shadow-lg">
                  <Plus className="h-4 w-4 mr-2" />
                  Nouveau client
                </Button>
              </CardContent>
            </Card>

            <Card 
              className="group cursor-pointer hover:shadow-2xl transition-all duration-500 hover:-translate-y-3 hover:scale-105 border-[hsl(var(--accent-purple))]/40 bg-gradient-to-br from-card via-card to-[hsl(var(--accent-purple))]/10 overflow-hidden relative"
              onClick={() => navigate("/products")}
            >
              <div className="absolute inset-0 bg-gradient-to-br from-[hsl(var(--accent-purple))]/0 via-[hsl(var(--accent-purple))]/10 to-[hsl(var(--accent-purple))]/30 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              <div className="absolute -bottom-10 -right-10 w-32 h-32 bg-[hsl(var(--accent-purple))]/30 rounded-full blur-2xl group-hover:scale-150 transition-transform duration-500" />
              <CardHeader className="relative pb-3 sm:pb-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="p-3 rounded-xl bg-[hsl(var(--accent-purple))]/20 group-hover:bg-[hsl(var(--accent-purple))]/30 transition-all duration-300 group-hover:scale-110 group-hover:rotate-6">
                    <Package className="h-6 w-6 text-[hsl(var(--accent-purple))]" />
                  </div>
                  <ArrowUpRight className="h-5 w-5 text-[hsl(var(--accent-purple))] opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                </div>
                <CardTitle className="text-lg sm:text-xl font-bold group-hover:text-[hsl(var(--accent-purple))] transition-colors">Produits & Services</CardTitle>
                <CardDescription className="text-xs sm:text-sm leading-relaxed">
                  Catalogue de produits et services
                </CardDescription>
              </CardHeader>
              <CardContent className="relative pt-0">
                <Button variant="outline" className="w-full text-xs sm:text-sm border-[hsl(var(--accent-purple))]/40 hover:bg-[hsl(var(--accent-purple))]/20 hover:border-[hsl(var(--accent-purple))] transition-all group-hover:shadow-lg">
                  <Plus className="h-4 w-4 mr-2" />
                  Nouveau produit
                </Button>
              </CardContent>
            </Card>

            <Card 
              className="group cursor-pointer hover:shadow-2xl transition-all duration-500 hover:-translate-y-3 hover:scale-105 border-[hsl(var(--accent-green))]/40 bg-gradient-to-br from-card via-card to-[hsl(var(--accent-green))]/10 overflow-hidden relative"
              onClick={() => navigate("/invoices")}
            >
              <div className="absolute inset-0 bg-gradient-to-br from-[hsl(var(--accent-green))]/0 via-[hsl(var(--accent-green))]/10 to-[hsl(var(--accent-green))]/30 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              <div className="absolute -bottom-10 -right-10 w-32 h-32 bg-[hsl(var(--accent-green))]/30 rounded-full blur-2xl group-hover:scale-150 transition-transform duration-500" />
              <CardHeader className="relative pb-3 sm:pb-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="p-3 rounded-xl bg-[hsl(var(--accent-green))]/20 group-hover:bg-[hsl(var(--accent-green))]/30 transition-all duration-300 group-hover:scale-110 group-hover:rotate-6">
                    <FileText className="h-6 w-6 text-[hsl(var(--accent-green))]" />
                  </div>
                  <ArrowUpRight className="h-5 w-5 text-[hsl(var(--accent-green))] opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                </div>
                <CardTitle className="text-lg sm:text-xl font-bold group-hover:text-[hsl(var(--accent-green))] transition-colors">Factures</CardTitle>
                <CardDescription className="text-xs sm:text-sm leading-relaxed">
                  Créer et gérer vos factures
                </CardDescription>
              </CardHeader>
              <CardContent className="relative pt-0">
                <Button variant="outline" className="w-full text-xs sm:text-sm border-[hsl(var(--accent-green))]/40 hover:bg-[hsl(var(--accent-green))]/20 hover:border-[hsl(var(--accent-green))] transition-all group-hover:shadow-lg">
                  <Plus className="h-4 w-4 mr-2" />
                  Nouvelle facture
                </Button>
              </CardContent>
            </Card>

            <Card 
              className="group cursor-pointer hover:shadow-2xl transition-all duration-500 hover:-translate-y-3 hover:scale-105 border-[hsl(var(--accent-orange))]/40 bg-gradient-to-br from-card via-card to-[hsl(var(--accent-orange))]/10 overflow-hidden relative"
              onClick={() => navigate("/company")}
            >
              <div className="absolute inset-0 bg-gradient-to-br from-[hsl(var(--accent-orange))]/0 via-[hsl(var(--accent-orange))]/10 to-[hsl(var(--accent-orange))]/30 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              <div className="absolute -bottom-10 -right-10 w-32 h-32 bg-[hsl(var(--accent-orange))]/30 rounded-full blur-2xl group-hover:scale-150 transition-transform duration-500" />
              <CardHeader className="relative pb-3 sm:pb-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="p-3 rounded-xl bg-[hsl(var(--accent-orange))]/20 group-hover:bg-[hsl(var(--accent-orange))]/30 transition-all duration-300 group-hover:scale-110 group-hover:rotate-6">
                    <Building2 className="h-6 w-6 text-[hsl(var(--accent-orange))]" />
                  </div>
                  <ArrowUpRight className="h-5 w-5 text-[hsl(var(--accent-orange))] opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                </div>
                <CardTitle className="text-lg sm:text-xl font-bold group-hover:text-[hsl(var(--accent-orange))] transition-colors">Mon Entreprise</CardTitle>
                <CardDescription className="text-xs sm:text-sm leading-relaxed">
                  Paramètres de l'entreprise
                </CardDescription>
              </CardHeader>
              <CardContent className="relative pt-0">
                <Button variant="outline" className="w-full text-xs sm:text-sm border-[hsl(var(--accent-orange))]/40 hover:bg-[hsl(var(--accent-orange))]/20 hover:border-[hsl(var(--accent-orange))] transition-all group-hover:shadow-lg">
                  Modifier
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;