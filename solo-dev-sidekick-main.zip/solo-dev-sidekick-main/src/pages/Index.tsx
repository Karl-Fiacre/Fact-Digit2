import React, { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { FileText, Users, Package, BarChart3 } from "lucide-react";

const Index = () => {
  const navigate = useNavigate();

  useEffect(() => {
    const checkUser = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (session) {
        navigate("/dashboard");
      }
    };
    checkUser();
  }, [navigate]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/20 to-secondary/20">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <h1 className="text-xl sm:text-2xl font-bold">Fact-Digit</h1>
          <Button 
            onClick={() => navigate("/auth")}
            size="sm"
            className="text-sm sm:text-base"
          >
            Se connecter
          </Button>
        </div>
      </header>

      {/* Hero Section */}
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 lg:py-16">
        <div className="text-center max-w-3xl mx-auto mb-12 sm:mb-16">
          <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold mb-4 sm:mb-6 leading-tight">
            Solution de facturation pour la Côte d'Ivoire
          </h1>
          <p className="text-lg sm:text-xl text-muted-foreground mb-6 sm:mb-8 px-4">
            Simplifiez votre gestion des factures avec Fact-Digit. 
            Conformité DGI, factures normalisées et gestion d'entreprise tout-en-un.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center items-center">
            <Button 
              size="lg" 
              onClick={() => navigate("/auth")}
              className="w-full sm:w-auto min-w-[200px]"
            >
              Commencer gratuitement
            </Button>
            <Button 
              variant="outline" 
              size="lg"
              className="w-full sm:w-auto min-w-[200px]"
            >
              En savoir plus
            </Button>
          </div>
        </div>

        {/* Features */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
          <div className="text-center p-4 sm:p-6">
            <div className="bg-primary/10 rounded-lg p-3 sm:p-4 w-14 h-14 sm:w-16 sm:h-16 mx-auto mb-3 sm:mb-4 flex items-center justify-center">
              <FileText className="h-6 w-6 sm:h-8 sm:w-8 text-primary" />
            </div>
            <h3 className="text-base sm:text-lg font-semibold mb-2">Facturation simple</h3>
            <p className="text-sm sm:text-base text-muted-foreground">
              Créez vos factures en quelques clics avec nos modèles professionnels
            </p>
          </div>

          <div className="text-center p-4 sm:p-6">
            <div className="bg-primary/10 rounded-lg p-3 sm:p-4 w-14 h-14 sm:w-16 sm:h-16 mx-auto mb-3 sm:mb-4 flex items-center justify-center">
              <Users className="h-6 w-6 sm:h-8 sm:w-8 text-primary" />
            </div>
            <h3 className="text-base sm:text-lg font-semibold mb-2">Gestion clients</h3>
            <p className="text-sm sm:text-base text-muted-foreground">
              Gérez votre base clients et suivez l'historique de vos transactions
            </p>
          </div>

          <div className="text-center p-4 sm:p-6">
            <div className="bg-primary/10 rounded-lg p-3 sm:p-4 w-14 h-14 sm:w-16 sm:h-16 mx-auto mb-3 sm:mb-4 flex items-center justify-center">
              <Package className="h-6 w-6 sm:h-8 sm:w-8 text-primary" />
            </div>
            <h3 className="text-base sm:text-lg font-semibold mb-2">Catalogue produits</h3>
            <p className="text-sm sm:text-base text-muted-foreground">
              Organisez vos produits et services avec gestion des prix et TVA
            </p>
          </div>

          <div className="text-center p-4 sm:p-6">
            <div className="bg-primary/10 rounded-lg p-3 sm:p-4 w-14 h-14 sm:w-16 sm:h-16 mx-auto mb-3 sm:mb-4 flex items-center justify-center">
              <BarChart3 className="h-6 w-6 sm:h-8 sm:w-8 text-primary" />
            </div>
            <h3 className="text-base sm:text-lg font-semibold mb-2">Tableau de bord</h3>
            <p className="text-sm sm:text-base text-muted-foreground">
              Suivez vos performances avec des rapports détaillés
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Index;
