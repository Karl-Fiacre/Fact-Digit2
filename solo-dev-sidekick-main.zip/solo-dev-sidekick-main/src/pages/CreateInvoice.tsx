import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { ArrowLeft, Plus, Trash2, Save } from "lucide-react";

const invoiceItemSchema = z.object({
  description: z.string().min(1, "Description requise"),
  quantity: z.number().min(0.01, "Quantité doit être supérieure à 0"),
  unit_price: z.number().min(0, "Prix unitaire doit être positif"),
  tva_rate: z.number().min(0).max(100, "Taux TVA invalide"),
});

const invoiceSchema = z.object({
  client_id: z.string().min(1, "Client requis"),
  date_issued: z.string().min(1, "Date d'émission requise"),
  date_due: z.string().optional(),
  notes: z.string().optional(),
  terms: z.string().optional(),
  discount_type: z.enum(['none', 'percentage', 'fixed']).default('none'),
  discount_value: z.number().min(0).default(0),
  items: z.array(invoiceItemSchema).min(1, "Au moins un article requis"),
});

type InvoiceFormData = z.infer<typeof invoiceSchema>;

interface Client {
  id: string;
  name: string;
  email?: string;
  type: string;
}

interface Product {
  id: string;
  name: string;
  price: number;
  tva_rate: number;
  unit: string;
  description?: string;
}

const CreateInvoice = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [clients, setClients] = useState<Client[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(false);
  const [companyInfo, setCompanyInfo] = useState<any>(null);

  const form = useForm<InvoiceFormData>({
    resolver: zodResolver(invoiceSchema),
    defaultValues: {
      date_issued: new Date().toISOString().split('T')[0],
      discount_type: 'none',
      discount_value: 0,
      items: [{ description: "", quantity: 1, unit_price: 0, tva_rate: 18 }],
    },
  });

  const { fields, append, remove } = useFieldArray({
    control: form.control,
    name: "items",
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      // Charger les clients
      const { data: clientsData } = await supabase
        .from('clients')
        .select('*')
        .order('name');

      // Charger les produits
      const { data: productsData } = await supabase
        .from('products')
        .select('*')
        .order('name');

      // Charger les infos de l'entreprise
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Non authentifié");
      
      const { data: profileData } = await supabase
        .from('profiles')
        .select('*, companies(*)')
        .eq('user_id', user.id)
        .maybeSingle();

      setClients(clientsData || []);
      setProducts(productsData || []);
      setCompanyInfo(profileData);
    } catch (error: any) {
      toast({
        title: "Erreur",
        description: "Impossible de charger les données",
        variant: "destructive"
      });
    }
  };

  const generateInvoiceNumber = () => {
    const date = new Date();
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const random = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
    return `FACT-${year}${month}-${random}`;
  };

  const calculateSubtotal = (items: any[]) => {
    return items.reduce((sum, item) => sum + (item.quantity * item.unit_price), 0);
  };

  const calculateTVA = (items: any[]) => {
    return items.reduce((sum, item) => {
      const itemTotal = item.quantity * item.unit_price;
      return sum + (itemTotal * item.tva_rate / 100);
    }, 0);
  };

  const onSubmit = async (data: InvoiceFormData) => {
    if (!companyInfo?.company_id) {
      toast({
        title: "Erreur",
        description: "Veuillez d'abord configurer votre entreprise",
        variant: "destructive"
      });
      return;
    }

    setLoading(true);
    try {
      const subtotal = calculateSubtotal(data.items);
      
      // Calculer la réduction
      let discountAmount = 0;
      if (data.discount_type === 'percentage') {
        discountAmount = (subtotal * data.discount_value) / 100;
      } else if (data.discount_type === 'fixed') {
        discountAmount = data.discount_value;
      }
      
      const subtotalAfterDiscount = subtotal - discountAmount;
      const tvaAmount = calculateTVA(data.items);
      const totalAmount = subtotalAfterDiscount + tvaAmount;

      // 🚀 NOUVEAU: Identifier et créer automatiquement les nouveaux produits/services
      const newProductsToCreate = [];
      for (const item of data.items) {
        // Vérifier si la description correspond à un produit existant
        const existingProduct = products.find(p => 
          item.description.toLowerCase().includes(p.name.toLowerCase())
        );
        
        // Si ce n'est pas un produit existant, le préparer pour création
        if (!existingProduct) {
          // Extraire le nom du produit (première partie avant " - " si présent)
          const productName = item.description.split(' - ')[0].trim();
          
          // Vérifier qu'il n'est pas déjà dans la liste à créer
          const alreadyInList = newProductsToCreate.find(p => p.name === productName);
          
          if (!alreadyInList && productName.length > 0) {
            newProductsToCreate.push({
              name: productName,
              description: item.description,
              price: item.unit_price,
              tva_rate: item.tva_rate,
              unit: 'unité',
              is_service: false,
              company_id: companyInfo.company_id
            });
          }
        }
      }

      // Créer les nouveaux produits en parallèle si nécessaire
      if (newProductsToCreate.length > 0) {
        const { error: productsError } = await supabase
          .from('products')
          .insert(newProductsToCreate);
        
        if (productsError) {
          console.error('Erreur lors de la création des produits:', productsError);
          // Ne pas bloquer la création de facture, juste logger
        } else {
          toast({
            title: "🎉 Produits ajoutés",
            description: `${newProductsToCreate.length} nouveau(x) produit(s) ajouté(s) automatiquement au catalogue`,
          });
        }
      }

      // Créer la facture
      const { data: invoice, error: invoiceError } = await supabase
        .from('invoices')
        .insert({
          company_id: companyInfo.company_id,
          client_id: data.client_id,
          invoice_number: generateInvoiceNumber(),
          date_issued: data.date_issued,
          date_due: data.date_due || null,
          notes: data.notes || null,
          terms: data.terms || null,
          subtotal: subtotalAfterDiscount,
          tva_amount: tvaAmount,
          total_amount: totalAmount,
          status: 'draft',
          fne_status: 'draft'
        })
        .select()
        .single();

      if (invoiceError) throw invoiceError;

      // Créer les articles de facture
      const invoiceItems = data.items.map(item => ({
        invoice_id: invoice.id,
        description: item.description,
        quantity: item.quantity,
        unit_price: item.unit_price,
        tva_rate: item.tva_rate
      }));

      const { error: itemsError } = await supabase
        .from('invoice_items')
        .insert(invoiceItems);

      if (itemsError) throw itemsError;

      toast({
        title: "✅ Succès",
        description: "Facture créée avec succès"
      });

      navigate('/invoices');
    } catch (error: any) {
      toast({
        title: "Erreur",
        description: error.message || "Erreur lors de la création de la facture",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const addProductToInvoice = (productId: string) => {
    const product = products.find(p => p.id === productId);
    if (product) {
      append({
        description: product.name + (product.description ? ` - ${product.description}` : ''),
        quantity: 1,
        unit_price: product.price,
        tva_rate: product.tva_rate
      });
    }
  };

  const currentItems = form.watch("items");
  const discountType = form.watch("discount_type");
  const discountValue = form.watch("discount_value");
  
  const subtotal = calculateSubtotal(currentItems);
  const tvaAmount = calculateTVA(currentItems);
  
  // Calculer la réduction
  let discountAmount = 0;
  if (discountType === 'percentage') {
    discountAmount = (subtotal * discountValue) / 100;
  } else if (discountType === 'fixed') {
    discountAmount = discountValue;
  }
  
  const subtotalAfterDiscount = subtotal - discountAmount;
  const total = subtotalAfterDiscount + tvaAmount;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="sm" onClick={() => navigate("/invoices")}>
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <h1 className="text-2xl font-bold">Nouvelle Facture</h1>
          </div>
          <Button 
            onClick={form.handleSubmit(onSubmit)} 
            disabled={loading}
            className="bg-primary hover:bg-primary/90"
          >
            <Save className="h-4 w-4 mr-2" />
            {loading ? "Création..." : "Créer la facture"}
          </Button>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Informations générales */}
              <Card>
                <CardHeader>
                  <CardTitle>Informations de la facture</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <FormField
                    control={form.control}
                    name="client_id"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Client *</FormLabel>
                        <Select onValueChange={field.onChange} value={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Sélectionner un client" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {clients.map((client) => (
                              <SelectItem key={client.id} value={client.id}>
                                {client.name} ({client.type})
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="date_issued"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Date d'émission *</FormLabel>
                          <FormControl>
                            <Input type="date" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="date_due"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Date d'échéance</FormLabel>
                          <FormControl>
                            <Input type="date" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="notes"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Notes</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="Notes additionnelles pour la facture..." 
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="terms"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Conditions de paiement</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="Conditions de paiement..." 
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </CardContent>
              </Card>

              {/* Résumé financier */}
              <Card>
                <CardHeader>
                  <CardTitle>Résumé financier</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3 mb-4 pb-4 border-b">
                    <FormField
                      control={form.control}
                      name="discount_type"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Type de réduction</FormLabel>
                          <Select onValueChange={field.onChange} value={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="none">Aucune réduction</SelectItem>
                              <SelectItem value="percentage">Pourcentage (%)</SelectItem>
                              <SelectItem value="fixed">Montant fixe (FCFA)</SelectItem>
                            </SelectContent>
                          </Select>
                        </FormItem>
                      )}
                    />

                    {discountType !== 'none' && (
                      <FormField
                        control={form.control}
                        name="discount_value"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>
                              {discountType === 'percentage' ? 'Pourcentage de réduction (%)' : 'Montant de réduction (FCFA)'}
                            </FormLabel>
                            <FormControl>
                              <Input 
                                type="number" 
                                step="0.01"
                                min="0"
                                max={discountType === 'percentage' ? 100 : undefined}
                                {...field}
                                onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                              />
                            </FormControl>
                          </FormItem>
                        )}
                      />
                    )}
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>Sous-total (HT)</span>
                      <span className="font-medium">{subtotal.toLocaleString('fr-FR')} FCFA</span>
                    </div>
                    
                    {discountAmount > 0 && (
                      <div className="flex justify-between text-orange-600">
                        <span>Réduction {discountType === 'percentage' ? `(${discountValue}%)` : ''}</span>
                        <span className="font-medium">-{discountAmount.toLocaleString('fr-FR')} FCFA</span>
                      </div>
                    )}

                    <div className="flex justify-between">
                      <span>TVA</span>
                      <span className="font-medium">{tvaAmount.toLocaleString('fr-FR')} FCFA</span>
                    </div>
                    <div className="border-t pt-2">
                      <div className="flex justify-between text-lg font-bold">
                        <span>Total (TTC)</span>
                        <span>{total.toLocaleString('fr-FR')} FCFA</span>
                      </div>
                    </div>
                  </div>

                  {products.length > 0 && (
                    <div className="pt-4 border-t">
                      <FormLabel>Ajouter un produit existant</FormLabel>
                      <Select onValueChange={addProductToInvoice}>
                        <SelectTrigger className="mt-2">
                          <SelectValue placeholder="Sélectionner un produit" />
                        </SelectTrigger>
                        <SelectContent>
                          {products.map((product) => (
                            <SelectItem key={product.id} value={product.id}>
                              {product.name} - {product.price.toLocaleString('fr-FR')} FCFA/{product.unit}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Articles de la facture */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Articles de la facture</CardTitle>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => append({ description: "", quantity: 1, unit_price: 0, tva_rate: 18 })}
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Ajouter un article
                </Button>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {fields.map((field, index) => (
                    <div key={field.id} className="grid grid-cols-1 md:grid-cols-6 gap-4 p-4 border rounded-lg">
                      <div className="md:col-span-2">
                        <FormField
                          control={form.control}
                          name={`items.${index}.description`}
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Description *</FormLabel>
                              <FormControl>
                                <Input placeholder="Description de l'article" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <FormField
                        control={form.control}
                        name={`items.${index}.quantity`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Quantité *</FormLabel>
                            <FormControl>
                              <Input 
                                type="number" 
                                step="0.01"
                                min="0.01"
                                {...field}
                                onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name={`items.${index}.unit_price`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Prix unitaire (FCFA) *</FormLabel>
                            <FormControl>
                              <Input 
                                type="number" 
                                step="0.01"
                                min="0"
                                {...field}
                                onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name={`items.${index}.tva_rate`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>TVA (%)</FormLabel>
                            <FormControl>
                              <Input 
                                type="number" 
                                step="0.01"
                                min="0"
                                max="100"
                                {...field}
                                onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <div className="flex items-end">
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => remove(index)}
                          disabled={fields.length === 1}
                          className="w-full"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </form>
        </Form>
      </div>
    </div>
  );
};

export default CreateInvoice;