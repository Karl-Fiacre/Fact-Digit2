import React, { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { ArrowLeft, Building2, Upload, X } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";

const Company = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [logoPreview, setLogoPreview] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [companyId, setCompanyId] = useState<string | null>(null);
  const [company, setCompany] = useState({
    name: "",
    address: "",
    rccm: "",
    numero_cc: "",
    phone: "",
    email: "",
    website: "",
  });

  useEffect(() => {
    loadCompanyData();
  }, []);

  const loadCompanyData = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data: profile } = await supabase
        .from('profiles')
        .select('company_id, company:companies(*)')
        .eq('user_id', user.id)
        .single();

      if (profile?.company_id && profile.company) {
        setCompanyId(profile.company_id);
        setCompany({
          name: profile.company.name || "",
          address: profile.company.address || "",
          rccm: profile.company.rccm || "",
          numero_cc: profile.company.numero_cc || "",
          phone: profile.company.phone || "",
          email: profile.company.email || "",
          website: profile.company.website || "",
        });
        if (profile.company.logo_url) {
          setLogoPreview(profile.company.logo_url);
        }
      }
    } catch (error) {
      console.error('Error loading company data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) { // 5MB limit
        toast({
          title: "Fichier trop volumineux",
          description: "Le logo ne doit pas dépasser 5MB.",
          variant: "destructive",
        });
        return;
      }

      const reader = new FileReader();
      reader.onload = (event) => {
        setLogoPreview(event.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const removeLogo = () => {
    setLogoPreview(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        toast({
          title: "Erreur d'authentification",
          description: "Vous devez être connecté pour sauvegarder.",
          variant: "destructive",
        });
        return;
      }

      if (companyId) {
        // Mise à jour de l'entreprise existante
        const { error } = await supabase
          .from('companies')
          .update({
            name: company.name,
            address: company.address,
            rccm: company.rccm,
            numero_cc: company.numero_cc,
            phone: company.phone,
            email: company.email,
            website: company.website,
            logo_url: logoPreview,
            updated_at: new Date().toISOString()
          })
          .eq('id', companyId);

        if (error) throw error;

        toast({
          title: "Entreprise mise à jour",
          description: "Les informations de votre entreprise ont été sauvegardées avec succès.",
        });
      } else {
        // Création d'une nouvelle entreprise
        const { data: newCompany, error: companyError } = await supabase
          .from('companies')
          .insert([{
            name: company.name,
            address: company.address,
            rccm: company.rccm,
            numero_cc: company.numero_cc,
            phone: company.phone,
            email: company.email,
            website: company.website,
            logo_url: logoPreview
          }])
          .select()
          .single();

        if (companyError) throw companyError;

        // Mise à jour du profil avec le company_id
        const { error: profileError } = await supabase
          .from('profiles')
          .update({ company_id: newCompany.id })
          .eq('user_id', user.id);

        if (profileError) throw profileError;
        
        setCompanyId(newCompany.id);

        toast({
          title: "Entreprise créée",
          description: "Votre entreprise a été créée avec succès.",
        });
      }

      navigate("/dashboard");
    } catch (error: any) {
      console.error('Error saving company:', error);
      toast({
        title: "Erreur",
        description: error.message || "Une erreur est survenue lors de la sauvegarde.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="sm" onClick={() => navigate("/dashboard")}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Retour
            </Button>
            <h1 className="text-2xl font-bold">Mon Entreprise</h1>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <Card className="max-w-3xl mx-auto">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Building2 className="h-5 w-5" />
              Informations de l'entreprise
            </CardTitle>
            <CardDescription>
              Configurez les informations de votre entreprise pour la facturation
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Upload du logo */}
              <div className="space-y-4">
                <Label>Logo de l'entreprise</Label>
                <div className="flex items-center gap-4">
                  {logoPreview ? (
                    <div className="relative">
                      <img
                        src={logoPreview}
                        alt="Logo preview"
                        className="w-24 h-24 object-contain border rounded-lg"
                      />
                      <Button
                        type="button"
                        variant="destructive"
                        size="sm"
                        className="absolute -top-2 -right-2 h-6 w-6 rounded-full p-0"
                        onClick={removeLogo}
                      >
                        <X className="h-3 w-3" />
                      </Button>
                    </div>
                  ) : (
                    <div className="w-24 h-24 border-2 border-dashed border-muted-foreground/25 rounded-lg flex items-center justify-center">
                      <Upload className="h-8 w-8 text-muted-foreground" />
                    </div>
                  )}
                  <div className="space-y-2">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => fileInputRef.current?.click()}
                    >
                      <Upload className="h-4 w-4 mr-2" />
                      Choisir un logo
                    </Button>
                    <p className="text-sm text-muted-foreground">
                      Formats acceptés: PNG, JPG, SVG (max 5MB)
                    </p>
                  </div>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleLogoUpload}
                    className="hidden"
                  />
                </div>
              </div>

              {/* Informations de base */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="md:col-span-2">
                  <Label htmlFor="name">Nom de l'entreprise *</Label>
                  <Input
                    id="name"
                    value={company.name}
                    onChange={(e) => setCompany({...company, name: e.target.value})}
                    required
                    placeholder="Raison sociale de votre entreprise"
                  />
                </div>
                <div>
                  <Label htmlFor="rccm">RCCM</Label>
                  <Input
                    id="rccm"
                    value={company.rccm}
                    onChange={(e) => setCompany({...company, rccm: e.target.value})}
                    placeholder="Numéro RCCM"
                  />
                </div>
                <div>
                  <Label htmlFor="numero_cc">Numéro CC</Label>
                  <Input
                    id="numero_cc"
                    value={company.numero_cc}
                    onChange={(e) => setCompany({...company, numero_cc: e.target.value})}
                    placeholder="Numéro compte contribuable"
                  />
                </div>
              </div>

              {/* Adresse */}
              <div>
                <Label htmlFor="address">Adresse complète</Label>
                <Textarea
                  id="address"
                  value={company.address}
                  onChange={(e) => setCompany({...company, address: e.target.value})}
                  rows={3}
                  placeholder="Adresse physique de l'entreprise"
                />
              </div>

              {/* Contacts */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="phone">Téléphone</Label>
                  <Input
                    id="phone"
                    value={company.phone}
                    onChange={(e) => setCompany({...company, phone: e.target.value})}
                    placeholder="+225 XX XX XX XX XX"
                  />
                </div>
                <div>
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={company.email}
                    onChange={(e) => setCompany({...company, email: e.target.value})}
                    placeholder="contact@entreprise.ci"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="website">Site web</Label>
                <Input
                  id="website"
                  type="url"
                  value={company.website}
                  onChange={(e) => setCompany({...company, website: e.target.value})}
                  placeholder="https://www.entreprise.ci"
                />
              </div>

              <div className="flex gap-4 pt-6">
                <Button type="submit" className="flex-1">
                  Sauvegarder les modifications
                </Button>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => navigate("/dashboard")}
                >
                  Annuler
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Company;