/**
 * Détection de la plateforme d'exécution
 */

export type Platform = 'web' | 'electron' | 'capacitor' | 'tauri';

export const detectPlatform = (): Platform => {
  // Détecter Electron
  if (window.electronAPI?.isElectron) {
    return 'electron';
  }

  // Détecter Capacitor
  if (window.Capacitor?.isNativePlatform()) {
    return 'capacitor';
  }

  // Détecter Tauri
  if (window.__TAURI__) {
    return 'tauri';
  }

  // Par défaut, c'est une app web
  return 'web';
};

export const isNative = (): boolean => {
  const platform = detectPlatform();
  return platform === 'electron' || platform === 'capacitor' || platform === 'tauri';
};

export const isMobile = (): boolean => {
  return detectPlatform() === 'capacitor';
};

export const isDesktop = (): boolean => {
  const platform = detectPlatform();
  return platform === 'electron' || platform === 'tauri';
};

export const getPlatformInfo = () => {
  const platform = detectPlatform();
  
  return {
    platform,
    isNative: isNative(),
    isMobile: isMobile(),
    isDesktop: isDesktop(),
    isWeb: platform === 'web',
    supportsOffline: platform !== 'web',
    supportsNotifications: true,
    supportsPushNotifications: platform === 'capacitor',
  };
};

// Déclarations TypeScript pour les APIs globales
declare global {
  interface Window {
    electronAPI?: {
      isElectron: boolean;
      getAppVersion: () => Promise<string>;
      showSaveDialog: (options: any) => Promise<any>;
      showOpenDialog: (options: any) => Promise<any>;
      showMessageBox: (options: any) => Promise<any>;
      onMenuAction: (callback: (action: string) => void) => () => void;
      platform: string;
      storage: {
        get: (key: string) => any;
        set: (key: string, value: any) => boolean;
        remove: (key: string) => boolean;
        clear: () => boolean;
      };
    };
    Capacitor?: {
      isNativePlatform: () => boolean;
      getPlatform: () => string;
    };
    __TAURI__?: any;
  }
}
