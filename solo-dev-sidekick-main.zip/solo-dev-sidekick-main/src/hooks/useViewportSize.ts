import { useState, useEffect } from 'react';

interface ViewportSize {
  width: number;
  height: number;
}

export const useViewportSize = () => {
  const [viewportSize, setViewportSize] = useState<ViewportSize>({
    width: typeof window !== 'undefined' ? window.innerWidth : 0,
    height: typeof window !== 'undefined' ? window.innerHeight : 0,
  });

  useEffect(() => {
    const handleResize = () => {
      setViewportSize({
        width: window.innerWidth,
        height: window.innerHeight,
      });
    };

    window.addEventListener('resize', handleResize);
    
    // Initial call to set the size
    handleResize();

    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const isExtraSmall = viewportSize.width < 480;
  const isSmall = viewportSize.width >= 480 && viewportSize.width < 768;
  const isMedium = viewportSize.width >= 768 && viewportSize.width < 1024;
  const isLarge = viewportSize.width >= 1024;

  return {
    ...viewportSize,
    isExtraSmall,
    isSmall,
    isMedium,
    isLarge,
    isMobile: viewportSize.width < 768,
    isTablet: viewportSize.width >= 768 && viewportSize.width < 1024,
    isDesktop: viewportSize.width >= 1024,
  };
};