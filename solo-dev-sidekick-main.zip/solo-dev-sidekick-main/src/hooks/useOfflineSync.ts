import { useState, useEffect } from 'react';
import { Network } from '@capacitor/network';
import { supabase } from '@/integrations/supabase/client';

interface OfflineData {
  invoices: any[];
  clients: any[];
  products: any[];
  pendingActions: any[];
}

export const useOfflineSync = () => {
  const [isOnline, setIsOnline] = useState(true);
  const [isSyncing, setIsSyncing] = useState(false);
  const [offlineData, setOfflineData] = useState<OfflineData>({
    invoices: [],
    clients: [],
    products: [],
    pendingActions: []
  });

  useEffect(() => {
    let networkListener: any = null;

    // Vérifier le statut réseau initial
    const checkNetworkStatus = async () => {
      const status = await Network.getStatus();
      setIsOnline(status.connected);
    };

    // Écouter les changements de réseau
    const setupNetworkListener = async () => {
      networkListener = await Network.addListener('networkStatusChange', status => {
        setIsOnline(status.connected);
        if (status.connected) {
          syncOfflineData();
        }
      });
    };

    checkNetworkStatus();
    setupNetworkListener();
    loadOfflineData();

    return () => {
      if (networkListener) {
        networkListener.remove();
      }
    };
  }, []);

  const loadOfflineData = () => {
    try {
      const stored = localStorage.getItem('fact-digit-offline');
      if (stored) {
        setOfflineData(JSON.parse(stored));
      }
    } catch (error) {
      console.error('Erreur lors du chargement des données offline:', error);
    }
  };

  const saveOfflineData = (data: OfflineData) => {
    try {
      localStorage.setItem('fact-digit-offline', JSON.stringify(data));
      setOfflineData(data);
    } catch (error) {
      console.error('Erreur lors de la sauvegarde offline:', error);
    }
  };

  const addPendingAction = (action: any) => {
    const newData = {
      ...offlineData,
      pendingActions: [...offlineData.pendingActions, { ...action, timestamp: Date.now() }]
    };
    saveOfflineData(newData);
  };

  const syncOfflineData = async () => {
    if (!isOnline || isSyncing) return;

    setIsSyncing(true);
    try {
      // Synchroniser les actions en attente
      for (const action of offlineData.pendingActions) {
        await executeAction(action);
      }

      // Vider les actions en attente
      const newData = { ...offlineData, pendingActions: [] };
      saveOfflineData(newData);

      // Récupérer les dernières données du serveur
      await refreshAllData();
    } catch (error) {
      console.error('Erreur lors de la synchronisation:', error);
    } finally {
      setIsSyncing(false);
    }
  };

  const executeAction = async (action: any) => {
    switch (action.type) {
      case 'CREATE_INVOICE':
        await supabase.from('invoices').insert(action.data);
        break;
      case 'UPDATE_INVOICE':
        await supabase.from('invoices').update(action.data).eq('id', action.id);
        break;
      case 'CREATE_CLIENT':
        await supabase.from('clients').insert(action.data);
        break;
      case 'UPDATE_CLIENT':
        await supabase.from('clients').update(action.data).eq('id', action.id);
        break;
      case 'CREATE_PRODUCT':
        await supabase.from('products').insert(action.data);
        break;
      case 'UPDATE_PRODUCT':
        await supabase.from('products').update(action.data).eq('id', action.id);
        break;
    }
  };

  const refreshAllData = async () => {
    try {
      const [invoicesRes, clientsRes, productsRes] = await Promise.all([
        supabase.from('invoices').select('*'),
        supabase.from('clients').select('*'),
        supabase.from('products').select('*')
      ]);

      const newData = {
        ...offlineData,
        invoices: invoicesRes.data || [],
        clients: clientsRes.data || [],
        products: productsRes.data || []
      };
      saveOfflineData(newData);
    } catch (error) {
      console.error('Erreur lors du rafraîchissement des données:', error);
    }
  };

  return {
    isOnline,
    isSyncing,
    offlineData,
    addPendingAction,
    syncOfflineData,
    refreshAllData
  };
};