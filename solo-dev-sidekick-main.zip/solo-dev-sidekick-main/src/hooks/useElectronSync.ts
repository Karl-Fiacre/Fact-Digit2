import { useState, useEffect } from 'react';

declare global {
  interface Window {
    electronAPI?: {
      isElectron: boolean;
      platform: string;
      getAppVersion: () => Promise<string>;
      showSaveDialog: (options: any) => Promise<any>;
      showOpenDialog: (options: any) => Promise<any>;
      showMessageBox: (options: any) => Promise<any>;
      onMenuAction: (callback: (action: string) => void) => () => void;
      storage: {
        get: (key: string) => any;
        set: (key: string, value: any) => boolean;
        remove: (key: string) => boolean;
        clear: () => boolean;
      };
    };
  }
}

interface ElectronData {
  invoices: any[];
  clients: any[];
  products: any[];
  pendingActions: any[];
  lastSync: number;
}

export const useElectronSync = () => {
  const [isElectron, setIsElectron] = useState(false);
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [isSyncing, setIsSyncing] = useState(false);
  const [electronData, setElectronData] = useState<ElectronData>({
    invoices: [],
    clients: [],
    products: [],
    pendingActions: [],
    lastSync: 0
  });

  useEffect(() => {
    // Vérifier si on est dans Electron
    setIsElectron(!!window.electronAPI?.isElectron);
    
    // Écouter les changements de connectivité
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    
    // Écouter les actions du menu Electron
    let removeMenuListener: (() => void) | undefined;
    if (window.electronAPI) {
      removeMenuListener = window.electronAPI.onMenuAction((action) => {
        handleMenuAction(action);
      });
    }

    // Charger les données locales
    loadElectronData();

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      if (removeMenuListener) {
        removeMenuListener();
      }
    };
  }, []);

  const loadElectronData = () => {
    if (!window.electronAPI) return;
    
    try {
      const stored = window.electronAPI.storage.get('fact-digit-electron');
      if (stored) {
        setElectronData(stored);
      }
    } catch (error) {
      console.error('Erreur lors du chargement des données Electron:', error);
    }
  };

  const saveElectronData = (data: ElectronData) => {
    if (!window.electronAPI) return false;
    
    try {
      const success = window.electronAPI.storage.set('fact-digit-electron', data);
      if (success) {
        setElectronData(data);
      }
      return success;
    } catch (error) {
      console.error('Erreur lors de la sauvegarde Electron:', error);
      return false;
    }
  };

  const addPendingAction = (action: any) => {
    const newData = {
      ...electronData,
      pendingActions: [...electronData.pendingActions, { 
        ...action, 
        timestamp: Date.now(),
        id: crypto.randomUUID()
      }]
    };
    saveElectronData(newData);
  };

  const syncWithServer = async () => {
    if (!isOnline || isSyncing || !window.electronAPI) return;

    setIsSyncing(true);
    try {
      // TODO: Implémenter la synchronisation avec Supabase
      // Cette fonction sera étendue pour synchroniser avec le serveur
      
      // Simuler la synchronisation
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Marquer la dernière synchronisation
      const newData = {
        ...electronData,
        lastSync: Date.now(),
        pendingActions: [] // Vider les actions après synchronisation
      };
      saveElectronData(newData);
      
      return true;
    } catch (error) {
      console.error('Erreur lors de la synchronisation:', error);
      return false;
    } finally {
      setIsSyncing(false);
    }
  };

  const handleMenuAction = (action: string) => {
    switch (action) {
      case 'new-invoice':
        // TODO: Naviguer vers la création de facture
        window.location.hash = '#/invoices/new';
        break;
      case 'sync-data':
        syncWithServer();
        break;
      default:
        console.log('Action de menu non gérée:', action);
    }
  };

  const showSaveDialog = async (options: any) => {
    if (!window.electronAPI) return null;
    return await window.electronAPI.showSaveDialog(options);
  };

  const showOpenDialog = async (options: any) => {
    if (!window.electronAPI) return null;
    return await window.electronAPI.showOpenDialog(options);
  };

  const exportToPDF = async (invoiceData: any) => {
    if (!window.electronAPI) return false;
    
    try {
      const result = await showSaveDialog({
        title: 'Exporter la facture',
        defaultPath: `Facture-${invoiceData.invoice_number}.pdf`,
        filters: [
          { name: 'PDF Files', extensions: ['pdf'] }
        ]
      });
      
      if (!result.canceled && result.filePath) {
        // TODO: Implémenter l'export PDF
        console.log('Export PDF vers:', result.filePath);
        return true;
      }
      return false;
    } catch (error) {
      console.error('Erreur lors de l\'export PDF:', error);
      return false;
    }
  };

  return {
    isElectron,
    isOnline,
    isSyncing,
    electronData,
    addPendingAction,
    syncWithServer,
    showSaveDialog,
    showOpenDialog,
    exportToPDF,
    lastSync: electronData.lastSync
  };
};