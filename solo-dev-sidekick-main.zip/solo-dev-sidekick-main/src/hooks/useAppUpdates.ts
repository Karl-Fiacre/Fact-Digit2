import { useEffect, useState } from 'react';
import { useToast } from '@/hooks/use-toast';

export const useAppUpdates = () => {
  const [updateAvailable, setUpdateAvailable] = useState(false);
  const [currentVersion, setCurrentVersion] = useState<string>('1.0.0');
  const { toast } = useToast();

  useEffect(() => {
    // Check for Electron
    if (window.electronAPI?.isElectron) {
      checkElectronVersion();
    } else {
      checkWebVersion();
    }
  }, []);

  const checkElectronVersion = async () => {
    try {
      if (window.electronAPI?.getAppVersion) {
        const version = await window.electronAPI.getAppVersion();
        setCurrentVersion(version);
        console.log('Electron version:', version);
      }
    } catch (error) {
      console.error('Error checking Electron version:', error);
    }
  };

  const checkWebVersion = () => {
    // For web version, check service worker updates
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.addEventListener('controllerchange', () => {
        setUpdateAvailable(true);
        toast({
          title: "Mise à jour disponible",
          description: "Une nouvelle version est disponible. Rechargez la page pour mettre à jour.",
          duration: 10000,
        });
      });

      // Check for updates periodically
      setInterval(() => {
        navigator.serviceWorker.getRegistrations().then(registrations => {
          registrations.forEach(registration => {
            registration.update();
          });
        });
      }, 1000 * 60 * 60); // Check every hour
    }
  };

  const applyUpdate = () => {
    if (window.electronAPI?.isElectron) {
      // For Electron, you would implement auto-updater
      toast({
        title: "Mise à jour",
        description: "Vérification des mises à jour...",
      });
    } else {
      // For web, reload the page
      window.location.reload();
    }
  };

  return {
    updateAvailable,
    currentVersion,
    applyUpdate,
  };
};
