import { useEffect, useState } from 'react';
import { PushNotifications } from '@capacitor/push-notifications';
import { LocalNotifications } from '@capacitor/local-notifications';
import { Capacitor } from '@capacitor/core';
import { useToast } from '@/hooks/use-toast';

export const usePushNotifications = () => {
  const [isRegistered, setIsRegistered] = useState(false);
  const [token, setToken] = useState<string | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    // Only initialize on native platforms
    if (!Capacitor.isNativePlatform()) {
      return;
    }

    const initializePushNotifications = async () => {
      try {
        // Request permission
        let permStatus = await PushNotifications.checkPermissions();

        if (permStatus.receive === 'prompt') {
          permStatus = await PushNotifications.requestPermissions();
        }

        if (permStatus.receive !== 'granted') {
          console.log('Push notification permission denied');
          return;
        }

        // Register with Apple / Google to receive push
        await PushNotifications.register();

        // Initialize local notifications
        await LocalNotifications.requestPermissions();

        setIsRegistered(true);
      } catch (error) {
        console.error('Error initializing push notifications:', error);
      }
    };

    // Event listeners
    PushNotifications.addListener('registration', (token) => {
      console.log('Push registration success, token:', token.value);
      setToken(token.value);
    });

    PushNotifications.addListener('registrationError', (error) => {
      console.error('Push registration error:', error);
    });

    PushNotifications.addListener('pushNotificationReceived', (notification) => {
      console.log('Push notification received:', notification);
      
      // Show local notification when app is in foreground
      LocalNotifications.schedule({
        notifications: [
          {
            title: notification.title || 'Fact-Digit',
            body: notification.body || '',
            id: Date.now(),
            schedule: { at: new Date(Date.now() + 1000) },
            sound: 'default',
            smallIcon: 'ic_stat_icon_config_sample',
            iconColor: '#488AFF',
          },
        ],
      });
    });

    PushNotifications.addListener('pushNotificationActionPerformed', (notification) => {
      console.log('Push notification action performed:', notification);
      
      // Handle notification tap
      toast({
        title: notification.notification.title || 'Notification',
        description: notification.notification.body,
      });
    });

    initializePushNotifications();

    return () => {
      PushNotifications.removeAllListeners();
    };
  }, [toast]);

  const scheduleLocalNotification = async (title: string, body: string, delay: number = 1000) => {
    try {
      await LocalNotifications.schedule({
        notifications: [
          {
            title,
            body,
            id: Date.now(),
            schedule: { at: new Date(Date.now() + delay) },
            sound: 'default',
            smallIcon: 'ic_stat_icon_config_sample',
            iconColor: '#488AFF',
          },
        ],
      });
    } catch (error) {
      console.error('Error scheduling local notification:', error);
    }
  };

  return {
    isRegistered,
    token,
    scheduleLocalNotification,
  };
};
